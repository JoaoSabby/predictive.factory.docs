#' @title Adicionar o Nível de Probabilidade da Predição
#'
#' @usage
#' AddColumn_TARGET_PROB_LEVEL(database)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Acrescenta a coluna `TARGET_PROB_LEVEL`, que classifica a probabilidade prevista da
#' classe positiva em três níveis.
#'
#' @details
#' Sendo \eqn{p} o valor de `TARGET_PROB` e \eqn{m} a mediana de \eqn{p} entre os
#' registros com \eqn{p \ge 0{,}5}:
#'
#' +-------+------------------------------+
#' | Nível | Condição                     |
#' +=======+==============================+
#' | `1L`  | \eqn{p < 0{,}5}              |
#' +-------+------------------------------+
#' | `2L`  | \eqn{0{,}5 \le p < m}        |
#' +-------+------------------------------+
#' | `3L`  | \eqn{p \ge m} e demais casos |
#' +-------+------------------------------+
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **Casos Particulares:**
#' Registros com `TARGET_PROB` ausente recebem o nível `3L`, pelo ramo `TRUE` de
#' `case_when()`. Quando nenhum registro tem \eqn{p \ge 0{,}5}, \eqn{m} é `NA`, e todos os
#' registros com \eqn{p \ge 0{,}5} recebem o nível `3L`. A função não é chamada por nenhum
#' pipeline do projeto.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(AddColumn_TARGET_PROB_LEVEL, prefix = "##", code = FALSE,
#'   narrow = TRUE), "AddColumn_TARGET_PROB_LEVEL_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(AddColumn_TARGET_PROB_LEVEL,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "AddColumn_TARGET_PROB_LEVEL_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @param database Data frame com a coluna numérica `TARGET_PROB`.
#'
#' @returns `database` com a coluna inteira `TARGET_PROB_LEVEL` acrescentada.
#'
#' @family Avaliação do Modelo
#'
#' @seealso \code{\link{PredictModel}}
#'
#' @references
#' dplyr: case_when.
#' \url{https://dplyr.tidyverse.org/reference/case_when.html}
#'
#' @examples
#' \dontrun{
#' predicoes <- tibble::tibble(TARGET_PROB = c(0.2, 0.6, 0.9))
#' AddColumn_TARGET_PROB_LEVEL(predicoes)
#' }
#'
#' @export
AddColumn_TARGET_PROB_LEVEL <- function(database){
  
  ## Calculo do limite entre niveis
  # Apura niveis de probabilidade
  betweenLevelLimit <- database |> 
    filter(
      (TARGET_PROB >= 0.5)
    ) |> 
    summarise(
      Median = median(TARGET_PROB, na.rm = TRUE) 
    ) |> 
    pull(Median)
  
  ## Classificacao em niveis
  # Adiciona
  database <- database |> 
    mutate(
      TARGET_PROB_LEVEL = case_when(
        (TARGET_PROB < 0.5)               ~ 1L,
        (TARGET_PROB < betweenLevelLimit) ~ 2L,
        TRUE                              ~ 3L
      )
    )
  
  # Retorno da funcao 
  return(database)
}
####
## Fim
#