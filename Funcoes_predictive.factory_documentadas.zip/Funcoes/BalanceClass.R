#' @title Balancear as Classes da Base de Treino
#'
#' @usage
#' BalanceClass(database, balanceClassConfig, nThreads)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Aplica à base de treino o método de balanceamento de classes definido em
#' `balanceClassConfig$method`.
#'
#' @details
#' +-----------------------------+-------------------------------------------------------+
#' | `balanceClassConfig$method` | Ação                                                  |
#' +=============================+=======================================================+
#' | `"adanear"`                 | `BalanceClassAdanear()`: sobreamostragem ADASYN e     |
#' |                             | subamostragem NearMiss                                |
#' +-----------------------------+-------------------------------------------------------+
#' | `"random_under"`            | `BalanceClassRandomUnder()`: subamostragem aleatória  |
#' |                             | da classe majoritária                                 |
#' +-----------------------------+-------------------------------------------------------+
#' | outro valor                 | base retornada sem alteração                          |
#' +-----------------------------+-------------------------------------------------------+
#'
#' O balanceamento deve ser aplicado apenas às bases de ajuste, nunca às bases de
#' validação ou de teste, para que as métricas reflitam a distribuição real das classes.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(BalanceClass, prefix = "##", code = FALSE,
#'   narrow = TRUE), "BalanceClass_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(BalanceClass, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "BalanceClass_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @param database Data frame com a coluna `TARGET` (fator com níveis `"Sim"` e `"Nao"`) e
#'   as features.
#' @param balanceClassConfig Lista com o elemento `method` e os parâmetros do método
#'   escolhido (por exemplo, `adasyn_k`, `adasyn_ratio`, `nearmiss_k`, `nearmiss_ratio` ou
#'   `under_sampling`).
#' @param nThreads Inteiro com o número de threads, repassado apenas ao método
#'   `"adanear"`.
#'
#' @returns Data frame balanceado, com as mesmas colunas de `database`.
#'
#' @family Balanceamento de Classes
#'
#' @seealso \code{\link{BalanceClassAdanear}}, \code{\link{BalanceClassRandomUnder}},
#'   \code{\link{FitModelXGBoost}}, \code{\link{TuneModelResampleFoldsXGBoost}}
#'
#' @references
#' He, H., & Garcia, E. A. (2009). Learning from imbalanced data. IEEE Transactions on
#' Knowledge and Data Engineering, 21(9), 1263-1284.
#' \url{https://doi.org/10.1109/TKDE.2008.239}
#'
#' @examples
#' \dontrun{
#' balancedDataset <- BalanceClass(
#'   database = trainingSet,
#'   balanceClassConfig = list(method = "random_under", under_sampling = 3),
#'   nThreads = 4L
#' )
#' }
#'
#' @export
BalanceClass <- function(database, balanceClassConfig, nThreads){
  
  ## Selecao do metodo de balanceamento
  # Se for balanceamento ADASYN + NearMiss
  if(balanceClassConfig$method == "adanear"){
    balancedDataset <- BalanceClassAdanear(database, balanceClassConfig, nThreads)
  # Se for balanceamento aleatorio para reducao classe majoritaria
  } else if(balanceClassConfig$method == "random_under"){
    balancedDataset <- BalanceClassRandomUnder(database, balanceClassConfig)
  } else {
    balancedDataset <- database
  }
  
  ## Retorno da base balanceada
  # Retorna base balanceada
  return(balancedDataset)
} 
####
## Fim
#
