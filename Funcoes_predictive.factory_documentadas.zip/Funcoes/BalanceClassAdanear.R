#' @title Balancear Classes com ADASYN e NearMiss
#'
#' @usage
#' BalanceClassAdanear(database, balanceClassConfig, nThreads)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Balanceia a base de treino combinando sobreamostragem sintética adaptativa (ADASYN) da
#' classe minoritária e subamostragem NearMiss da classe majoritária, por meio de
#' `sbyadanear::sby_adanear_hpc()`.
#'
#' @details
#' Antes do balanceamento, as colunas lógicas são convertidas para inteiro. O ADASYN gera
#' exemplos sintéticos da classe minoritária em proporção à dificuldade de cada ponto,
#' medida pela fração de vizinhos da classe majoritária entre seus \eqn{k} vizinhos:
#' \deqn{r_i = \frac{\Delta_i}{k}, \qquad g_i = \frac{r_i}{\sum_j r_j} G}
#' em que \eqn{\Delta_i} é o número de vizinhos majoritários e \eqn{G} é o total de
#' exemplos sintéticos. O NearMiss mantém os exemplos majoritários mais próximos da classe
#' minoritária.
#'
#' A semente é fixada em `42` por `set.seed(42L)` e pelo argumento `sby_seed = 42L`, o que
#' torna o resultado reprodutível para os mesmos dados e parâmetros.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **Restauração de Tipos:**
#' Após o balanceamento, voltam a ser lógicas as colunas que em `database` são inteiras
#' com valores em \eqn{\{0, 1, NA\}}. As colunas que já eram lógicas em `database` foram
#' convertidas para inteiro antes do balanceamento e permanecem inteiras no resultado.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(BalanceClassAdanear, prefix = "##", code = FALSE,
#'   narrow = TRUE), "BalanceClassAdanear_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(BalanceClassAdanear, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "BalanceClassAdanear_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @param database Data frame com `TARGET` e as features.
#' @param balanceClassConfig Lista com `adasyn_k`, `adasyn_ratio`, `nearmiss_k` e
#'   `nearmiss_ratio`.
#' @param nThreads Inteiro com o número máximo de threads do algoritmo.
#'
#' @returns Data frame balanceado retornado por `sby_adanear_hpc()`, com a restauração de
#'   tipos descrita em detalhes.
#'
#' @family Balanceamento de Classes
#'
#' @seealso \code{\link{BalanceClass}}, \code{\link{BalanceClassRandomUnder}}
#'
#' @references
#' He, H., Bai, Y., Garcia, E. A., & Li, S. (2008). ADASYN: Adaptive synthetic sampling
#' approach for imbalanced learning. IEEE International Joint Conference on Neural
#' Networks, 1322-1328.
#' \url{https://doi.org/10.1109/IJCNN.2008.4633969}
#'
#' Mani, I., & Zhang, I. (2003). kNN approach to unbalanced data distributions: a case
#' study involving information extraction. Proceedings of the ICML Workshop on Learning
#' from Imbalanced Datasets.
#'
#' @examples
#' \dontrun{
#' balancedDataset <- BalanceClassAdanear(
#'   database = trainingSet,
#'   balanceClassConfig = list(
#'     adasyn_k = 5L, adasyn_ratio = 0.5, nearmiss_k = 3L, nearmiss_ratio = 1
#'   ),
#'   nThreads = 4L
#' )
#' }
#'
#' @export
BalanceClassAdanear <- function(database, balanceClassConfig, nThreads){
  
  ## Balanceamento ADASYN e NearMiss
  # Balanceamento de registros entre classes - adanear
  set.seed(42L)
  balancedDataset <- sbyadanear::sby_adanear_hpc(
    formula = TARGET ~ .,
    .data = database |> 
      dplyr::mutate_if(is.logical, as.integer),
    sby_adasyn_k = balanceClassConfig$adasyn_k,
    sby_adasyn_ratio = balanceClassConfig$adasyn_ratio,
    sby_nearmiss_k = balanceClassConfig$nearmiss_k,
    sby_nearmiss_ratio = balanceClassConfig$nearmiss_ratio,
    sby_seed = 42L,
    sby_config_max_threads = nThreads
  ) 
  
  ## Restauracao das colunas logicas
  # Retorna campos logicos
  balancedDataset <- collapse::ftransformv(
    .data = balancedDataset,
    vapply(database, function(x) {
      if(!is.integer(x)) return(FALSE)
      collapse::allv(collapse::fmatch(collapse::funique(x), c(0, 1, NA), nomatch = 0L) > 0L, TRUE)
    }, logical(1L)), as.logical
  )
  
  # Dados balanceados
  return(balancedDataset)
}
####
## Fim
#
