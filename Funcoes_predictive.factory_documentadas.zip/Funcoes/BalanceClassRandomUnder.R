#' @title Balancear Classes por Subamostragem Aleatória
#'
#' @usage
#' BalanceClassRandomUnder(database, balanceClassConfig)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Reduz a classe majoritária (`TARGET == "Nao"`) por amostragem aleatória sem reposição,
#' em proporção ao tamanho da classe minoritária, e mantém todos os registros da classe
#' minoritária (`TARGET == "Sim"`).
#'
#' @details
#' Sendo \eqn{n_{min}} o número de registros com `TARGET == "Sim"` e \eqn{u} o valor de
#' `balanceClassConfig$under_sampling`, o número de registros da classe majoritária
#' mantidos é:
#' \deqn{n_{maj} = \lfloor n_{min} \cdot u \rfloor}
#' limitado ao total disponível. A semente é fixada em `42` por `set.seed(42)`. O
#' resultado contém primeiro os registros majoritários amostrados e depois os
#' minoritários.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(BalanceClassRandomUnder, prefix = "##", code = FALSE,
#'   narrow = TRUE), "BalanceClassRandomUnder_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(BalanceClassRandomUnder, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "BalanceClassRandomUnder_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @param database Data frame com `TARGET` (níveis `"Sim"` e `"Nao"`) e as features.
#' @param balanceClassConfig Lista com o elemento numérico `under_sampling`, razão entre
#'   registros majoritários mantidos e registros minoritários.
#'
#' @returns Data frame com \eqn{n_{maj} + n_{min}} linhas e as mesmas colunas de
#'   `database`.
#'
#' @family Balanceamento de Classes
#'
#' @seealso \code{\link{BalanceClass}}, \code{\link{BalanceClassAdanear}},
#'   \code{\link[dplyr]{slice_sample}}
#'
#' @references
#' He, H., & Garcia, E. A. (2009). Learning from imbalanced data. IEEE Transactions on
#' Knowledge and Data Engineering, 21(9), 1263-1284.
#' \url{https://doi.org/10.1109/TKDE.2008.239}
#'
#' @examples
#' \dontrun{
#' balancedDataset <- BalanceClassRandomUnder(
#'   database = trainingSet,
#'   balanceClassConfig = list(under_sampling = 3)
#' )
#' }
#'
#' @export
BalanceClassRandomUnder <- function(database, balanceClassConfig){
  
  ## Contagem da classe minoritaria
  # Tamanho da classe minoritaria
  sizeMinorClass <- sum(database$TARGET == "Sim")
  
  ## Subamostragem da classe majoritaria
  # Dados balanceados
  set.seed(42)
  balancedDataset <- database |> 
    filter(
      (TARGET == "Nao")
    ) |> 
    slice_sample(
      n = as.integer(sizeMinorClass * balanceClassConfig$under_sampling),
      replace = FALSE
    ) |> 
    bind_rows(
      database |> 
        filter(
          (TARGET == "Sim")
        )
    ) 
  
  # Dados balanceados
  return(balancedDataset)
}
####
## Fim
#