#' @title Construir o Pipeline Completo de Modelagem Preditiva
#'
#' @usage
#' BuildPipeline()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Monta a lista completa de targets do pipeline preditivo, concatenando os pipelines de
#' cada fase e aplicando a todos os targets os ganchos de inicialização e de registro de
#' logs.
#'
#' @details
#' É a última expressão de `_targets.R` e, portanto, define o grafo de dependências (DAG)
#' executado por `tar_make()`. As fases são concatenadas na ordem:
#'
#' #. `BuildPipelineBegin()`: inicialização e metadados do ambiente;
#' #. `BuildPipelineHistoricalData()`: feature engineering e alvo para modelagem;
#' #. `BuildPipelineModeling()`: preparação, divisão, tuning, ajuste e avaliação;
#' #. `BuildPipelinePredictingData()`: feature engineering para predição;
#' #. `BuildPipelinePredicting()`: preparação dos dados e inferência;
#' #. `BuildPipelineFinish()`: registro do término.
#'
#' `BuildPipelinePublishing()` está desativada por comentário. Em seguida:
#'
#' - `tar_hook_before()` insere `InitializeTargetExecution()` antes do comando de cada
#'   target;
#' - `tar_hook_outer()` envolve o comando de cada target (`.x`) em
#'   `LogPipelineExecution()`, que registra traces, telemetria e registro de execução nas
#'   pastas `logsTracesPath`, `logsTelemetryPath` e `logsRegistryPath`;
#' - `purrr::compact()` remove elementos vazios da lista.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-sitemap"></i> **Objetos Globais:**
#' Os caminhos de log são lidos do ambiente global, onde foram publicados por
#' `LoadModelRunConfig()` em `_Setup.R`.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(BuildPipeline, prefix = "##", code = FALSE,
#'   narrow = TRUE), "BuildPipeline_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(BuildPipeline, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "BuildPipeline_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - escreve no console as etapas de progresso de cada fase e as encerra com
#'   `cli_progress_cleanup()`.
#'
#' @returns Lista de objetos `tar_target` com os ganchos aplicados, pronta para ser
#'   retornada por `_targets.R`.
#'
#' @family Construção do Pipeline
#'
#' @seealso \code{\link{BuildPipelineBegin}}, \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{BuildPipelineModeling}}, \code{\link{BuildPipelinePredictingData}},
#'   \code{\link{BuildPipelinePredicting}}, \code{\link{BuildPipelineFinish}},
#'   \code{\link{LogPipelineExecution}}, \code{\link[tarchetypes]{tar_hook_outer}}
#'
#' @references
#' Landau, W. M. (2021). The targets R package: a dynamic Make-like function-oriented
#' pipeline toolkit for reproducibility and high-performance computing. Journal of Open
#' Source Software, 6(57), 2959.
#' \url{https://doi.org/10.21105/joss.02959}
#'
#' tarchetypes: Target hooks.
#' \url{https://docs.ropensci.org/tarchetypes/reference/tar_hook_outer.html}
#'
#' @examples
#' \dontrun{
#' # Em _targets.R, após _Setup.R e tar_option_set()
#' BuildPipeline()
#' }
#'
#' @importFrom tarchetypes tar_hook_before tar_hook_outer
#' @importFrom purrr compact
#'
#' @export
BuildPipeline <- function(){

  ## Concatenacao dos pipelines das fases
  # Orquestrador do pipeline preditivo
  listPipeline <- c(
    
    # Pipeline para inicialização do processo de modelagem preditiva
    BuildPipelineBegin(),
    
    # Pipeline para feature engineering dos dados usados na modelagem
    BuildPipelineHistoricalData(),
     
    # Pipeline para construcao e ajuste do modelo preditivo
    BuildPipelineModeling(),
     
    # Pipeline para feature engineering dos dados usados na predicao
    BuildPipelinePredictingData(),
     
    # Pipeline para processamento e geracao das predicoes
    BuildPipelinePredicting(),
    
    # Pipeline para publicacao, armazenamento e registros finais do modelo preditivo 
    # BuildPipelinePublishing(),
     
    # Pipeline para finalizacao do processo de modelagem preditiva
    BuildPipelineFinish()
  )
  
  ## Encerramento das mensagens de progresso
  # Finaliza mensagens dos pipelines
  cli_progress_cleanup()
  
  ## Aplicacao do gancho de inicializacao
  # Inicializacoes antes de executar os alvos
  listPipeline <- tar_hook_before(
    targets = listPipeline,
    names = tidyselect::everything(),
    hook = InitializeTargetExecution()
  )

  ## Aplicacao do gancho de registro de logs
  # Adiciona registro de logs
  listPipeline <- tar_hook_outer(
    targets = listPipeline,
    names = tidyselect::everything(),
    hook = LogPipelineExecution(
      targetCommand = .x,
      targetName = targets::tar_name(),
      logsTracesPath = logsTracesPath,
      logsTelemetryPath = logsTelemetryPath,
      logsRegistryPath = logsRegistryPath
    )
  )

  ## Remocao de elementos vazios
  # Limpa pipeline de list's vazios
  listPipeline <- purrr::compact(listPipeline)
  
  # Retorna list com pipeline completo
  return(listPipeline)
}
####
## Fim
#
