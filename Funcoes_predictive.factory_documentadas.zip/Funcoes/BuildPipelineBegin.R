#' @title Construir o Pipeline de Inicialização
#'
#' @usage
#' BuildPipelineBegin()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Cria o target `pipelineBegin`, que registra o início da execução e captura metadados do
#' usuário, do processo, do servidor e da sessão R.
#'
#' @details
#' O target usa `tar_cue(mode = "always")` e, por isso, executa em toda chamada de
#' `tar_make()`. Como `pipelineBegin` é dependência de `CheckFeatureStore()`, a cada
#' execução a verificação da feature store também é refeita.
#'
#' @section Targets do Pipeline:
#' +-----------------+-------------------------------------------------------------------+
#' | Target          | Descrição, comando e dependências                                 |
#' +=================+===================================================================+
#' | `pipelineBegin` | Inicialização do processo de modelagem. Comando: `list(Username,  |
#' |                 | PID, ...)`. Depende de: nenhum.                                   |
#' +-----------------+-------------------------------------------------------------------+
#'
#' A lista do comando contém: `Username`, `PPID`, `PID`, `Inicio`, `UsedRAM`,
#' `Theads_limit` (opção `predy_threads_limit`), `Environment`, `Server` (saída de
#' `lscpu`), `PlatformInfo`, `ExternalInfo` e `SessionInfo`.
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(BuildPipelineBegin, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "BuildPipelineBegin_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - escreve no console a etapa de progresso do pipeline e a encerra com
#'   `cli_progress_done()`;
#' - na execução do target: executa o comando de sistema `lscpu` duas vezes.
#'
#' @returns Lista com um objeto `tar_target` (`pipelineBegin`).
#'
#' @family Construção do Pipeline
#'
#' @seealso \code{\link{BuildPipeline}}, \code{\link{BuildPipelineFinish}},
#'   \code{\link[sessioninfo]{session_info}}, \code{\link[targets]{tar_cue}}
#'
#' @references
#' The targets R Package User Manual.
#' \url{https://books.ropensci.org/targets/}
#'
#' sessioninfo: R Session Information.
#' \url{https://sessioninfo.r-lib.org/}
#'
#' @examples
#' \dontrun{
#' listPipelineBegin <- BuildPipelineBegin()
#' }
#'
#' @importFrom targets tar_target tar_cue
#'
#' @export
BuildPipelineBegin <- function(){
  
  ## Construcao do target de inicializacao
  # Constroi pipeline 
  listPipelineBegin <- list(  
    tar_target(
      description = "inicializacao processo de modelagem preditiva",
      name = pipelineBegin,
      command = list(
        Username = ps::ps_username(),
        PPID = ps::ps_ppid(),
        PID = ps::ps_pid(), 
        Inicio = Sys.time(),
        UsedRAM = lobstr::mem_used(),
        Theads_limit = opt("predy_threads_limit"),
        Environment = ps::ps_environ(),
        Server = tibble(
          Campo = names(class(system("lscpu", intern = TRUE))),
          Valor = system("lscpu", intern = TRUE) 
        ),
        PlatformInfo = sessioninfo::platform_info(),
        ExternalInfo = sessioninfo::external_info(),
        SessionInfo  = sessioninfo::session_info()
      ),
      packages = character(),
      cue = tar_cue(
        mode = "always"
      )
    )
  )
  
  ## Exibicao da etapa de progresso
  # Processo atual
  pipelineName <- "inicialização do processo de modelagem preditiva"
  cli_progress_step(
    msg = "{cli::style_bold(cli::col_cyan('BuildPipelineBegin'))}: {cli::col_cyan(pipelineName)}"
  )
  cli_progress_done()
  
  ## Retorno da lista de targets
  # Retorna list do pipeline
  return(listPipelineBegin)
}
####
## Fim
#
