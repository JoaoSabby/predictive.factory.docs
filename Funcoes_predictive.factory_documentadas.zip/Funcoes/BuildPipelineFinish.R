#' @title Construir o Pipeline de Finalização
#'
#' @usage
#' BuildPipelineFinish()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Cria o target `pipelineFinish`, que registra o horário de término e a memória usada ao
#' final da execução do pipeline.
#'
#' @details
#' O target usa `tar_cue(mode = "always")` e executa em toda chamada de `tar_make()`.
#'
#' @section Targets do Pipeline:
#' +------------------+------------------------------------------------------------------+
#' | Target           | Descrição, comando e dependências                                |
#' +==================+==================================================================+
#' | `pipelineFinish` | Final do pipeline preditivo. Comando: `list(Final, UsedRAM)`.    |
#' |                  | Depende de: nenhum.                                              |
#' +------------------+------------------------------------------------------------------+
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(BuildPipelineFinish, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "BuildPipelineFinish_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - escreve no console a etapa de progresso do pipeline.
#'
#' @returns Lista com um objeto `tar_target` (`pipelineFinish`).
#'
#' @family Construção do Pipeline
#'
#' @seealso \code{\link{BuildPipeline}}, \code{\link{BuildPipelineBegin}},
#'   \code{\link[lobstr]{mem_used}}
#'
#' @references
#' The targets R Package User Manual.
#' \url{https://books.ropensci.org/targets/}
#'
#' @examples
#' \dontrun{
#' listPipelineFinish <- BuildPipelineFinish()
#' }
#'
#' @importFrom targets tar_target tar_cue
#'
#' @export
BuildPipelineFinish <- function(){
  
  ## Construcao do target de finalizacao
  # Constroi pipeline
  listPipelineFinish <- list(  
    tar_target(
      description = "Final do pipeline preditivo",
      name = pipelineFinish,
      command = list(
        Final = Sys.time(),
        UsedRAM = lobstr::mem_used()
      ),
      packages = character(),
      cue = tar_cue(
        mode = "always"
      )
    )
  )
  
  ## Exibicao da etapa de progresso
  # Processo atual
  pipelineName <- "finalização do processo de modelagem preditiva"  
  cli_progress_step(
    msg = "{cli::style_bold(cli::col_cyan('BuildPipelineFinish'))}: {cli::col_cyan(pipelineName)}"
  )
  
  ## Retorno da lista de targets
  # Retorna list pipeline
  return(listPipelineFinish)
}
####
##
# 
