#' @title Construir o Pipeline de Dados Históricos para Modelagem
#'
#' @usage
#' BuildPipelineHistoricalData()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Cria os targets de feature engineering da base de treino: verificação da feature store,
#' definição dos clientes válidos, geração de cada feature group, consolidação na feature
#' store de treino, geração do alvo e consolidação dos dados históricos.
#'
#' @details
#' Os feature groups são descobertos dinamicamente: `tar_map()` cria um target para cada
#' função do ambiente global cujo nome começa com `GenerateFeatureLineage_IM_ML_`. O nome
#' de cada target é `trainingFeatureGroupTable_{GRUPO}`, em que `{GRUPO}` é o sufixo da
#' função (por exemplo, `RFM`). Assim, um novo feature group passa a fazer parte do
#' pipeline apenas pela criação da função correspondente em `Funcoes/`.
#'
#' Os targets de geração usam `tar_skip()` com `skip = featureStoreProcessedTreino`:
#' quando a feature store de treino já existe, a geração é ignorada. Todos os targets usam
#' `deployment = "worker"`, e os feature groups usam o controlador `crew`
#' `GenerateFeatureLineage`.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-link"></i> **Dependência Externa:**
#' `GenerateTarget()` não pertence ao predictive.factory: deve ser definida pelo projeto
#' cliente (por exemplo, `predictive.desercao/Funcoes`).
#' :::
#'
#' @section Targets do Pipeline:
#' +-------------------------------------+-----------------------------------------------+
#' | Target                              | Descrição, comando e dependências             |
#' +=====================================+===============================================+
#' | `featureStoreProcessedTreino`       | Verifica a feature store de treino. Comando:  |
#' |                                     | `CheckFeatureStore()`. Depende de:            |
#' |                                     | `pipelineBegin`.                              |
#' +-------------------------------------+-----------------------------------------------+
#' | `tabelaClientesValidosTreino`       | Define os clientes válidos de treino.         |
#' |                                     | Comando: `DefineValidCustomers()`. Depende    |
#' |                                     | de: configuração.                             |
#' +-------------------------------------+-----------------------------------------------+
#' | `trainingFeatureGroupTable_{GRUPO}` | Gera cada feature group de treino. Comando:   |
#' |                                     | `GenerateFeatureLineage_IM_ML_{GRUPO}()`.     |
#' |                                     | Depende de: `tabelaClientesValidosTreino`.    |
#' +-------------------------------------+-----------------------------------------------+
#' | `modelingTable_FEATURE_STORE`       | Consolida `IM_ML_FEATURE_STORE_TREINO`.       |
#' |                                     | Comando: `Generate_IM_ML_FEATURE_STORE()`.    |
#' |                                     | Depende de: feature groups de treino.         |
#' +-------------------------------------+-----------------------------------------------+
#' | `table_TARGET`                      | Gera o alvo de treino. Comando:               |
#' |                                     | `GenerateTarget()`. Depende de:               |
#' |                                     | `tabelaClientesValidosTreino`.                |
#' +-------------------------------------+-----------------------------------------------+
#' | `historicalData`                    | Consolida preditores e alvo. Comando:         |
#' |                                     | `ConsolidateHistoricalData()`. Depende de:    |
#' |                                     | `table_TARGET`,                               |
#' |                                     | `modelingTable_FEATURE_STORE`.                |
#' +-------------------------------------+-----------------------------------------------+
#'
#' Nenhum target informa `format`; vale o padrão `"qs"` de `_targets.R`.
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(BuildPipelineHistoricalData,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "BuildPipelineHistoricalData_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - escreve no console a etapa de progresso por meio de `MsgBuildPipeline()`;
#' - depende dos objetos globais de datas e janelas publicados por `LoadModelRunConfig()`
#'   (por exemplo, `dataFeatureTreino` e `janelaAgregacao`).
#'
#' @returns Lista invisível de objetos `tar_target`, incluindo os targets gerados por
#'   `tar_map()`.
#'
#' @family Construção do Pipeline
#'
#' @seealso \code{\link{BuildPipeline}}, \code{\link{CheckFeatureStore}},
#'   \code{\link{DefineValidCustomers}}, \code{\link{Generate_IM_ML_FEATURE_STORE}},
#'   \code{\link{ConsolidateHistoricalData}}, \code{\link[tarchetypes]{tar_map}},
#'   \code{\link[tarchetypes]{tar_skip}}
#'
#' @references
#' Landau, W. M. (2021). The targets R package: a dynamic Make-like function-oriented
#' pipeline toolkit for reproducibility and high-performance computing. Journal of Open
#' Source Software, 6(57), 2959.
#' \url{https://doi.org/10.21105/joss.02959}
#'
#' tarchetypes: Static branching with tar_map.
#' \url{https://docs.ropensci.org/tarchetypes/reference/tar_map.html}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: funções carregadas e configuração publicada por LoadModelRunConfig()
#' listPipelineTrainingData <- BuildPipelineHistoricalData()
#' }
#'
#' @importFrom targets tar_target tar_resources tar_resources_crew
#' @importFrom tarchetypes tar_map tar_skip
#'
#' @export
BuildPipelineHistoricalData <- function(){
  
  ## Construcao dos targets de dados historicos
  # Constroi pipeline
  listPipelineTrainingData <- list(
    tar_target(
      description = glue("Verifica se possui ML_FEATURE_STORE para treino na referência {dataFeatureTreino}"),
      name = featureStoreProcessedTreino,
      command = CheckFeatureStore(
        pipelineBegin = pipelineBegin,
        dataFeature = dataFeatureTreino,
        janelaAgregacao = janelaAgregacao,
        janelaHistorico = janelaHistorico
      ),
      deployment = "worker"
    ),
    tar_target(
      description = glue("Definição dos clientes validos para treino na referência {dataFeatureTreino}"),
      name = tabelaClientesValidosTreino,
      command = DefineValidCustomers(
        sufixoTabela = "TREINO",
        featureProcessed = FALSE,
        janelaAgregacao = janelaAgregacao,
        janelaHistorico = janelaHistorico,
        dataReferencia = dataFeatureTreino,
        dataAgregacaoInicial = dataFeatureTreinoAgregacaoInicial,
        dataAgregacaoFinal = dataFeatureTreinoAgregacaoFinal,
        dataHistoricaInicial = dataFeatureTreinoHistoricaInicial,
        dataHistoricaFinal = dataFeatureTreinoHistoricaFinal
      ),
      deployment = "worker"
    ),
    tar_map(
      values = tibble(
        Function = ls(
          pattern = "^GenerateFeatureLineage_IM_ML_",
          sorted = TRUE,
          envir = .GlobalEnv
        )
      ) |>
        mutate(
          FeatureGroup = str_remove(Function, "GenerateFeatureLineage_IM_ML_"),
          Function = syms(Function),
          Description = glue("Geração do feature group {FeatureGroup} na tabela IM_ML_{FeatureGroup}_TREINO")
        ),
      names = FeatureGroup,
      descriptions = Description,
      delimiter = "_",
      tar_skip(
        skip = featureStoreProcessedTreino,
        name = trainingFeatureGroupTable,
        command = Function(
          sufixoTabela          = "TREINO",
          tabelaClientesValidos = tabelaClientesValidosTreino,
          dataFeature           = dataFeatureTreino,
          janelaAgregacao       = janelaAgregacao,
          janelaHistorico       = janelaHistorico,
          dataAgregacaoInicial  = dataFeatureTreinoAgregacaoInicial,
          dataAgregacaoFinal    = dataFeatureTreinoAgregacaoFinal,
          dataHistoricaInicial  = dataFeatureTreinoHistoricaInicial,
          dataHistoricaFinal    = dataFeatureTreinoHistoricaFinal
        ),
        resources = tar_resources(
          crew = tar_resources_crew(
            controller = "GenerateFeatureLineage"
          )
        ),
        deployment = "worker"
      )
    ),
    tar_skip(
      skip = featureStoreProcessedTreino,
      description = "Geração da tabela IM_ML_FEATURE_STORE_TREINO que consolida os feature groups para treino do modelo",
      name = modelingTable_FEATURE_STORE,
      command = Generate_IM_ML_FEATURE_STORE(
        sufixoTabela = "TREINO",
        nomesTabelas = list(!!!rlang::syms(
          ls(
            pattern = "^GenerateFeatureLineage_IM_ML_",
            sorted = TRUE,
            envir = .GlobalEnv
          ) |>
            str_remove("GenerateFeatureLineage_IM_ML_") %>%
            str_c("trainingFeatureGroupTable_", .)
        )),
        tabelaClientesValidos = tabelaClientesValidosTreino,
        dataFeature = dataFeatureTreino,
        janelaAgregacao = janelaAgregacao,
        janelaHistorico = janelaHistorico,
        dataAgregacaoInicial = dataFeatureTreinoAgregacaoInicial,
        dataAgregacaoFinal = dataFeatureTreinoAgregacaoFinal,
        dataHistoricaInicial = dataFeatureTreinoHistoricaInicial,
        dataHistoricaFinal = dataFeatureTreinoHistoricaFinal
      ),
      deployment = "worker"
    ),
    tar_target(
      description = glue("Geração do TARGET {targetModel} referente {dataTargetTreino}"),
      name = table_TARGET,
      command = GenerateTarget(
        tabelaClientesValidosTreino = tabelaClientesValidosTreino,
        targetModel = targetModel,
        dataTargetTreino = dataTargetTreino,
        dataTargetTreinoInicial = dataTargetTreinoInicial,
        dataTargetTreinoFinal = dataTargetTreinoFinal,
        horizontePreditivo = horizontePreditivo
      ),
      deployment = "worker"
    ),
    tar_target(
      description = glue("Consolida dados historicos com TARGET {targetModel} no modelo {idModel}"),
      name = historicalData,
      command = ConsolidateHistoricalData(
        table_TARGET = table_TARGET,
        modelingTable_FEATURE_STORE = modelingTable_FEATURE_STORE
      ),
      deployment = "worker"
    )
  )
  
  ## Exibicao da etapa de progresso
  # Processo atual
  MsgBuildPipeline("feature engineering dos dados usados na modelagem")
  
  ## Retorno da lista de targets
  # Retorna list do pipeline
  return(invisible(listPipelineTrainingData))
}
####
## Fim
#
