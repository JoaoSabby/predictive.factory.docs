#' @title Construir o Pipeline de Modelagem Preditiva
#'
#' @usage
#' BuildPipelineModeling()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Cria os targets de modelagem: preparação dos dados históricos, divisão em treino e
#' teste, otimização de hiperparâmetros, ajuste do modelo final e avaliação do desempenho
#' na base de teste.
#'
#' @details
#' A divisão treino e teste usa `rsample::initial_split()` estratificada por `TARGET`, com
#' a proporção de treino definida pela opção `predy_training_set_prop`. A descrição do
#' target de tuning informa o motor da opção `predy_engine_model`.
#'
#' @section Targets do Pipeline:
#' +----------------------+--------------------------------------------------------------+
#' | Target               | Descrição, comando e dependências                            |
#' +======================+==============================================================+
#' | `dataModel`          | Preprocessamento dos dados históricos. Comando:              |
#' |                      | `PrepareDataModel()`. Depende de: `historicalData`.          |
#' +----------------------+--------------------------------------------------------------+
#' | `splitSet`           | Divisão estratificada em treino e teste. Comando:            |
#' |                      | `initial_split()`. Depende de: `dataModel`.                  |
#' +----------------------+--------------------------------------------------------------+
#' | `trainingSet`        | Porção de treino. Comando: `training()`. Depende de:         |
#' |                      | `splitSet`.                                                  |
#' +----------------------+--------------------------------------------------------------+
#' | `hyperParams`        | Otimização de hiperparâmetros. Comando: `TuneModel()`.       |
#' |                      | Depende de: `trainingSet`.                                   |
#' +----------------------+--------------------------------------------------------------+
#' | `fileModel`          | Ajuste do modelo preditivo. Comando: `FitModel()`. Formato:  |
#' |                      | `"file"`. Depende de: `trainingSet`, `hyperParams`.          |
#' +----------------------+--------------------------------------------------------------+
#' | `holdoutSet`         | Porção de teste. Comando: `testing()`. Depende de:           |
#' |                      | `splitSet`.                                                  |
#' +----------------------+--------------------------------------------------------------+
#' | `performanceMetrics` | Desempenho na base de teste. Comando: `EvaluateModel()`.     |
#' |                      | Depende de: `fileModel`, `holdoutSet`.                       |
#' +----------------------+--------------------------------------------------------------+
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(BuildPipelineModeling, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "BuildPipelineModeling_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - escreve no console a etapa de progresso do pipeline.
#'
#' @returns Lista com sete objetos `tar_target`.
#'
#' @family Construção do Pipeline
#'
#' @seealso \code{\link{BuildPipeline}}, \code{\link{PrepareDataModel}},
#'   \code{\link{TuneModel}}, \code{\link{FitModel}}, \code{\link{EvaluateModel}},
#'   \code{\link[rsample]{initial_split}}
#'
#' @references
#' Hastie, T., Tibshirani, R., & Friedman, J. (2009). The Elements of Statistical Learning
#' (2a ed.). Springer. Capítulo 7: Model Assessment and Selection.
#' \url{https://hastie.su.domains/ElemStatLearn/}
#'
#' rsample: General Resampling Infrastructure.
#' \url{https://rsample.tidymodels.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: opções definidas por DefineOptionsSetup()
#' listPipelineModeling <- BuildPipelineModeling()
#' }
#'
#' @importFrom targets tar_target
#' @importFrom rsample initial_split training testing
#'
#' @export
BuildPipelineModeling <- function(){
  
  ## Construcao dos targets de modelagem
  # Constroi pipeline
  listPipelineModeling <- list(
    tar_target(
      description = "Preprocessamento dos dados históricos (historicalData) para dados de modelagem (modelData)",
      name = dataModel,
      command = PrepareDataModel(
        dataset = historicalData
      )
    ),
    tar_target(
      description = "Split dados de modelagem (modelData) em treino (trainingSet) e teste (holdoutSet) para cálculo de desempenho",
      name = splitSet,
      command = initial_split(
        data = dataModel,
        prop = opt("predy_training_set_prop"),
        strata = "TARGET"
      )
    ),
    tar_target(
      description = "Extrai porção de treino (trainingSet)",
      name = trainingSet,
      command = training(
        x = splitSet
      )
    ),
    tar_target(
      description = glue("Otimização de hiperparâmetros para {opt('predy_engine_model')}"),
      name = hyperParams, 
      command = TuneModel(
        trainingSet = trainingSet
      )
    ),
    tar_target(
      description = "Criação do modelo preditivo",
      name = fileModel,
      command = FitModel(
        trainingSet = trainingSet,
        hyperParams = hyperParams
      ),
      format = "file"
    ),
    tar_target(
      description = "Extrai porção para teste (holdoutSet)",
      name = holdoutSet,
      command = testing(
        x = splitSet
      )
    ),
    tar_target(
      description = "Calcula desempenho preditivo do modelo com a base de dados de teste (holdoutSet)",
      name = performanceMetrics,
      command = EvaluateModel(
        fileModel = fileModel,
        holdoutSet = holdoutSet
      )
    )
  )
  
  ## Exibicao da etapa de progresso
  # Processo atual
  pipelineName <- "construção do modelo preditivo"  
  cli_progress_step("{cli::style_bold(cli::col_cyan('BuildPipelineModeling'))}: {cli::col_cyan(pipelineName)}")
  
  ## Retorno da lista de targets
  # Retorna list do pipeline
  return(listPipelineModeling)
}
####
## Fim
#
