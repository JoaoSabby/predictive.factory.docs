#' @title Construir o Pipeline de Inferência das Predições
#'
#' @usage
#' BuildPipelinePredicting()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Cria os targets que preparam a feature store de predição e aplicam o modelo ajustado
#' para gerar as predições do horizonte preditivo.
#'
#' @details
#' A predição é aplicada sobre a feature store de predição consolidada por
#' `BuildPipelinePredictingData()`, com o mesmo preprocessamento usado na modelagem
#' (`PrepareDataModel()`), e sobre o arquivo do modelo `fileModel` gerado por
#' `BuildPipelineModeling()`.
#'
#' @section Targets do Pipeline:
#' +---------------------+---------------------------------------------------------------+
#' | Target              | Descrição, comando e dependências                             |
#' +=====================+===============================================================+
#' | `predictionData`    | Preprocessamento dos dados de inferência. Comando:            |
#' |                     | `PrepareDataModel()`. Depende de:                             |
#' |                     | `predictionTable_FEATURE_STORE`.                              |
#' +---------------------+---------------------------------------------------------------+
#' | `predictionResults` | Inferência das predições do horizonte. Comando:               |
#' |                     | `PredictModel()`. Depende de: `fileModel`, `predictionData`.  |
#' +---------------------+---------------------------------------------------------------+
#'
#' A descrição de `predictionResults` informa `idModel` e o intervalo de
#' `dataTargetPredicaoInicial` a `dataTargetPredicaoFinal`.
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(BuildPipelinePredicting, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "BuildPipelinePredicting_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - escreve no console a etapa de progresso do pipeline.
#'
#' @returns Lista invisível com dois objetos `tar_target`.
#'
#' @family Construção do Pipeline
#'
#' @seealso \code{\link{BuildPipeline}}, \code{\link{PrepareDataModel}},
#'   \code{\link{PredictModel}}
#'
#' @references
#' The targets R Package User Manual.
#' \url{https://books.ropensci.org/targets/}
#'
#' @examples
#' \dontrun{
#' listPipelinePredicting <- BuildPipelinePredicting()
#' }
#'
#' @importFrom targets tar_target
#'
#' @export
BuildPipelinePredicting <- function(){
  
  ## Construcao dos targets de inferencia
  # Constroi pipeline
  listPipelinePredicting <- list(  
    tar_target(
      description = "Preprocessamento dos dados para inferência da predição (predictionData)",
      name = predictionData,
      command = PrepareDataModel(
        dataset = predictionTable_FEATURE_STORE
      )
    ),
    tar_target(
      description = glue("Infere predições do modelo {idModel} de {dataTargetPredicaoInicial} até {dataTargetPredicaoFinal}"),
      name = predictionResults,
      command = PredictModel(
        fileModel = fileModel,
        predictionData = predictionData
      )
    )
  )
  
  ## Exibicao da etapa de progresso
  # Processo atual
  pipelineName <- "processamento e geração das predições"  
  cli_progress_step("{cli::style_bold(cli::col_cyan('BuildPipelinePredicting'))}: {cli::col_cyan(pipelineName)}")
  
  ## Retorno da lista de targets
  # Retorna list pipeline 
  return(invisible(listPipelinePredicting))
}
####
##
# 
