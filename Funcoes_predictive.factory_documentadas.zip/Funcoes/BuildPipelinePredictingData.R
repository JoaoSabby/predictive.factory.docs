#' @title Construir o Pipeline de Dados para Predição
#'
#' @usage
#' BuildPipelinePredictingData()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Cria os targets de feature engineering da base de predição: verificação da feature
#' store, definição dos clientes válidos, geração de cada feature group e consolidação na
#' feature store de predição.
#'
#' @details
#' Segue a mesma estrutura de `BuildPipelineHistoricalData()`, com sufixo de tabela
#' `"PREDICAO"` e datas de predição. Os feature groups são descobertos por `ls(pattern =
#' "^GenerateFeatureLineage_IM_ML_")` e mapeados por `tar_map()` em targets
#' `predictionFeatureGroupTable_{GRUPO}`.
#'
#' Diferenças em relação ao pipeline de treino:
#'
#' - a definição dos clientes válidos também usa `tar_skip()` e recebe `featureProcessed =
#'   featureStoreProcessedPredicao`;
#' - os feature groups de predição não definem o controlador `crew` dedicado e usam o
#'   controlador padrão de `_targets.R`;
#' - o target de consolidação não define `deployment = "worker"`;
#' - não há geração de alvo, pois o alvo de predição ainda não é observado.
#'
#' @section Targets do Pipeline:
#' +---------------------------------------+---------------------------------------------+
#' | Target                                | Descrição, comando e dependências           |
#' +=======================================+=============================================+
#' | `featureStoreProcessedPredicao`       | Verifica a feature store de predição.       |
#' |                                       | Comando: `CheckFeatureStore()`. Depende de: |
#' |                                       | `pipelineBegin`.                            |
#' +---------------------------------------+---------------------------------------------+
#' | `tabelaClientesValidosPredicao`       | Define os clientes válidos de predição.     |
#' |                                       | Comando: `DefineValidCustomers()`. Depende  |
#' |                                       | de: `featureStoreProcessedPredicao`.        |
#' +---------------------------------------+---------------------------------------------+
#' | `predictionFeatureGroupTable_{GRUPO}` | Gera cada feature group de predição.        |
#' |                                       | Comando:                                    |
#' |                                       | `GenerateFeatureLineage_IM_ML_{GRUPO}()`.   |
#' |                                       | Depende de:                                 |
#' |                                       | `tabelaClientesValidosPredicao`.            |
#' +---------------------------------------+---------------------------------------------+
#' | `predictionTable_FEATURE_STORE`       | Consolida `IM_ML_FEATURE_STORE_PREDICAO`.   |
#' |                                       | Comando: `Generate_IM_ML_FEATURE_STORE()`.  |
#' |                                       | Depende de: feature groups de predição.     |
#' +---------------------------------------+---------------------------------------------+
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(BuildPipelinePredictingData,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "BuildPipelinePredictingData_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - escreve no console a etapa de progresso do pipeline;
#' - depende dos objetos globais de datas de predição publicados por
#'   `LoadModelRunConfig()`.
#'
#' @returns Lista de objetos `tar_target`, incluindo os targets gerados por `tar_map()`.
#'
#' @family Construção do Pipeline
#'
#' @seealso \code{\link{BuildPipeline}}, \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{BuildPipelinePredicting}}, \code{\link[tarchetypes]{tar_map}}
#'
#' @references
#' tarchetypes: Static branching with tar_map.
#' \url{https://docs.ropensci.org/tarchetypes/reference/tar_map.html}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: funções carregadas e configuração publicada por LoadModelRunConfig()
#' listPipelinePredictingData <- BuildPipelinePredictingData()
#' }
#'
#' @importFrom targets tar_target
#' @importFrom tarchetypes tar_map tar_skip
#'
#' @export
BuildPipelinePredictingData <- function(){
  
  ## Construcao dos targets de dados para predicao
  # Constroi pipeline
  listPipelinePredictingData <- list(
    tar_target(
      description = glue("Verifica se possui ML_FEATURE_STORE para predição na referência {dataFeaturePredicao}"),
      name = featureStoreProcessedPredicao,
      command = CheckFeatureStore(
        pipelineBegin = pipelineBegin,
        dataFeature = dataFeaturePredicao,
        janelaAgregacao = janelaAgregacao,
        janelaHistorico = janelaHistorico
      ),
      deployment = "worker"
    ), 
    tar_skip(
      skip = featureStoreProcessedPredicao,
      description = glue("Definição dos clientes validos para predição na referência {dataFeaturePredicao}"),
      name = tabelaClientesValidosPredicao,
      command = DefineValidCustomers(
        sufixoTabela = "PREDICAO",
        featureProcessed = featureStoreProcessedPredicao,
        janelaAgregacao = janelaAgregacao,
        janelaHistorico = janelaHistorico,
        dataReferencia = dataFeaturePredicao,
        dataAgregacaoInicial = dataFeaturePredicaoAgregacaoInicial,
        dataAgregacaoFinal = dataFeaturePredicaoAgregacaoFinal,
        dataHistoricaInicial = dataFeaturePredicaoHistoricaInicial,
        dataHistoricaFinal = dataFeaturePredicaoHistoricaFinal
      ),
      deployment = "worker"
    ),
    tar_map(
      values = tibble(
        Function = ls(
          pattern = "^GenerateFeatureLineage_IM_ML_",
          sorted = TRUE,
          envir = .GlobalEnv
        ) 
      ) |> 
        mutate(
          FeatureGroup = str_remove(Function, "GenerateFeatureLineage_IM_ML_"),
          Function = rlang::syms(Function),
          Description = glue("Geração do feature group {FeatureGroup} na tabela IM_ML_{FeatureGroup}_PREDICAO")
        ),
      names = FeatureGroup,
      descriptions = Description,
      delimiter = "_",
      tar_skip(
        skip = featureStoreProcessedPredicao,
        name = predictionFeatureGroupTable,
        command = Function(
          sufixoTabela          = "PREDICAO",
          tabelaClientesValidos = tabelaClientesValidosPredicao,
          dataFeature           = dataFeaturePredicao,
          janelaAgregacao       = janelaAgregacao,
          janelaHistorico       = janelaHistorico,
          dataAgregacaoInicial  = dataFeaturePredicaoAgregacaoInicial,
          dataAgregacaoFinal    = dataFeaturePredicaoAgregacaoFinal,
          dataHistoricaInicial  = dataFeaturePredicaoHistoricaInicial,
          dataHistoricaFinal    = dataFeaturePredicaoHistoricaFinal
        ),
        deployment = "worker"
      )
    ),
    tar_skip(
      skip = featureStoreProcessedPredicao,
      description = "Geração da tabela IM_ML_FEATURE_STORE_PREDICAO que consolida os feature groups para predição",
      name = predictionTable_FEATURE_STORE,
      command = Generate_IM_ML_FEATURE_STORE(
        sufixoTabela = "PREDICAO",
        nomesTabelas = list(!!!rlang::syms(
          ls(
            pattern = "^GenerateFeatureLineage_IM_ML_",
            sorted = TRUE,
            envir = .GlobalEnv
          ) |> 
            str_remove("GenerateFeatureLineage_IM_ML_") %>% 
            str_c("predictionFeatureGroupTable_", .)
        )),
        tabelaClientesValidos = tabelaClientesValidosPredicao,
        dataFeature = dataFeaturePredicao,
        janelaAgregacao = janelaAgregacao,
        janelaHistorico = janelaHistorico,
        dataAgregacaoInicial = dataFeaturePredicaoAgregacaoInicial,
        dataAgregacaoFinal = dataFeaturePredicaoAgregacaoFinal,
        dataHistoricaInicial = dataFeaturePredicaoHistoricaInicial,
        dataHistoricaFinal = dataFeaturePredicaoHistoricaFinal
      )
    )
  )
  
  ## Exibicao da etapa de progresso
  # Processo atual
  pipelineName <- "feature engineering dos dados de predição"
  cli_progress_step(
    msg = "{cli::style_bold(cli::col_cyan('BuildPipelinePredictingData'))}: {cli::col_cyan(pipelineName)}"
  )
  
  ## Retorno da lista de targets
  # Retorna list pipeline
  return(listPipelinePredictingData)
}
####
## Fim
#
