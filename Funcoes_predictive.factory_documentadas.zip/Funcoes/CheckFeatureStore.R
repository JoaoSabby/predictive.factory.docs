#' @title Verificar a Existência da Feature Store para o Contexto
#'
#' @usage
#' CheckFeatureStore(
#'   pipelineBegin,
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Consulta a tabela `ML_FEATURE_STORE` para saber se os preditores já foram processados e
#' persistidos para a data de referência e as janelas informadas.
#'
#' @details
#' A busca usa a chave `DATA_REFERENCIA == dataFeature`, `SUMMARY_WINDOW ==
#' janelaAgregacao` e `LANDMARK_WINDOW == janelaHistorico`, traduzida para SQL por
#' `dbplyr` e avaliada por `DbExists()` no banco Oracle.
#'
#' O resultado alimenta o argumento `skip` de `tar_skip()` nos pipelines de dados: quando
#' `TRUE`, a definição dos clientes válidos (em predição), a geração dos feature groups e
#' a consolidação da feature store são ignoradas.
#'
#' O argumento `pipelineBegin` não é usado no corpo da função. Ele existe para criar a
#' dependência entre o target de verificação e o target `pipelineBegin`, que é executado
#' em toda chamada de `tar_make()`. Assim, a verificação é refeita a cada execução.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(CheckFeatureStore, prefix = "##", code = FALSE,
#'   narrow = TRUE), "CheckFeatureStore_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(CheckFeatureStore, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "CheckFeatureStore_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - abre ou reutiliza a conexão com o banco Oracle por meio de `Db()`.
#'
#' @param pipelineBegin Valor do target `pipelineBegin` (lista de metadados de
#'   inicialização). Usado apenas como dependência no grafo do `targets`.
#' @param dataFeature Data de referência dos preditores (`Date` ou texto `"AAAA-MM-DD"`).
#' @param janelaAgregacao Inteiro com o número de meses de sumarização.
#' @param janelaHistorico Inteiro com o número de meses de profundidade histórica.
#'
#' @returns Vetor lógico de comprimento 1: `TRUE` quando já existem registros em
#'   `ML_FEATURE_STORE` para o contexto, `FALSE` caso contrário.
#'
#' @family Feature Store
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{BuildPipelinePredictingData}}, \code{\link[tarchetypes]{tar_skip}}
#'
#' @references
#' Hermann, J., & Del Balso, M. (2017). Meet Michelangelo: Uber's Machine Learning
#' Platform. Uber Engineering Blog.
#' \url{https://www.uber.com/blog/michelangelo-machine-learning-platform/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle disponível
#' featureStoreProcessed <- CheckFeatureStore(
#'   pipelineBegin = list(),
#'   dataFeature = as.Date("2025-10-01"),
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L
#' )
#' }
#'
#' @export
CheckFeatureStore <- function(
    pipelineBegin,
    dataFeature,
    janelaAgregacao,
    janelaHistorico
){
  
  ## Consulta a ML_FEATURE_STORE
  # Verifica se ja processou o pipeline de features na data de referencia
  featureStoreProcessed <- Db("ML_FEATURE_STORE") |> 
    filter(
      (DATA_REFERENCIA  == dataFeature),
      (SUMMARY_WINDOW   == janelaAgregacao),
      (LANDMARK_WINDOW  == janelaHistorico)
    ) |> 
    DbExists()
  
  ## Retorno do indicador de processamento
  # Retorna se ja processou as features para o contexto
  return(featureStoreProcessed)
}
####
## Fim
#
