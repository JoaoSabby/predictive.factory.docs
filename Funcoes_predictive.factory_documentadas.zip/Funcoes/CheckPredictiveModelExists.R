#' @title Verificar a Existência do Modelo Preditivo no Registro
#'
#' @usage
#' CheckPredictiveModelExists(
#'   targetModel,
#'   dataReferencia,
#'   horizontePreditivo,
#'   janelaAgregacao,
#'   janelaHistorico
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Consulta a tabela `ML_MODEL_REGISTRY` para saber se já existe modelo preditivo
#' registrado para a combinação de alvo, data de referência, horizonte e janelas. Quando o
#' modelo existe, exibe no console um resumo com a chave de identificação e as tabelas em
#' que os resultados podem ser consultados.
#'
#' @details
#' A consulta é traduzida para SQL por `dbplyr` e executada no banco Oracle. A chave de
#' busca mapeia os argumentos para as colunas do registro:
#'
#' +----------------------+-------------------------------+
#' | Argumento            | Coluna de `ML_MODEL_REGISTRY` |
#' +======================+===============================+
#' | `dataReferencia`     | `DATA_REFERENCIA`             |
#' +----------------------+-------------------------------+
#' | `janelaHistorico`    | `LANDMARK_WINDOW`             |
#' +----------------------+-------------------------------+
#' | `janelaAgregacao`    | `SUMMARY_WINDOW`              |
#' +----------------------+-------------------------------+
#' | `horizontePreditivo` | `PREDICTION_HORIZON`          |
#' +----------------------+-------------------------------+
#' | `targetModel`        | `TARGET_MODEL`                |
#' +----------------------+-------------------------------+
#'
#' A existência é avaliada por `DbExists()`, sem trazer as linhas para a memória do R.
#' Quando o modelo não existe, a função retorna imediatamente, sem mensagens.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(CheckPredictiveModelExists, prefix = "##", code = FALSE,
#'   narrow = TRUE), "CheckPredictiveModelExists_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(CheckPredictiveModelExists,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "CheckPredictiveModelExists_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - abre ou reutiliza a conexão com o banco Oracle por meio de `Db()`;
#' - quando o modelo existe, escreve no console o status do pipeline, a chave de
#'   identificação e as tabelas `ML_MODEL_PREDICTION` e
#'   `VW_ML_MODEL_ARTIFACT_PERFORMANCE_METRICS`.
#'
#' @param targetModel Vetor de caracteres de comprimento 1 com o nome do alvo de predição,
#'   já em maiúsculas.
#' @param dataReferencia Data de referência da execução (`Date` ou texto `"AAAA-MM-DD"`),
#'   comparada com `DATA_REFERENCIA`.
#' @param horizontePreditivo Inteiro com o número de meses de projeção, comparado com
#'   `PREDICTION_HORIZON`.
#' @param janelaAgregacao Inteiro com o número de meses de sumarização, comparado com
#'   `SUMMARY_WINDOW`.
#' @param janelaHistorico Inteiro com o número de meses de profundidade histórica,
#'   comparado com `LANDMARK_WINDOW`.
#'
#' @returns Vetor lógico de comprimento 1: `TRUE` quando o modelo já está registrado e
#'   `FALSE` caso contrário. O valor é retornado de forma visível.
#'
#' @family Orquestração do Pipeline
#'
#' @seealso \code{\link{RunPipeline}}, \code{\link[dbplyr]{dbplyr-package}}
#'
#' @references
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' cli: Helpers for Developing Command Line Interfaces.
#' \url{https://cli.r-lib.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: ambiente carregado por _Setup.R e conexão Oracle disponível
#' existeModelo <- CheckPredictiveModelExists(
#'   targetModel = "OF_INFLOW_AUTHORISED",
#'   dataReferencia = as.Date("2026-01-01"),
#'   horizontePreditivo = 3L,
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L
#' )
#' }
#'
#' @importFrom cli cli_text cli_rule cli_alert_success cli_h3 cli_bullets
#'
#' @export
CheckPredictiveModelExists <- function(
    targetModel, 
    dataReferencia, 
    horizontePreditivo, 
    janelaAgregacao, 
    janelaHistorico
){
  
  ## Consulta ao registro de modelos
  # Verifica se o modelo ja foi criado (existe)
  existsPredictiveModel <- Db("ML_MODEL_REGISTRY", exibirTabela = FALSE) |> 
    filter(
      DATA_REFERENCIA    == dataReferencia,     # Nesta data de referencia
      LANDMARK_WINDOW    == janelaHistorico,    # para essa janela historica (ex. 36 meses)
      SUMMARY_WINDOW     == janelaAgregacao,    # com sumarizacao dos ultimos meses (ex. 6 meses)
      PREDICTION_HORIZON == horizontePreditivo, # com horizonte preditivo de ate n meses (ex. 3 meses)
      TARGET_MODEL       == targetModel        # Com esse nome de alvo de predicao (ex. OF_INFLOW_AUTHORISED)  
    ) |>
    DbExists()
  
  ## Retorno quando o modelo nao existe
  # Se NAO tem modelo preditivo 
  if(!existsPredictiveModel){
    return(existsPredictiveModel)
  }
  
  ## Exibicao do status do modelo existente
  # Espacamento visual inicial
  cli_text("")
  
  # Espacamento visual inicial no console
  cli_text("")
  
  # Cabecalho de Sucesso com o icone de caixa de arquivo de banco de dados
  cli_rule(
    left = "{.col_green {.strong STATUS DO PIPELINE: CONCLUIDO} 📦}"
  )
  
  # Alerta de sucesso com o icone de "tick" verde nativo do cli
  cli_alert_success("O modelo preditivo ja foi processado e esta pronto para consumo {col_green(symbol$tick)}")
  cli_text("")
  
  # Bloco de Metadados utilizando a identidade visual de "check"
  cli_h3("Chave de Identificacao (Metadados)")
  cli_bullets(c(
    "v" = "Alvo (Target): {.val {targetModel}}",
    "v" = "Data de Referencia: {.val {dataReferencia}}",
    "v" = "Horizonte Preditivo: {.val {horizontePreditivo}} meses",
    "v" = "Janela de Agregacao: {.val {janelaAgregacao}} meses",
    "v" = "Janela Historica: {.val {janelaHistorico}} meses"
  ))
  
  cli_text("")
  
  # Bloco de Persistencia com o icone de banco de dados
  cli_h3("🔗  Rastreabilidade no Banco de Dados Oracle")
  cli_bullets(c(
    "*" = "Predicoes consolidadas em: {.field ML_MODEL_PREDICTION}",
    "*" = "Metricas de desempenho em: {.field VW_ML_MODEL_ARTIFACT_PERFORMANCE_METRICS}"
  ))
  
  # Retorna se encontrou o modelo preditivo
  return(existsPredictiveModel)
}
####
## Fim 
#
