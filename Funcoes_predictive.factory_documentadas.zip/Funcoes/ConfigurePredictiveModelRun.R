#' @title Configurar a Execução do Modelo Preditivo
#'
#' @usage
#' ConfigurePredictiveModelRun(
#'   targetModel,
#'   dataReferencia,
#'   horizontePreditivo,
#'   janelaAgregacao,
#'   janelaHistorico
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Gera o identificador do modelo, cria a estrutura de pastas da execução, calcula todas
#' as datas de treino e de predição a partir da data de referência e das janelas, grava a
#' configuração em YAML e registra o lock de execução.
#'
#' @details
#' O identificador `idModel` segue o padrão `ALVO_AAAAMM_Phh_Aaa_Hhh`, por exemplo
#' `DESERCAO_202601_P03_A06_H36`, com horizonte, agregação e histórico preenchidos com
#' zeros à esquerda até dois dígitos.
#'
#' As datas são derivadas da data de referência \eqn{d} (ajustada ao primeiro dia do mês),
#' do horizonte \eqn{h}, da janela de agregação \eqn{a} e da janela histórica \eqn{H}, em
#' meses. Sendo \eqn{\mathrm{fim}(x)} o último dia do mês de \eqn{x}:
#'
#' +---------------------------------------+-----------------------+
#' | Data                                  | Fórmula               |
#' +=======================================+=======================+
#' | `dataTargetTreino`                    | $d$                   |
#' +---------------------------------------+-----------------------+
#' | `dataTargetTreinoInicial`             | $d - (h - 1)$         |
#' +---------------------------------------+-----------------------+
#' | `dataTargetTreinoFinal`               | $\mathrm{fim}(d)$     |
#' +---------------------------------------+-----------------------+
#' | `dataFeatureTreino` ($f$)             | $d - h$               |
#' +---------------------------------------+-----------------------+
#' | `dataFeatureTreinoAgregacaoInicial`   | $f - (a - 1)$         |
#' +---------------------------------------+-----------------------+
#' | `dataFeatureTreinoHistoricaInicial`   | $f - (H - 1)$         |
#' +---------------------------------------+-----------------------+
#' | `dataFeatureTreino*Final`             | $\mathrm{fim}(f)$     |
#' +---------------------------------------+-----------------------+
#' | `dataFeaturePredicao` ($p$)           | $d$                   |
#' +---------------------------------------+-----------------------+
#' | `dataFeaturePredicaoAgregacaoInicial` | $p - (a - 1)$         |
#' +---------------------------------------+-----------------------+
#' | `dataFeaturePredicaoHistoricaInicial` | $p - (H - 1)$         |
#' +---------------------------------------+-----------------------+
#' | `dataFeaturePredicao*Final`           | $\mathrm{fim}(p)$     |
#' +---------------------------------------+-----------------------+
#' | `dataTargetPredicaoInicial`           | $d + 1$               |
#' +---------------------------------------+-----------------------+
#' | `dataTargetPredicaoFinal`             | $\mathrm{fim}(d + h)$ |
#' +---------------------------------------+-----------------------+
#'
#' Assim, os preditores de treino terminam no mês imediatamente anterior à janela do alvo
#' de treino, o que evita vazamento temporal entre preditores e alvo.
#'
#' A lista retornada também fixa parâmetros operacionais: `nFoldsValidating = 10L`,
#' `nFoldsTuning = 5L`, `nThreadsGenerateFeatureLineage = 4L`,
#' `nThreadsTuneHyperparameters = 6L` e `nThreadsTuning = 5L`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(ConfigurePredictiveModelRun, prefix = "##", code = FALSE,
#'   narrow = TRUE), "ConfigurePredictiveModelRun_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(ConfigurePredictiveModelRun,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "ConfigurePredictiveModelRun_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - cria, quando não existem, a pasta
#'   `{parSys$DirDados}gpc.predictive.factory/Dados/{idModel}` e as subpastas `eda`,
#'   `ema`, `_targets`, `vetiver_board`, `reports`, `artifacts`, `logs`, `logs/telemetry`,
#'   `logs/traces` e `logs/registry`;
#' - grava `_PredictiveModelRunConfig.yaml` na pasta do modelo, sobrescrevendo arquivo
#'   existente;
#' - define a variável de ambiente `GPC_PREDICTIVE_FACTORY_RUN_CONFIG` com `idModel`, lida
#'   depois por `LoadModelRunConfig()`;
#' - cria o lock de execução por meio de `CreateRunLock()`;
#' - depende do objeto global `parSys`, carregado em `_Setup.R`.
#'
#' @param targetModel Vetor de caracteres de comprimento 1 com o nome do alvo de predição,
#'   já validado por `RunPipeline()`.
#' @param dataReferencia Data de referência (`Date` ou texto `"AAAA-MM-DD"`). É convertida
#'   para o primeiro dia do mês por `DataNoPrimeiroDia()`.
#' @param horizontePreditivo Inteiro com o número de meses previstos à frente.
#' @param janelaAgregacao Inteiro com o número de meses de sumarização dos preditores.
#' @param janelaHistorico Inteiro com o número de meses de profundidade histórica.
#'
#' @returns Lista com os elementos `idModel`, `descricao`, `orquestrador`,
#'   `projeto_preditivo`, `funcao_definicao_target`, `configs` (parâmetros da execução),
#'   `datas` (datas em texto `"AAAA-MM-DD"`, conforme a tabela de detalhes) e `paths`
#'   (caminhos das pastas e dos arquivos de configuração `_targets.R`, `.Renviron`,
#'   `.Rprofile` e `Makevars`).
#'
#' @family Orquestração do Pipeline
#'
#' @seealso \code{\link{RunPipeline}}, \code{\link{LoadModelRunConfig}},
#'   \code{\link[lubridate]{months}}, \code{\link[yaml]{write_yaml}}
#'
#' @references
#' Kaufman, S., Rosset, S., Perlich, C., & Stitelman, O. (2012). Leakage in data mining:
#' Formulation, detection, and avoidance. ACM Transactions on Knowledge Discovery from
#' Data, 6(4), 1-21.
#' \url{https://doi.org/10.1145/2382577.2382579}
#'
#' YAML Ain't Markup Language, versão 1.2.
#' \url{https://yaml.org/spec/1.2.2/}
#'
#' lubridate: Make Dealing with Dates a Little Easier.
#' \url{https://lubridate.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: ambiente carregado por _Setup.R (objeto parSys disponível)
#' modelRunConfig <- ConfigurePredictiveModelRun(
#'   targetModel = "DESERCAO",
#'   dataReferencia = as.Date("2026-01-01"),
#'   horizontePreditivo = 3L,
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L
#' )
#' modelRunConfig$datas$dataFeatureTreino
#' }
#'
#' @importFrom lubridate months
#' @importFrom yaml write_yaml
#'
#' @export
ConfigurePredictiveModelRun <- function(
    targetModel,
    dataReferencia,
    horizontePreditivo,
    janelaAgregacao,
    janelaHistorico
){
  
  ## Identificacao do modelo
  # Configuracao que identifica o modelo preditivo (idModel)
  idModel <- str_c(
    targetModel,
    "_",  str_sub(str_remove_all(dataReferencia, "-"), end = 6L),
    "_P", str_pad(horizontePreditivo, width = 2L, pad = "0"),
    "_A", str_pad(janelaAgregacao, width = 2L, pad = "0"),
    "_H", str_pad(janelaHistorico, width = 2L, pad = "0")
  )
  
  #### Definicao dos diretorios ####
  
  ## Criacao da estrutura de pastas
  # Criacao do diretorio base dos resultados 
  modelPath <- file.path(glue::glue("{parSys$DirDados}gpc.predictive.factory/Dados/{idModel}"))
  dir.create(modelPath, recursive = TRUE, showWarnings = FALSE)
  
  # Caminhos das pastas com resultados - EDA
  # Exploratory Data Analysis
  edaPath <- file.path(modelPath, "eda") 
  dir.create(edaPath, recursive = TRUE, showWarnings = FALSE)
  
  # Caminhos das pastas com resultados - xai 
  # Exploratory Model Analysis
  emaPath <- file.path(modelPath, "ema") 
  dir.create(emaPath, recursive = TRUE, showWarnings = FALSE)
  
  # Caminhos das pastas com resultados - _targets
  targetsPath <- file.path(modelPath, "_targets")
  dir.create(targetsPath, recursive = TRUE, showWarnings = FALSE)
  
  # Caminhos das pastas com resultados - vetiver 
  # Version, Share, Deploy, and Monitor Models
  vetiverPath <- file.path(modelPath, "vetiver_board") 
  dir.create(vetiverPath, recursive = TRUE, showWarnings = FALSE)
  
  # Caminhos das pastas com resultados - reports
  reportsPath <- file.path(modelPath, "reports")
  dir.create(reportsPath, recursive = TRUE, showWarnings = FALSE)
  
  # Caminhos das pastas com resultados - artifacts
  artifactsPath <- file.path(modelPath, "artifacts")
  dir.create(artifactsPath, recursive = TRUE, showWarnings = FALSE)
  
  # Caminhos das pastas com resultados - logs
  logsPath <- file.path(modelPath, "logs")
  dir.create(logsPath, recursive = TRUE, showWarnings = FALSE)
  
  # Caminhos das pastas com resultados - logs/telemetry
  logsTelemetryPath <- file.path(modelPath, "logs/telemetry")
  dir.create(logsTelemetryPath, recursive = TRUE, showWarnings = FALSE)
  
  # Caminhos das pastas com resultados - logs/traces
  logsTracesPath <- file.path(modelPath, "logs/traces")
  dir.create(logsTracesPath, recursive = TRUE, showWarnings = FALSE)
  
  # Caminhos das pastas com resultados - logs/registry
  logsRegistryPath <- file.path(modelPath, "logs/registry")
  dir.create(logsRegistryPath, recursive = TRUE, showWarnings = FALSE)
  
  # Penviron para performance/tuning
  scriptPath <- file.path(Sys.getenv("DirProjetos"), "/gpc.predictive.factory/_targets.R")
  
  # Penviron para performance/tuning
  renvironPath <- file.path(Sys.getenv("DirProjetos"), "/gpc.predictive.factory/config/.Renviron")
  
  # Profile para performance/tuning
  rprofilePath <- file.path(Sys.getenv("DirProjetos"), "/gpc.predictive.factory/config/.Rprofile")
  
  # Makevars para performance/tuning
  makevarsPath <- file.path(Sys.getenv("DirProjetos"), "/gpc.predictive.factory/config/Makevars")
  
  #### Definicao das datas ####
  
  ## Calculo das datas de treino e predicao
  # Garante o formato data no primeiro dia do mes
  dataReferencia <- DataNoPrimeiroDia(dataReferencia)
  
  # Data de referencia do target para treino
  dataTargetTreino <- dataReferencia
  
  # Data inicial do horizonte de treino do target 
  dataTargetTreinoInicial <- dataTargetTreino - months((horizontePreditivo - 1L), abbreviate = FALSE)
  
  # Data final do horizonte de treino do target 
  dataTargetTreinoFinal <- DataNoUltimoDia(dataTargetTreino)
  
  # Data de referencia dos preditores para treino
  dataFeatureTreino <- dataTargetTreinoInicial - months(1L, abbreviate = FALSE)
  
  # Data Inicial de treino da agregacao 
  dataFeatureTreinoAgregacaoInicial <- dataFeatureTreino - months((janelaAgregacao - 1L), abbreviate = FALSE)
  
  # Data final de treino da agregacao 
  dataFeatureTreinoAgregacaoFinal <- DataNoUltimoDia(dataFeatureTreino)
  
  # Data inicial de treino para campos que precisamo do historico longo
  dataFeatureTreinoHistoricaInicial <- dataFeatureTreino - months((janelaHistorico - 1L), abbreviate = FALSE)
  
  # Data final de treino para campos que precisamo do historico longo
  dataFeatureTreinoHistoricaFinal <- DataNoUltimoDia(dataFeatureTreino)
  
  # Data de referencia dos preditores para predicao
  dataFeaturePredicao <- dataReferencia
  
  # Data Inicial da agregacao para predicao
  dataFeaturePredicaoAgregacaoInicial <- dataFeaturePredicao - months((janelaAgregacao - 1L), abbreviate = FALSE)
  
  # Data final da agregacao para predicao
  dataFeaturePredicaoAgregacaoFinal <- DataNoUltimoDia(dataFeaturePredicao)
  
  # Data inicial do historico para predicao
  dataFeaturePredicaoHistoricaInicial <- dataFeaturePredicao - months((janelaHistorico - 1L), abbreviate = FALSE)
  
  # Data final do historico para predicao
  dataFeaturePredicaoHistoricaFinal <- DataNoUltimoDia(dataFeaturePredicao)
  
  # Data inicial da predicao
  dataTargetPredicaoInicial <- (dataReferencia + months(1L, abbreviate = FALSE))
  
  # Data final da predicao
  dataTargetPredicaoFinal <- DataNoUltimoDia(dataTargetPredicaoInicial + months((horizontePreditivo - 1L), abbreviate = FALSE))

  ## Montagem da configuracao de execucao
  # Configuracao de execucao do modelo
  modelRunConfig <- list(
    idModel = idModel,
    descricao = glue("Modelo de predicao binaria para {targetModel}"),
    orquestrador = "gpc.predictive.factory",
    projeto_preditivo = basename(getwd()),
    funcao_definicao_target = str_c(basename(getwd()), "/Funcoes/Append_ML_TARGET_", targetModel, ".R"),
    configs = list(
      targetModel = targetModel,
      dataReferencia = as.character(dataReferencia),
      horizontePreditivo = horizontePreditivo,
      janelaAgregacao = janelaAgregacao,
      janelaHistorico = janelaHistorico,
      nFoldsValidating = 10L,
      nFoldsTuning = 5L,
      nThreadsGenerateFeatureLineage = 4L,
      nThreadsTuneHyperparameters = 6L,
      nThreadsTuning = 5L
    ),
    datas = list(
      dataTargetTreino                     = as.character(dataTargetTreino),
      dataTargetTreinoInicial              = as.character(dataTargetTreinoInicial),
      dataTargetTreinoFinal                = as.character(dataTargetTreinoFinal),
      dataFeatureTreino                    = as.character(dataFeatureTreino),
      dataFeatureTreinoAgregacaoInicial    = as.character(dataFeatureTreinoAgregacaoInicial),
      dataFeatureTreinoAgregacaoFinal      = as.character(dataFeatureTreinoAgregacaoFinal),
      dataFeatureTreinoHistoricaInicial    = as.character(dataFeatureTreinoHistoricaInicial),
      dataFeatureTreinoHistoricaFinal      = as.character(dataFeatureTreinoHistoricaFinal),
      dataFeaturePredicao                  = as.character(dataFeaturePredicao),
      dataFeaturePredicaoAgregacaoInicial  = as.character(dataFeaturePredicaoAgregacaoInicial),
      dataFeaturePredicaoAgregacaoFinal    = as.character(dataFeaturePredicaoAgregacaoFinal),
      dataFeaturePredicaoHistoricaInicial  = as.character(dataFeaturePredicaoHistoricaInicial),
      dataFeaturePredicaoHistoricaFinal    = as.character(dataFeaturePredicaoHistoricaFinal),
      dataTargetPredicaoInicial            = as.character(dataTargetPredicaoInicial),
      dataTargetPredicaoFinal              = as.character(dataTargetPredicaoFinal)
    ),
    paths = list(
      modelPath = modelPath,
      edaPath = edaPath,
      targetsPath = targetsPath,
      vetiverPath = vetiverPath,
      emaPath = emaPath,
      reportsPath = reportsPath,
      artifactsPath = artifactsPath,
      logsRegistryPath = logsRegistryPath,
      logsTelemetryPath = logsTelemetryPath,
      logsTracesPath = logsTracesPath,
      scriptPath = scriptPath,
      RenvironPath = renvironPath,
      RprofilePath = rprofilePath,
      MakevarsPath = makevarsPath
    )
  )
  
  ## Gravacao da configuracao e do lock de execucao
  # Salva configuracoes
  yaml::write_yaml(
    modelRunConfig, 
    file.path(modelPath, "_PredictiveModelRunConfig.yaml")
  )
  
  # Configuracao do modelo em execucao
  Sys.setenv(
    GPC_PREDICTIVE_FACTORY_RUN_CONFIG = idModel
  )
  
  # Indica processamento em andamento
  CreateRunLock(modelPath)
  
  cli_alert_success("Definição da configuração dos parâmetros do modelo preditivo")
  
  # Retorna o caminho do modelo
  return(modelRunConfig)
}
####
## Fim
#
