#' @title Consolidar Alvo e Preditores para Modelagem
#'
#' @usage
#' ConsolidateHistoricalData(table_TARGET, modelingTable_FEATURE_STORE)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Une a tabela do alvo e a feature store de treino por `SEQUENCIA_CLIENTE`, traz o
#' resultado para a memória do R e converte o alvo binário em fator com níveis `"Sim"` e
#' `"Nao"`.
#'
#' @details
#' #. executa `inner_join()` no Oracle entre `table_TARGET` e
#'    `modelingTable_FEATURE_STORE`; clientes sem alvo ou sem preditores são descartados;
#' #. define as features como todas as colunas exceto `TARGET` e as colunas de contexto da
#'    opção `predy_columns_key_context`, em ordem alfabética;
#' #. seleciona `TARGET` e as features, removendo as colunas de contexto, e coleta o
#'    resultado com `collect()`;
#' #. converte `TARGET`: o valor `1` vira `"Sim"` e qualquer outro valor vira `"Nao"`,
#'    como fator não ordenado com níveis `c("Sim", "Nao")`.
#'
#' O primeiro nível `"Sim"` é tratado como classe positiva pelas funções de modelagem e de
#' métricas do projeto.
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Valores Ausentes no Alvo:**
#' `ifelse(TARGET == 1L, "Sim", "Nao")` retorna `NA` quando `TARGET` é nulo. Esses
#' registros permanecem na base com alvo ausente.
#' :::
#'
#' A variável local `colunasContexto` é calculada, mas não é usada.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(ConsolidateHistoricalData, prefix = "##", code = FALSE,
#'   narrow = TRUE), "ConsolidateHistoricalData_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(ConsolidateHistoricalData, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "ConsolidateHistoricalData_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - transfere a base consolidada do Oracle para a memória do R;
#' - escreve no console as etapas de progresso.
#'
#' @param table_TARGET Vetor de caracteres de comprimento 1 com o nome da tabela do alvo,
#'   que deve conter `SEQUENCIA_CLIENTE` e `TARGET` codificado como `1` para a classe
#'   positiva.
#' @param modelingTable_FEATURE_STORE Vetor de caracteres de comprimento 1 com o nome da
#'   feature store de treino (`IM_ML_FEATURE_STORE_TREINO`).
#'
#' @returns Tibble em memória com a coluna `TARGET` (fator com níveis `"Sim"` e `"Nao"`)
#'   seguida das features em ordem alfabética, sem as colunas de contexto.
#'
#' @family Feature Store
#'
#' @seealso \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{PrepareDataModel}},
#'   \code{\link{BuildPipelineHistoricalData}}
#'
#' @references
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' yardstick: event_level e a classe positiva em métricas binárias.
#' \url{https://yardstick.tidymodels.org/articles/metric-types.html}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: tabelas do alvo e da feature store criadas no Oracle
#' historicalData <- ConsolidateHistoricalData(
#'   table_TARGET = "IM_ML_TARGET_TREINO",
#'   modelingTable_FEATURE_STORE = "IM_ML_FEATURE_STORE_TREINO"
#' )
#' }
#'
#' @export
ConsolidateHistoricalData <- function(
    table_TARGET,
    modelingTable_FEATURE_STORE
){
    
  ## Inicio da etapa de progresso
  # Inicio do processo
  processID <- cli_progress_step(
    msg = "Consolidação do {.strong TARGET} com as {.strong FEATURES}",
    msg_done = "Processo de preparação dos dados para treino concluído",
    msg_failed = "Falha na função ConsolidateHistoricalData"
  )
  
  ## Juncao do alvo com a feature store
  # Prepara dados para treino do modelo
  historicalData <- Db(table_TARGET) |> 
    inner_join(
      Db(modelingTable_FEATURE_STORE),
      by = "SEQUENCIA_CLIENTE"
    )
  
  ## Definicao das features
  # Busca nome das features
  features <- sort(setdiff(colnames(historicalData), c("TARGET", opt("predy_columns_key_context"))))
  colunasContexto <- opt("predy_columns_key_context")
  
  ## Coleta e conversao do alvo
  # Ajusta colunas e coleta resultado
  cli_progress_step("Converte TARGET para factor Sim/Nao")
  historicalData <- historicalData |> 
    select(
      TARGET, !!features
    ) |> 
    collect() |> 
    mutate(
      TARGET = ifelse(
        test = (TARGET == 1L),
        yes = "Sim",
        no = "Nao"
      ) |> 
        factor(
          levels = c(
            "Sim", "Nao"
          ),
          ordered = FALSE
        )
    )
  
  cli_progress_done(processID)
  
  ## Retorno dos dados historicos
  # Retorna dados para modelagem preditiva
  return(historicalData)  
}
####
## Fim
#
