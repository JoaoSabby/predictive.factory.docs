#' @title Consolidar a Feature Store de Predição em Memória
#'
#' @usage
#' ConsolidatePredictionData(table_FEATURE_STORE)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Lê a feature store de predição do Oracle, seleciona as colunas de contexto e as
#' features em ordem alfabética e aplica o preprocessamento dos dados.
#'
#' @details
#' ::: {.callout-important}
#' <i class="fa-solid fa-circle-exclamation"></i> **Função Fora do Pipeline:**
#' A função não é chamada por nenhum pipeline: `BuildPipelinePredicting()` aplica
#' `PrepareDataModel()` diretamente sobre `predictionTable_FEATURE_STORE`. Além disso,
#' `PreprocessData()` não está definida em nenhum projeto do repositório, e a chamada
#' termina com erro.
#' :::
#'
#' As features são todas as colunas da tabela, em ordem alfabética; as colunas de contexto
#' da opção `predy_columns_key_context` também fazem parte dessa lista e são posicionadas
#' no início.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(ConsolidatePredictionData, prefix = "##", code = FALSE,
#'   narrow = TRUE), "ConsolidatePredictionData_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(ConsolidatePredictionData, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "ConsolidatePredictionData_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - transfere a feature store do Oracle para a memória do R;
#' - escreve no console as etapas de progresso.
#'
#' @param table_FEATURE_STORE Vetor de caracteres de comprimento 1 com o nome da feature
#'   store de predição (`IM_ML_FEATURE_STORE_PREDICAO`).
#'
#' @returns Tibble invisível com os dados preprocessados para predição.
#'
#' @family Feature Store
#'
#' @seealso \code{\link{PrepareDataModel}}, \code{\link{BuildPipelinePredicting}}
#'
#' @references
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Requer a definição de PreprocessData()
#' predictionData <- ConsolidatePredictionData(
#'   table_FEATURE_STORE = "IM_ML_FEATURE_STORE_PREDICAO"
#' )
#' }
#'
#' @export
ConsolidatePredictionData <- function(
    table_FEATURE_STORE
){
  
  ## Inicio da etapa de progresso
  idProcess <- cli_progress_step(
    msg = "Preparação dos dados para predição",
    msg_done = "Processo de preparação dos dados para predição concluído",
    msg_failed = "Falha na função {.fn ConsolidatePredictionData}"
  )
  
  ## Definicao das colunas
  # Busca nome das colunas
  features <- sort(colnames(Db(table_FEATURE_STORE, exibirTabela = FALSE)))
  
  ## Coleta e preprocessamento
  # Prepara dados para predicao
  predictionData <- Db(table_FEATURE_STORE, exibirTabela = FALSE) |> 
    collect() |> 
    select(
      any_of(opt("predy_columns_key_context")), !!features
    ) |> 
    PreprocessData()
  
  cli_progress_done(idProcess)
  
  ## Retorno dos dados de predicao
  # Retorna os dados para predicao
  return(invisible(predictionData))
}
####
## Fim
# 
