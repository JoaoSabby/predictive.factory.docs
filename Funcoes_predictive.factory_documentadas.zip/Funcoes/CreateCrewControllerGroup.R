#' @title Criar o Grupo de Controladores de Paralelismo crew
#'
#' @usage
#' CreateCrewControllerGroup()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Cria o grupo de controladores `crew` usado pelo pipeline `targets`: um controlador de
#' contingência com um worker e um controlador dedicado à geração dos feature groups.
#'
#' @details
#' O grupo contém dois controladores criados por `CreateCrewController()`:
#'
#' +--------------------------+--------------------------+-------------------------------+
#' | Controlador              | Workers                  | Uso                           |
#' +==========================+==========================+===============================+
#' | `Fallback`               | 1                        | Contingência                  |
#' +--------------------------+--------------------------+-------------------------------+
#' | `GenerateFeatureLineage` | $\min(6,                 | Targets                       |
#' |                          | \text{threads\_limit})$  | `GenerateFeatureLineage_*`    |
#' +--------------------------+--------------------------+-------------------------------+
#'
#' O controlador `GenerateFeatureLineage` usa `Fallback` como `backup`. A opção
#' `threads_limit` é lida com `getOption()`, sem prefixo `predy_`. O grupo é passado a
#' `tar_option_set(controller = ...)` em `_targets.R`, e os targets são associados ao
#' controlador por `tar_resources_crew(controller = "GenerateFeatureLineage")`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(CreateCrewControllerGroup, prefix = "##", code = FALSE,
#'   narrow = TRUE), "CreateCrewControllerGroup_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(CreateCrewControllerGroup, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "CreateCrewControllerGroup_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @returns Objeto `crew_class_controller_group` com os controladores `Fallback` e
#'   `GenerateFeatureLineage`.
#'
#' @family Orquestração do Pipeline
#'
#' @seealso \code{\link[crew]{crew_controller_group}},
#'   \code{\link{BuildPipelineHistoricalData}}
#'
#' @references
#' Landau, W. M. crew: A Distributed Worker Launcher Framework.
#' \url{https://wlandau.github.io/crew/}
#'
#' The targets R Package User Manual: Distributed computing.
#' \url{https://books.ropensci.org/targets/crew.html}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: opção threads_limit definida
#' crewControllerGroup <- CreateCrewControllerGroup()
#' targets::tar_option_set(controller = crewControllerGroup)
#' }
#'
#' @importFrom crew crew_controller_group
#'
#' @export
CreateCrewControllerGroup <- function(){
  
  ## Criacao do controlador de contingencia
  # Controller crew para excecao
  crewControllerFallback <- CreateCrewController(
    name = "Fallback",
    workers = 1L
  ) 
  
  ## Criacao do controlador de feature groups
  # Controller crew para funcoes GenerateFeatureLineage*
  crewControllerGenerateFeatureLineage <- CreateCrewController(
    name = "GenerateFeatureLineage",
    workers = min(6L, getOption("threads_limit")),
    backup = crewControllerFallback
  )

  ## Montagem do grupo de controladores
  # Monta controller group
  crewControllerGroup <- crew_controller_group(
    crewControllerFallback,
    crewControllerGenerateFeatureLineage
  )
  
  # Retorna controller group de paralelismo com crew
  return(crewControllerGroup)
}
####
## Fim
# 
