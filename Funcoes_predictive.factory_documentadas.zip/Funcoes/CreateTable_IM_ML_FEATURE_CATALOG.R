#' @title Criar a Tabela do Catálogo de Features
#'
#' @usage
#' CreateTable_IM_ML_FEATURE_CATALOG()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Cria no Oracle a tabela in-memory `IM_ML_FEATURE_CATALOG`, destinada a catalogar o
#' escopo, o tipo e o nome de cada feature, quando a tabela ainda não existe.
#'
#' @details
#' A tabela prevista tem três colunas:
#'
#' +-----------------+-----------------+-------------------------------------------------+
#' | Coluna          | Tipo            | Conteúdo                                        |
#' +=================+=================+=================================================+
#' | `FEATURE_SCOPE` | `VARCHAR2(30    | Escopo: global (`FACTORY`) ou local             |
#' |                 | CHAR)`          | (`DESERCAO`, `OF_INFLOW`, `OF_OUTFLOW`)         |
#' +-----------------+-----------------+-------------------------------------------------+
#' | `FEATURE_TYPE`  | `CHAR(1)`       | Tipo: `B` binária, `I` inteira, `C` contínua,   |
#' |                 |                 | `E` enumerada, `T` texto                        |
#' +-----------------+-----------------+-------------------------------------------------+
#' | `FEATURE_NAME`  | `VARCHAR2(30    | Nome da variável                                |
#' |                 | CHAR)`          |                                                 |
#' +-----------------+-----------------+-------------------------------------------------+
#'
#' As opções de armazenamento são `NOLOGGING`, `PCTFREE 0`, `COMPRESS BASIC`, `INMEMORY
#' PRIORITY CRITICAL`, `MEMCOMPRESS FOR QUERY HIGH` e `CLUSTERING BY LINEAR ORDER
#' (FEATURE_SCOPE, FEATURE_TYPE)`.
#'
#' ::: {.callout-important}
#' <i class="fa-solid fa-circle-exclamation"></i> **Instrução DDL Inválida:**
#' A instrução `CREATE TABLE` contém vírgula após a última coluna (`FEATURE_NAME`), o que
#' o Oracle rejeita como erro de sintaxe. Nesse caso, a função interrompe a execução com a
#' mensagem `ERRO FATAL ao criar tabela IM_ML_FEATURE_CATALOG`. A função não é chamada por
#' nenhum pipeline do projeto.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(CreateTable_IM_ML_FEATURE_CATALOG, prefix = "##", code = FALSE,
#'   narrow = TRUE), "CreateTable_IM_ML_FEATURE_CATALOG_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(CreateTable_IM_ML_FEATURE_CATALOG,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "CreateTable_IM_ML_FEATURE_CATALOG_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - executa `CREATE TABLE IM_ML_FEATURE_CATALOG` no Oracle quando a tabela não existe.
#'
#' @returns `TRUE` invisível, tanto quando a tabela já existe quanto após a criação.
#'
#' @family Feature Store
#'
#' @seealso \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link[DBI]{dbExecute}}
#'
#' @references
#' Oracle Database SQL Language Reference, seção CREATE TABLE.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/sqlrf/}
#'
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle com permissão de criação de tabelas
#' CreateTable_IM_ML_FEATURE_CATALOG()
#' }
#'
#' @importFrom DBI dbExecute
#'
#' @export
CreateTable_IM_ML_FEATURE_CATALOG <- function(){

  ## Verificacao da existencia do catalogo
  # Se o catalogo existe
  existCatalog <- Db("IM_ML_FEATURE_CATALOG") |> 
    DbExists()
  
  # Se nao existe
  if(existCatalog){
    return(invisible(TRUE))
  }
  
  ## Montagem da instrucao DDL
  # Monta query de criacao da tabela in-memory otimizada
  queryCreate <- glue("
    CREATE TABLE IM_ML_FEATURE_CATALOG(
      -- Escopo (Ex: Global: 'FACTORY', Local: 'DESERCAO', 'OF_INFLOW', 'OF_OUTFLOW')
      FEATURE_SCOPE       VARCHAR2(30 CHAR) NOT NULL,
      -- Tipagem (B: Binari, I: Integer, C: Continuous, E: Enumerate, T: Text)
      FEATURE_TYPE        CHAR(1) NOT NULL,
      -- Nomes da variavel
      FEATURE_NAME        VARCHAR2(30 CHAR) NOT NULL,
    )
      NOLOGGING
      PCTFREE 0
      NOPARALLEL
      COMPRESS BASIC
      INMEMORY PRIORITY CRITICAL
      MEMCOMPRESS FOR QUERY HIGH  
      CLUSTERING BY LINEAR ORDER (FEATURE_SCOPE, FEATURE_TYPE)
  ")
  
  ## Criacao da tabela no Oracle
  # Cria tabela e persiste os dados em memoria
  tryCatch(
    expr = dbExecute(
      conn = ConexaoDB(), 
      statement = queryCreate
    ), 
    error = function(e){
      stop(str_c("ERRO FATAL ao criar tabela IM_ML_FEATURE_CATALOG:\n", e$message))
    }
  )
    
  ## Retorno invisivel
  # Funcao se retorno visivel
  return(invisible(TRUE))
}
####
## Fim
# 
