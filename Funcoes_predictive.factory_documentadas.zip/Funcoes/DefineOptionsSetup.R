#' @title Definir as Opções de Configuração do Predictive Factory
#'
#' @usage
#' DefineOptionsSetup()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Registra, com o pacote `options`, as 13 opções `predy_*` que parametrizam o motor de
#' modelagem, o tuning, os limites de threads, as colunas de contexto, a seleção de
#' features, a divisão treino e teste e o balanceamento de classes.
#'
#' @details
#' Cada opção é registrada por `options::define_option()` com valor padrão, descrição,
#' nome de opção igual ao nome da opção e variável de ambiente `R_{OPCAO}` em maiúsculas.
#' A ordem de precedência do pacote `options` permite sobrescrever o padrão pela opção da
#' sessão ou pela variável de ambiente.
#'
#' +--------------------------------------------+----------------------------------------+
#' | Opção                                      | Valor padrão                           |
#' +============================================+========================================+
#' | `predy_engine_model`                       | `"xgboost"`                            |
#' +--------------------------------------------+----------------------------------------+
#' | `predy_engine_model_xgboost`               | `list(max_trees = 3000L,               |
#' |                                            | max_delta_step = 1L, stop_iter = 50L,  |
#' |                                            | reg_alpha = 0.5)`                      |
#' +--------------------------------------------+----------------------------------------+
#' | `predy_tune_num_folds`                     | `5L`                                   |
#' +--------------------------------------------+----------------------------------------+
#' | `predy_positive_class_threshold`           | `0.5`                                  |
#' +--------------------------------------------+----------------------------------------+
#' | `predy_threads_limit`                      | `getOption("threads_limit")`           |
#' +--------------------------------------------+----------------------------------------+
#' | `predy_tune_debug`                         | `FALSE`                                |
#' +--------------------------------------------+----------------------------------------+
#' | `predy_tune_threads_outer`                 | `2L`                                   |
#' +--------------------------------------------+----------------------------------------+
#' | `predy_tune_threads_inner`                 | \eqn{\lfloor (\text{threads} - 2) /    |
#' |                                            | \text{folds} \rfloor}                  |
#' +--------------------------------------------+----------------------------------------+
#' | `predy_columns_key_context`                | `SEQUENCIA_CLIENTE`,                   |
#' |                                            | `DATA_REFERENCIA_TARGET`,              |
#' |                                            | `DATA_REFERENCIA_FEATURE`,             |
#' |                                            | `HORIZONTE_PREDITIVO`,                 |
#' |                                            | `JANELA_AGREGACAO`, `JANELA_HISTORICO` |
#' +--------------------------------------------+----------------------------------------+
#' | `predy_features_modal_frequency_threshold` | `0.995`                                |
#' +--------------------------------------------+----------------------------------------+
#' | `predy_features_correlation_threshold`     | `0.995`                                |
#' +--------------------------------------------+----------------------------------------+
#' | `predy_training_set_prop`                  | `0.90`                                 |
#' +--------------------------------------------+----------------------------------------+
#' | `predy_balance_class`                      | `list(method = "random_under",         |
#' |                                            | adasyn_k = 7L, adasyn_ratio = 0.2,     |
#' |                                            | nearmiss_k = 3L, nearmiss_ratio = 10L, |
#' |                                            | under_sampling = 10L)`                 |
#' +--------------------------------------------+----------------------------------------+
#'
#' O valor padrão de `predy_tune_threads_inner` é calculado no momento do registro, a
#' partir dos valores correntes de `predy_threads_limit` e `predy_tune_num_folds`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(DefineOptionsSetup, prefix = "##", code = FALSE,
#'   narrow = TRUE), "DefineOptionsSetup_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(DefineOptionsSetup, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "DefineOptionsSetup_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - carrega os pacotes `options` e `pacman` por `pacman::p_load()`;
#' - registra as definições de opções no ambiente global (`envir = .GlobalEnv`).
#'
#' @returns `NULL` invisível.
#'
#' @family Orquestração do Pipeline
#'
#' @seealso \code{\link{LoadModelRunConfig}}, \code{\link[options]{define_option}},
#'   \code{\link[options]{opt}}
#'
#' @references
#' options: Simple, Consistent Package Options.
#' \url{https://dgkf.github.io/options/}
#'
#' @examples
#' \dontrun{
#' DefineOptionsSetup()
#' options::opt("predy_engine_model")
#' }
#'
#' @importFrom options define_option opt
#'
#' @export
DefineOptionsSetup <- function(){
  
  ## Carga do pacote options
  # Carrega options
  pacman::p_load(options, pacman)
  
  ## Opcoes do motor de modelagem
  # Engine de Modelagem
  optionName <- "predy_engine_model"
  define_option(
    option = optionName,
    default = "xgboost",
    desc = paste(
      "Motor de inferência utilizado no pipeline de modelagem preditiva.\n",
      "Tipagem: character.\n\n",
      "Valores válidos:\n",
      "* **xgboost**: Otimizado para expansão de árvores por histogramas com forte ",
      "regularização $L1$ e $L2$ para mitigação de sobreajuste.\n",
      "* **lightgbm**: Maximiza a velocidade em grandes bases utilizando crescimento ",
      "folha a folha (leaf-wise) e amostragem baseada em gradiente (GOSS).\n",
      "* **catboost**: Especializado no processamento nativo de variáveis categóricas ",
      "via estatísticas de alvo ordenadas e uso de árvores simétricas alheias.\n"
    ),
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  # Engine de Modelagem - XGBoost
  optionName <- "predy_engine_model_xgboost"
  define_option(
    option = optionName,
    default = list(
      max_trees = 3000L,
      max_delta_step = 1L,
      stop_iter = 50L,
      reg_alpha = 0.5
    ),
    desc = strwrap(
      paste0(
        "**max_trees**\n\n",
        "Número máximo de árvores (nrounds) para o treinamento do XGBoost.",
        "Tipagem: integer. Intervalo técnico: \\eqn{[100, 20000]}.\n",
        "O XGBoost minimiza a função objetivo regularizada:",
        "\\deqn{\\mathcal{L}^{(t)} = \\sum_{i=1}^n l(y_i, \\hat{y}_i^{(t-1)} + f_t(x_i)) + \\Omega(f_t)}\n",
        "Este parâmetro define o limite superior para \\eqn{K} iterações aditivas.",
        "Valores elevados aumentam a capacidade do modelo, mas elevam exponencialmente",
        "o risco de overfitting sem a devida regularização.\n\n",
        
        "**max_delta_step**\n\n",
        "Parâmetro de regularização \\eqn{max\\_delta\\_step}.\n",
        "Tipagem: integer. Intervalo técnico: \\eqn{[0, 10]}\n",
        "Define o passo máximo permitido para a atualização do peso de cada nó folha.\n",
        "\\deqn{w_j = \\min(max\\_delta\\_step, |w_j|)}\n",
        "Em cenários de classes desbalanceadas, onde a logística frequentemente",
        "diverge, um valor \\eqn{max\\_delta\\_step > 0} atua como uma trava conservadora",
        "para a estabilidade da atualização dos pesos.\n\n",
        
        "**stop_iter**\n\n",
        "Limiar de iterações para parada prematura (early stopping).\n",
        "Tipagem: integer. Intervalo técnico: \\eqn{[1, 500]}.\n",
        "Interrompe o processo iterativo se a métrica de avaliação não apresentar ganho",
        "após 'stop_iter' rodadas consecutivas.\n",
        "\\deqn{\\text{Se } \\mathcal{M}^{(t)} \\leq \\mathcal{M}^{(t-stop\\_iter)} \\implies \\text{Stop}}\n",
        "Valores muito baixos podem causar interrupção prematura em modelos que",
        "necessitam de mais tempo para ajustar variações de baixa frequência.\n\n",
        
        "**reg_alpha**\n\n",
        "Controla o hiperparâmetro `reg_alpha` do XGBoost, também aceito pela ",
        "API como alias `alpha`. O parâmetro define o termo de regularização L1 ",
        "aplicado aos pesos do modelo. Em boosters baseados em árvores, esses ",
        "pesos correspondem aos escores estimados nas folhas; no booster linear, ",
        "correspondem aos coeficientes do modelo linear regularizado.",
        "\n\n",
        "A regularização L1 adiciona uma penalização proporcional ao valor absoluto ",
        "dos pesos, favorecendo soluções mais esparsas e reduzindo a magnitude dos ",
        "ajustes locais. Aumentar `reg_alpha` torna o modelo mais conservador, pois ",
        "eleva o custo de manter pesos diferentes de zero. Isso pode reduzir ",
        "overfitting, melhorar generalização e simplificar a estrutura efetiva do ",
        "modelo, mas valores excessivos podem induzir underfitting.",
        "\n\n",
        "Tipagem: numeric escalar, armazenado como double.",
        "\n\n",
        "Valor padrão: `0`, conforme a documentação oficial do XGBoost.",
        "\n\n",
        "Intervalo técnico admissível: \\eqn{[0, \\infty)}.",
        "\n\n",
        "O intervalo é semiaberto: inclui `0` e todos os valores reais finitos ",
        "maiores que zero. Embora a documentação matemática use \\eqn{\\infty} ",
        "como limite superior teórico, esta option bloqueia valores infinitos por ",
        "segurança operacional, compatibilidade com serialização e previsibilidade ",
        "da validação em pipelines automatizados.",
        "\n\n",
        "Unidade de medida: adimensional. O valor atua como coeficiente de penalização ",
        "na função objetivo regularizada.",
        "\n\n",
        "\\deqn{\\Omega(w) = \\alpha \\sum_j |w_j|}",
        "\n\n",
        "Onde \\eqn{\\alpha} representa `reg_alpha` e \\eqn{w_j} representa pesos ",
        "estimados pelo booster. Para o booster linear, a documentação oficial indica ",
        "que o termo é normalizado pelo número de observações de treinamento.",
        "\n\n",
        "| Faixa | Interpretação técnica | Risco operacional |",
        "\n",
        "|---|---|---|",
        "\n",
        "| `0` | Sem regularização L1 explícita. | Maior risco de overfitting quando ",
        "há muitas variáveis, ruído ou alta cardinalidade em dummies. |",
        "\n",
        "| `(0, 1]` | Penalização L1 leve a moderada. | Pode melhorar generalização, ",
        "mas ainda requer validação cruzada para calibração. |",
        "\n",
        "| `(1, 10]` | Penalização L1 forte. | Pode reduzir variância e esparsificar ",
        "pesos, mas aumenta risco de underfitting. |",
        "\n",
        "| `> 10` | Penalização L1 muito forte. | Deve ser usada apenas quando ",
        "justificada por validação, pois pode degradar sensibilidade, calibração e ",
        "capacidade preditiva. |",
        "\n\n",
        "Valores baixos reduzem a pressão de regularização e preservam maior liberdade ",
        "para o modelo ajustar pesos. Valores altos aumentam a penalização, reduzem a ",
        "complexidade efetiva e podem eliminar contribuições marginais. Valores ",
        "negativos são inválidos porque inverteriam o sentido da penalização. `NA`, ",
        "`NaN`, `Inf`, strings vazias, vetores com comprimento diferente de um e ",
        "conversões ambíguas são bloqueados antes da gravação da option.",
        "\n\n",
        "Impactos esperados: afeta diretamente regularização, qualidade estatística, ",
        "risco de overfitting, esparsidade e convergência do processo de otimização. ",
        "O parâmetro não controla paralelismo nem consumo de memória de forma direta, ",
        "mas pode reduzir a complexidade efetiva do modelo ajustado. A reprodutibilidade ",
        "continua dependendo de seed, particionamento, paralelismo do XGBoost e demais ",
        "hiperparâmetros do treinamento.",
        "\n\n",
        "Referência oficial: \n",
        "[XGBoost Parameters, alpha/reg_alpha]",
        "(https://xgboost.readthedocs.io/en/latest/tmp/r_docs/R-package/docs/reference/xgb.params.html)."
      )  
    ),  
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  ## Opcoes de tuning e de threads
  # Quantidade de folds no processo de tuning hyparameters
  optionName <- "predy_tune_num_folds"
  define_option(
    option = optionName,
    default = 5L,
    desc = paste(
      "Quantidade de folds para apuração da média de desempenho no processo de uma iteração de tuning hyparameters",
      "Tipagem: integer. Intervalo técnico: \\eqn{[2, 10]}.",
      sep = "\n"
    ),
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  # Limite de propabilidade para definição da classe positiva
  optionName <- "predy_positive_class_threshold"
  define_option(
    option = "predy_positive_class_threshold",
    default = 0.5,
    desc = "Limite de propabilidade para definição da classe positiva",
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  # Limite maximo de threads 
  optionName <- "predy_threads_limit"
  define_option(
    option = optionName,
    default = getOption("threads_limit"),
    desc = "Limite total de threads disponível",
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  # Define se faz debug 
  optionName <- "predy_tune_debug"
  define_option(
    option = optionName,
    default = FALSE,
    desc = "Indica que deve gerar log de debug log/ufrgs/gpc.predictive.factory/TuneModel.log",
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  # Limite maximo de threads no nivel externo
  optionName <- "predy_tune_threads_outer"
  define_option(
    option = optionName,
    default = 2L,
    desc = "Quantidade de threads máxima no nível externo do paralelismo aninhado para o processamento de otimização de hiperparâmetros.",
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  # Limite maximo de threads no nivel interno
  optionName <- "predy_tune_threads_inner"
  define_option(
    option = optionName,
    default = as.integer(floor((opt("predy_threads_limit") - 2L)  / opt("predy_tune_num_folds"))),
    desc = "Quantidade de threads máxima no nível interno do paralelismo aninhado para o processamento de otimização de hiperparâmetros.",
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  ## Opcoes de colunas e de selecao de features
  # Colunas de contexto
  optionName <- "predy_columns_key_context"
  define_option(
    option = optionName,
    default = c(
      "SEQUENCIA_CLIENTE", 
      "DATA_REFERENCIA_TARGET", "DATA_REFERENCIA_FEATURE", 
      "HORIZONTE_PREDITIVO", "JANELA_AGREGACAO", "JANELA_HISTORICO"
    ),
    desc = strwrap(
      paste0(
        "Além da variável dependente (*TARGET*) e das *features* utilizadas como preditores,",
        "a a base de dados contém um terceiro grupo de colunas denominadas **colunas chave e contexto**.",
        "Essas colunas não participam diretamente do processo de estimação do modelo —",
        "não são fornecidas como entrada ao algoritmo de aprendizado nem constituem o",
        "evento que se deseja predizer. Sua função é identificar e qualificar cada",
        "observação dentro do contexto operacional e temporal em que foi gerada.\n\n",
        
        "As colunas de contexto respondem a perguntas do tipo: *quem* é o sujeito da",
        "observação, *quando* as *features* foram mensuradas, *quando* o *target* foi",
        "observado e *qual* a configuração temporal da janela de modelagem utilizada.",
        "Dessa forma, uma mesma entidade pode aparecer múltiplas vezes na ABT sob",
        "diferentes configurações de contexto — por exemplo, distintas safras ou",
        "horizontes preditivos —, e as colunas de contexto são o que permite",
        "distinguir e rastrear essas ocorrências.\n\n",
        
        "No presente projeto, as colunas de contexto são:\n\n",
        
        "- **`SEQUENCIA_CLIENTE`**: identificador único do sujeito de modelagem;  \n",
        "- **`DATA_REFERENCIA_TARGET`**: data de referência utilizada para construção do *target*;  \n",
        "- **`DATA_REFERENCIA_FEATURE`**: data de referência a partir da qual as *features* foram calculadas;  \n",
        "- **`HORIZONTE_PREDITIVO`**: intervalo de tempo entre a observação das *features* e o evento-alvo;  \n",
        "- **`JANELA_AGREGACAO`**: período utilizado para agregação temporal das *features*;  \n",
        "- **`JANELA_HISTORICO`**: extensão do histórico retrospectivo considerado no cálculo das *features*.  \n",
        
        "Essas colunas são preservadas para fins de rastreabilidade,",
        "estratificação de amostras, validação temporal e auditoria dos resultados preditivos,",
        "sendo removidas do conjunto de entrada do modelo antes do treinamento."
      )
    ),  
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  # Definicao threshold para frequencia modal
  optionName <- "predy_features_modal_frequency_threshold"
  define_option(
    option = optionName,
    default = 0.995,
    desc = strwrap(
      paste0(
        "Variáveis com distribuição excessivamente concentrada em um único valor ",
        "carregam informação preditiva negligenciável, pois apresentam variância ",
        "próxima de zero e não contribuem para a discriminação entre observações. ",
        "Para identificar e remover essas variáveis, utiliza-se o critério de ",
        "**frequência modal** (*modal frequency*), definido como a proporção de ",
        "observações que assumem o valor mais frequente da variável:\n\n",
        "$$\n",
        "\\text{modal\\_frequency}(X_j) = \\frac{\\max_k \\, \\#\\{x_i = k\\}}{n}\n",
        "$$\n\n",
        "onde $n$ é o número total de observações e ",
        "$\\max_k \\, \\#\\{x_i = k\\}$ é a contagem do valor modal da variável $X_j$. ",
        "Uma variável é removida quando:\n\n",
        "$$\n",
        "\\text{modal\\_frequency}(X_j) \\geq \\tau_{\\text{mf}} = 0{,}99\n",
        "$$\n\n",
        "Ou seja, variáveis nas quais 99% ou mais das observações compartilham o ",
        "mesmo valor — incluindo variáveis binárias com predominância de zeros ",
        "(*zero-inflated*) — são excluídas do conjunto de preditores. Esse critério ",
        "é agnóstico ao tipo de variável, aplicando-se igualmente a *features* ",
        "numéricas, categóricas e indicadoras binárias geradas por codificação ",
        "*one-hot*."
      )
    ),  
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  # Definicao threshold para correlacao entre features
  optionName <- "predy_features_correlation_threshold"
  define_option(
    option = optionName,
    default = 0.995,
    desc = strwrap(
      paste0(
        "A presença de pares de variáveis altamente correlacionadas introduz ",
        "redundância no espaço de *features*, aumentando a dimensionalidade sem ",
        "acréscimo de informação e podendo impactar a estabilidade e ",
        "interpretabilidade dos modelos. Para mitigar esse efeito, aplica-se um ",
        "filtro de correlação par a par baseado no coeficiente de Pearson:\n\n",
        
        "$$\n",
        "r_{jk} = \\frac{\\sum_{i=1}^{n}(x_{ij} - \\bar{x}_j)(x_{ik} - \\bar{x}_k)}\n",
        "              {\\sqrt{\\sum_{i=1}^{n}(x_{ij} - \\bar{x}_j)^2 \\cdot\n",
        "               \\sum_{i=1}^{n}(x_{ik} - \\bar{x}_k)^2}}\n",
        "$$\n\n",
        
        "Para cada par $(X_j, X_k)$ com $j \\neq k$, quando:\n\n",
        
        "$$\n",
        "|r_{jk}| \\geq \\tau_{\\text{corr}} = 0{,}99\n",
        "$$\n\n",
        
        "uma das variáveis do par é removida, retendo-se aquela com maior",
        "correlação média absoluta com as demais *features* do conjunto, por ser",
        "a representante mais informativa da direção de variação compartilhada.",
        "O limiar de 99% é deliberadamente conservador, priorizando a remoção ",
        "apenas de redundâncias quasi-perfeitas e preservando variáveis com",
        "correlação substancial mas não colinear.\n\n",
        
        "O valor $x$ é válido se, e somente se, $x \\in \\{x \\in \\mathbb{R}",
        "\\mid x > 0 \\land x < 1\\}$, correspondendo ao intervalo aberto $(0, 1)$."
      )  
    ),  
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  ## Opcoes de divisao e balanceamento
  # Definicao proporcao de treino
  optionName <- "predy_training_set_prop"
  define_option(
    option = optionName,
    default = 0.90,
    desc = strwrap(
      paste0(
        "Divisão do conjunto $modelData$:\n\n",
        
        "$$\n",
        "modelData = trainingSet \\cup holdoutSet\n",
        "$$\n",
        
        "$$\n\n",
        "trainingSet \\cap holdoutSet = \\emptyset\n",
        "$$\n\n",
        
        "Sendo $TARGET \\in \\{0, 1\\}$ a variável binária, a divisão",
        "estratificada garante a proporção da classe nas porções:\n\n",
        
        "$$\n",
        "P(TARGET=1 \\mid trainingSet) = P(TARGET=1 \\mid holdoutSet) = P(TARGET=1 \\mid modelData)\n",
        "$$\n\n"
      )  
    ),  
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  # Definicao do metodo de balanceamento
  optionName <- "predy_balance_class"
  define_option(
    option = optionName,
    default = list(
      # method = "adanear",
      method = "random_under",
      adasyn_k = 7L,
      adasyn_ratio = 0.2,
      nearmiss_k = 3L,
      nearmiss_ratio = 10L,
      under_sampling = 10L
    ),
    desc = strwrap(
      paste0(
        "**method adanear**",
        "* none: Não faz balanceamento\n",
        "* random_under_sampling: Redução da classe majoritária com remoção aleatória de registros\n",
        "* adanear: ADASYN + NearMiss-1 (Brito et al, 2024) "
      )
    ),  
    option_name = optionName,
    envvar_name = paste0("R_", toupper(optionName)),
    envir = .GlobalEnv
  )
  
  invisible()
}
####
## Fim
#