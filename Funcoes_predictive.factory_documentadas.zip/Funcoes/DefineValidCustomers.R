#' @title Definir a Tabela de Clientes Válidos
#'
#' @usage
#' DefineValidCustomers(
#'   featureProcessed = FALSE,
#'   sufixoTabela = "TREINO",
#'   dataReferencia = "2026-05-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-12-01",
#'   dataAgregacaoFinal = "2026-05-31",
#'   dataHistoricaInicial = "2023-06-01",
#'   dataHistoricaFinal = "2026-05-31"
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Cria no Oracle a tabela in-memory `IM_ML_CLIENTES_VALIDOS_{SUFIXO}` com a população de
#' clientes pessoa física elegíveis à modelagem ou à predição, isto é, ativos em todos os
#' meses da janela de agregação.
#'
#' @details
#' A consulta é montada com `dbplyr` e executada integralmente no banco. Um cliente é
#' válido quando atende a todos os critérios:
#'
#' #. em `POS_KPI_CLIENTE_PF_MES`, possui `IND_ATIVO == "S"` e `IDADE` entre 0 e 120 em
#'    meses entre `dataAgregacaoInicial` e `dataAgregacaoFinal`;
#' #. em `CLIENTE`, possui `SEXO` igual a `"F"` ou `"M"`, `DATA_NASC_FUND` posterior a
#'    1905-12-31 e `DATA_OBITO` posterior a `dataAgregacaoFinal`;
#' #. em `HISTORICO_CLIENTE`, possui registro no mesmo mês de referência;
#' #. em `CONTA_BANRISUL` na `dataReferencia`, não aparece somente como segundo titular
#'    (`SEQUENCIA_CLIENTE_TIT2`) sem nenhuma conta como titular;
#' #. o número de meses distintos que atendem aos critérios anteriores é igual a
#'    `janelaAgregacao`.
#'
#' Sendo \eqn{M_c} o conjunto de meses válidos do cliente \eqn{c} na janela, a condição
#' final é:
#' \deqn{|M_c| = a}
#' em que \eqn{a} é `janelaAgregacao`.
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Comparações com Nulos:**
#' Em SQL, a comparação `DATA_OBITO > dataAgregacaoFinal` não é verdadeira quando
#' `DATA_OBITO` é nulo. Clientes sem data de óbito preenchida só permanecem na população
#' se a coluna usar uma data sentinela no lugar de nulo.
#' :::
#'
#' Quando `featureProcessed` é `TRUE`, a função retorna o nome da tabela sem executar a
#' consulta. Os argumentos `janelaHistorico`, `dataHistoricaInicial` e
#' `dataHistoricaFinal` não são usados no corpo da função; os valores padrão são de
#' referência e são sobrescritos pelos targets `tabelaClientesValidosTreino` e
#' `tabelaClientesValidosPredicao`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(DefineValidCustomers, prefix = "##", code = FALSE,
#'   narrow = TRUE), "DefineValidCustomers_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(DefineValidCustomers, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "DefineValidCustomers_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - remove, se existir, e recria a tabela `IM_ML_CLIENTES_VALIDOS_{SUFIXO}` no Oracle,
#'   por meio de `DbCreateTableMemoryFromQuery()`.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `POS_KPI_CLIENTE_PF_MES`, `CLIENTE`, `HISTORICO_CLIENTE`,     |
#' |                     | `CONTA_BANRISUL`                                              |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA` entre `dataAgregacaoInicial` e              |
#' |                     | `dataAgregacaoFinal`; `CONTA_BANRISUL` em `dataReferencia`    |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE` (e `DATA_REFERENCIA` com                  |
#' |                     | `HISTORICO_CLIENTE`)                                          |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | nenhuma                                                       |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_CLIENTES_VALIDOS_{SUFIXO}`                             |
#' +---------------------+---------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +---------------------+---------------------------------------------------------------+
#' | Coluna              | Descrição                                                     |
#' +=====================+===============================================================+
#' | `SEQUENCIA_CLIENTE` | Identificador do cliente válido, convertido por               |
#' |                     | `DbCastTo_SEQUENCIA_CLIENTE()`                                |
#' +---------------------+---------------------------------------------------------------+
#'
#' @param featureProcessed Lógico de comprimento 1. Quando `TRUE`, indica que a feature
#'   store já existe e a tabela não é recriada (padrão: `FALSE`).
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela, como `"TREINO"` ou `"PREDICAO"` (padrão: `"TREINO"`).
#' @param dataReferencia Data de referência usada no filtro de `CONTA_BANRISUL` (valor de
#'   referência: `"2026-05-01"`).
#' @param janelaAgregacao Inteiro com o número de meses que o cliente deve estar ativo
#'   (padrão: `6L`).
#' @param janelaHistorico Inteiro com a janela histórica. Não utilizado no corpo da função
#'   (padrão: `36L`).
#' @param dataAgregacaoInicial Data inicial da janela de agregação (valor de referência:
#'   `"2025-12-01"`).
#' @param dataAgregacaoFinal Data final da janela de agregação, também usada no critério
#'   de óbito (valor de referência: `"2026-05-31"`).
#' @param dataHistoricaInicial Data inicial da janela histórica. Não utilizada no corpo da
#'   função (valor de referência: `"2023-06-01"`).
#' @param dataHistoricaFinal Data final da janela histórica. Não utilizada no corpo da
#'   função (valor de referência: `"2026-05-31"`).
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela
#'   `IM_ML_CLIENTES_VALIDOS_{SUFIXO}`.
#'
#' @family Feature Store
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link[dbplyr]{dbplyr-package}}
#'
#' @references
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle disponível
#' tabelaClientesValidos <- DefineValidCustomers(
#'   featureProcessed = FALSE,
#'   sufixoTabela = "TREINO",
#'   dataReferencia = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31"
#' )
#' }
#'
#' @export
DefineValidCustomers <- function(
    featureProcessed = FALSE,
    sufixoTabela = "TREINO",
    dataReferencia = "2026-05-01",
    janelaAgregacao = 6L,
    janelaHistorico = 36L,
    dataAgregacaoInicial = "2025-12-01",
    dataAgregacaoFinal = "2026-05-31",
    dataHistoricaInicial = "2023-06-01",
    dataHistoricaFinal = "2026-05-31"
){
  
  ## Definicao do nome da tabela
  # Monta nome da tabela de clientes validos
  sufixoTabela <- str_to_upper(sufixoTabela[1L])
  tabelaClientesValidos <- str_c("IM_ML_CLIENTES_VALIDOS_", sufixoTabela)
  
  ## Retorno antecipado quando a feature store existe
  # Se ja processou
  if(featureProcessed){
    # Retorna tabela final 
    return(invisible(tabelaClientesValidos))
  }
  
  ## Selecao e gravacao dos clientes validos
  # Clientes ativos em todos os meses do periodo da janela de sumarizacao
  Db("POS_KPI_CLIENTE_PF_MES") |> 
    select(DATA_REFERENCIA, SEQUENCIA_CLIENTE, IDADE, IND_ATIVO) |>   
    filter(
      (IDADE >= 0L),
      (IDADE <= 120L),
      (IND_ATIVO == "S"),
      between(DATA_REFERENCIA, dataAgregacaoInicial, dataAgregacaoFinal)
    ) |> 
    semi_join(
      Db("CLIENTE") |> 
        select(SEQUENCIA_CLIENTE, DATA_OBITO, DATA_NASC_FUND, SEXO) |> 
        filter(
          (SEXO %in% c("F", "M")),
          (DATA_NASC_FUND > "1905-12-31"),
          (DATA_OBITO > dataAgregacaoFinal)
        ),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    semi_join(
      Db("HISTORICO_CLIENTE") |> 
        select(DATA_REFERENCIA, SEQUENCIA_CLIENTE) |> 
        filter(
          between(DATA_REFERENCIA, dataAgregacaoInicial, dataAgregacaoFinal)
        ),
      by = c("DATA_REFERENCIA", "SEQUENCIA_CLIENTE")
    ) |> 
    anti_join(
      # Definir a subquery de Titular 2 (Simplificação dos distincts)
      Db("CONTA_BANRISUL") |>
        filter(
          !is.na(SEQUENCIA_CLIENTE_TIT2),
          (DATA_REFERENCIA == dataReferencia)
        ) |>
        distinct(SEQUENCIA_CLIENTE = SEQUENCIA_CLIENTE_TIT2) |>
        anti_join(
          Db("CONTA_BANRISUL") |>
            filter(
              (DATA_REFERENCIA == dataReferencia)
            ) |> 
            distinct(SEQUENCIA_CLIENTE),
          by = "SEQUENCIA_CLIENTE"
        ),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    group_by(SEQUENCIA_CLIENTE) |>
    summarise(
      QtdMeses = n_distinct(DATA_REFERENCIA, na.rm = TRUE)
    ) |> 
    ungroup() |> 
    filter(
      (QtdMeses == janelaAgregacao)
    ) |>
    transmute(
      SEQUENCIA_CLIENTE = !!DbCastTo_SEQUENCIA_CLIENTE(SEQUENCIA_CLIENTE)
    ) |> 
    DbCreateTableMemoryFromQuery(nomeTabela = tabelaClientesValidos)
  
  ## Retorno do nome da tabela
  # Retorna tabela final 
  return(invisible(tabelaClientesValidos))
}
####
## Fim
#
