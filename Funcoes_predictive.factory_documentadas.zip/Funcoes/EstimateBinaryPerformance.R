#' @title Estimar o Desempenho de um Modelo Preditivo Binário
#'
#' @usage
#' EstimateBinaryPerformance(
#'   data,
#'   truth,
#'   ...,
#'   estimate,
#'   estimator = NULL,
#'   na_rm = TRUE,
#'   event_level = yardstick_event_level(),
#'   case_weights = NULL
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Conjunto padronizado de métricas de classificação binária, criado por
#' `yardstick::metric_set()`. Combina métricas baseadas em probabilidade e métricas
#' dependentes do ponto de corte.
#'
#' @details
#' `EstimateBinaryPerformance` não é uma função escrita no projeto: é o objeto retornado
#' por `yardstick::metric_set()`, avaliado na carga do arquivo. As métricas são:
#'
#' +----------------+---------------+---------------------------------------------+
#' | Métrica        | Tipo          | Definição                                   |
#' +================+===============+=============================================+
#' | `pr_auc`       | probabilidade | Área sob a curva precisão-recall            |
#' +----------------+---------------+---------------------------------------------+
#' | `roc_auc`      | probabilidade | Área sob a curva ROC                        |
#' +----------------+---------------+---------------------------------------------+
#' | `sens`         | classe        | \eqn{TP / (TP + FN)}                        |
#' +----------------+---------------+---------------------------------------------+
#' | `spec`         | classe        | \eqn{TN / (TN + FP)}                        |
#' +----------------+---------------+---------------------------------------------+
#' | `recall`       | classe        | \eqn{TP / (TP + FN)}, igual à sensibilidade |
#' +----------------+---------------+---------------------------------------------+
#' | `accuracy`     | classe        | \eqn{(TP + TN) / N}                         |
#' +----------------+---------------+---------------------------------------------+
#' | `bal_accuracy` | classe        | \eqn{(sens + spec) / 2}                     |
#' +----------------+---------------+---------------------------------------------+
#'
#' `yardstick::precision` está desativada por comentário. Em bases desbalanceadas, a
#' `pr_auc` é mais informativa que a `roc_auc`, pois depende diretamente da precisão na
#' classe positiva.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(EstimateBinaryPerformance, prefix = "##", code = FALSE,
#'   narrow = TRUE), "EstimateBinaryPerformance_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(EstimateBinaryPerformance, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "EstimateBinaryPerformance_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @param data Data frame com as colunas de valor real, classe predita e probabilidade.
#' @param truth Coluna do valor real (fator com dois níveis).
#' @param ... Coluna da probabilidade da classe positiva, usada por `pr_auc` e `roc_auc`.
#' @param estimate Coluna da classe predita (fator com os mesmos níveis de `truth`).
#' @param estimator Tipo de estimador; `NULL` usa o padrão binário.
#' @param na_rm Lógico: remove valores ausentes antes do cálculo (padrão: `TRUE`).
#' @param event_level `"first"` ou `"second"`: nível de `truth` tratado como evento.
#' @param case_weights Coluna opcional de pesos por observação.
#'
#' @returns Tibble com as colunas `.metric`, `.estimator` e `.estimate`, uma linha por
#'   métrica.
#'
#' @family Avaliação do Modelo
#'
#' @seealso \code{\link{EvaluateModel}}, \code{\link[yardstick]{metric_set}},
#'   \code{\link[yardstick]{pr_auc}}, \code{\link[yardstick]{roc_auc}}
#'
#' @references
#' Davis, J., & Goadrich, M. (2006). The relationship between Precision-Recall and ROC
#' curves. Proceedings of the 23rd ICML, 233-240.
#' \url{https://doi.org/10.1145/1143844.1143874}
#'
#' Fawcett, T. (2006). An introduction to ROC analysis. Pattern Recognition Letters,
#' 27(8), 861-874.
#' \url{https://doi.org/10.1016/j.patrec.2005.10.010}
#'
#' Saito, T., & Rehmsmeier, M. (2015). The precision-recall plot is more informative than
#' the ROC plot when evaluating binary classifiers on imbalanced datasets. PLoS ONE,
#' 10(3), e0118432.
#' \url{https://doi.org/10.1371/journal.pone.0118432}
#'
#' yardstick: Tidy Characterizations of Model Performance.
#' \url{https://yardstick.tidymodels.org/}
#'
#' @examples
#' \dontrun{
#' EstimateBinaryPerformance(
#'   data = performanceData,
#'   truth = TARGET_REAL,
#'   estimate = TARGET_PRED,
#'   TARGET_PROB,
#'   event_level = "first"
#' )
#' }
#'
#' @importFrom yardstick metric_set pr_auc roc_auc sens spec recall accuracy bal_accuracy
#'
#' @export
EstimateBinaryPerformance <- yardstick::metric_set(
  yardstick::pr_auc,
  yardstick::roc_auc,
  yardstick::sens,
  yardstick::spec,
  # yardstick::precision,
  yardstick::recall,
  yardstick::accuracy,
  yardstick::bal_accuracy
)
####
## Fim
#
