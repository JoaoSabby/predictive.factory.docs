#' @title Avaliar o Desempenho do Modelo na Base de Teste
#'
#' @usage
#' EvaluateModel(fileModel, holdoutSet)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Carrega o modelo XGBoost ajustado, aplica-o à base de teste (holdout) e calcula as
#' métricas de desempenho binário definidas em `EstimateBinaryPerformance`.
#'
#' @details
#' #. extrai o JSON do modelo para `tempdir()` e carrega-o com `xgb.load.raw()`;
#' #. constrói a `xgb.DMatrix` com as colunas de `holdoutSet`, exceto `TARGET`;
#' #. aplica `PredictModelXGBoost()` com ponto de corte `0.5`;
#' #. calcula as métricas com `TARGET` como valor real, a classe predita e a probabilidade
#'    de `"Sim"`, com `event_level = "first"`, isto é, `"Sim"` como classe positiva.
#'
#' A base de teste não é balanceada; as métricas refletem a distribuição observada das
#' classes.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(EvaluateModel, prefix = "##", code = FALSE,
#'   narrow = TRUE), "EvaluateModel_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(EvaluateModel, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "EvaluateModel_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - extrai o arquivo JSON do modelo em `tempdir()`, sobrescrevendo arquivo existente.
#'
#' @param fileModel Caminho do arquivo `.zip` com o modelo em JSON, retornado por
#'   `FitModel()`.
#' @param holdoutSet Tibble de teste, com `TARGET` (níveis `"Sim"` e `"Nao"`) e as mesmas
#'   features da base de treino.
#'
#' @returns Tibble com as colunas `METRIC` (nome da métrica) e `ESTIMATE` (valor), com uma
#'   linha para cada métrica de `EstimateBinaryPerformance`.
#'
#' @family Avaliação do Modelo
#'
#' @seealso \code{\link{EstimateBinaryPerformance}}, \code{\link{PredictModelXGBoost}},
#'   \code{\link{BuildPipelineModeling}}
#'
#' @references
#' Saito, T., & Rehmsmeier, M. (2015). The precision-recall plot is more informative than
#' the ROC plot when evaluating binary classifiers on imbalanced datasets. PLoS ONE,
#' 10(3), e0118432.
#' \url{https://doi.org/10.1371/journal.pone.0118432}
#'
#' yardstick: Tidy Characterizations of Model Performance.
#' \url{https://yardstick.tidymodels.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: modelo ajustado e base de teste disponível
#' performanceMetrics <- EvaluateModel(fileModel = fileModel, holdoutSet = holdoutSet)
#' }
#'
#' @importFrom xgboost xgb.load.raw xgb.DMatrix
#' @importFrom zip unzip
#'
#' @export
EvaluateModel <- function(fileModel, holdoutSet){
  
  ## Carga do modelo
  # Json file model
  jsonFileModel <- zip::unzip(
    zipfile = fileModel,
    exdir = tempdir(),
    overwrite = TRUE
  )
  
  # busca binario do modelo
  dataRaw <- readBin(
    con = jsonFileModel$path[1L],
    what = "raw",
    n = file.info(jsonFileModel$path[1L])$size
  )
  
  # Carrega modelo
  fittedModel <- xgb.load.raw(
    buffer = dataRaw
  )
  
  ## Construcao da matriz de teste
  # Gera matrix xgboost holdout
  xgbHoldoutSet <- xgb.DMatrix(
    data = holdoutSet |>
      select(-TARGET),
    silent = TRUE,
    nthread = opt("predy_threads_limit")
  )

  ## Predicao e calculo das metricas
  # Executa predicao
  performanceResult <- PredictModelXGBoost(
    data = xgbHoldoutSet,
    model = fittedModel,
    positive = "Sim",
    negative = "Nao"
  ) |> 
    transmute(
      TARGET_REAL = holdoutSet$TARGET,
      TARGET_PRED = .pred_class,
      TARGET_PROB = .pred_positive
    ) |> 
    EstimateBinaryPerformance(
      truth = TARGET_REAL,
      estimate = TARGET_PRED,
      TARGET_PROB,
      event_level = "first"
    ) |> 
    transmute(
      METRIC = .metric,
      ESTIMATE = .estimate
    )

  ## Retorno das metricas
  # Retorna avaliacao do modelo
  return(performanceResult)
}
####
## Fim
# 
