#' @title Ajustar o Modelo Preditivo Final
#'
#' @usage
#' FitModel(trainingSet, hyperParams)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Ajusta o modelo preditivo final com a base de treino e os hiperparâmetros otimizados,
#' delegando ao motor definido pela opção `predy_engine_model`.
#'
#' @details
#' +----------------------+----------------------------------------------+
#' | `predy_engine_model` | Função chamada                               |
#' +======================+==============================================+
#' | `"xgboost"`          | `FitModelXGBoost(trainingSet, hyperParams)`  |
#' +----------------------+----------------------------------------------+
#' | `"lightgbm"`         | `FitModelLightGBM(trainingSet, hyperParams)` |
#' +----------------------+----------------------------------------------+
#' | outro valor          | erro `FitModel: Engine não implementada`     |
#' +----------------------+----------------------------------------------+
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Assinatura do LightGBM:**
#' `FitModelLightGBM()` é definida com os argumentos `dataTrain`, `dataValid` e
#' `hyperParam`. A chamada com `trainingSet` e `hyperParams` termina com erro de argumento
#' não utilizado. A mensagem de erro para motor não implementado usa
#' `hyperParams$engine_model`, que pode não corresponder à opção lida.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(FitModel, prefix = "##", code = FALSE,
#'   narrow = TRUE), "FitModel_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(FitModel, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "FitModel_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @param trainingSet Tibble de treino preprocessada, com `TARGET` e as features.
#' @param hyperParams Lista de hiperparâmetros retornada por `TuneModel()`, com o elemento
#'   `results`.
#'
#' @returns Valor invisível retornado pela função do motor. Para XGBoost, o caminho do
#'   arquivo `.zip` do modelo, usado pelo target `fileModel` com `format = "file"`.
#'
#' @family Modelagem Preditiva
#'
#' @seealso \code{\link{FitModelXGBoost}}, \code{\link{FitModelLightGBM}},
#'   \code{\link{TuneModel}}, \code{\link{BuildPipelineModeling}}
#'
#' @references
#' Chen, T., & Guestrin, C. (2016). XGBoost: A scalable tree boosting system. Proceedings
#' of the 22nd ACM SIGKDD, 785-794.
#' \url{https://doi.org/10.1145/2939672.2939785}
#'
#' Ke, G., Meng, Q., Finley, T., et al. (2017). LightGBM: A highly efficient gradient
#' boosting decision tree. Advances in Neural Information Processing Systems 30.
#'
#' LightGBM Documentation.
#' \url{https://lightgbm.readthedocs.io/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: opção predy_engine_model definida e hiperparâmetros otimizados
#' fileModel <- FitModel(trainingSet = trainingSet, hyperParams = hyperParams)
#' }
#'
#' @export
FitModel <- function(
    trainingSet,
    hyperParams
){

  ## Leitura do motor preditivo
  # Algoritmo preditivo
  engineModel <- opt("predy_engine_model")
  
  ## Ajuste pelo motor selecionado
  # Se for XGBoost  
  if(engineModel == "xgboost"){
    fittedModel <- FitModelXGBoost(
      trainingSet = trainingSet,
      hyperParams = hyperParams
    )
  } else if(engineModel == "lightgbm"){
    fittedModel <- FitModelLightGBM(
      trainingSet = trainingSet,
      hyperParams = hyperParams
    )
  } else {
    stop(glue("FitModel: Engine não implementada {hyperParams$engine_model}!"))
  }
  
  ## Retorno do modelo ajustado
  # Retorna o modelo final
  return(invisible(fittedModel))
}
####
##
# 
