#' @title Ajustar um Modelo com LightGBM
#'
#' @usage
#' FitModelLightGBM(dataTrain, dataValid, hyperParam)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Ajusta um modelo LightGBM binário com parada antecipada, a partir de conjuntos
#' `lgb.Dataset` de treino e validação e de hiperparâmetros na nomenclatura do
#' `tidymodels`.
#'
#' @details
#' Os hiperparâmetros são convertidos para o LightGBM:
#'
#' +-------------------------+-----------------------------------------------------------+
#' | Hiperparâmetro recebido | Parâmetro do LightGBM                                     |
#' +=========================+===========================================================+
#' | `learn_rate`            | `learning_rate`                                           |
#' +-------------------------+-----------------------------------------------------------+
#' | `tree_depth`            | `max_depth`, arredondado, e `num_leaves` \eqn{= 2^{d} -   |
#' |                         | 1}                                                        |
#' +-------------------------+-----------------------------------------------------------+
#' | `loss_reduction`        | `min_gain_to_split`                                       |
#' +-------------------------+-----------------------------------------------------------+
#' | `sample_size`           | `bagging_fraction`, com `bagging_freq = 1`                |
#' +-------------------------+-----------------------------------------------------------+
#' | `mtry`                  | `feature_fraction` \eqn{= \min(\max(\mathrm{round}(mtry), |
#' |                         | 1) / p, 1)}                                               |
#' +-------------------------+-----------------------------------------------------------+
#' | `trees`                 | `nrounds`                                                 |
#' +-------------------------+-----------------------------------------------------------+
#' | `stop_iter`             | `early_stopping_rounds`                                   |
#' +-------------------------+-----------------------------------------------------------+
#'
#' em que \eqn{p} é o atributo `nFeatures` de `dataTrain`. O treinamento é determinístico
#' (`deterministic = TRUE` e sementes `42`), usa as métricas `average_precision` e
#' `binary_logloss` e o número de threads da variável de ambiente `OMP_NUM_THREADS`
#' (padrão 1).
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Integração com o Pipeline:**
#' `FitModel()` chama esta função com os argumentos `trainingSet` e `hyperParams`, que não
#' existem na assinatura. O motor `"lightgbm"` não está operacional no pipeline atual.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(FitModelLightGBM, prefix = "##", code = FALSE,
#'   narrow = TRUE), "FitModelLightGBM_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(FitModelLightGBM, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "FitModelLightGBM_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @param dataTrain Objeto `lgb.Dataset` de treino com o atributo `nFeatures`.
#' @param dataValid Objeto `lgb.Dataset` de validação, usado na parada antecipada.
#' @param hyperParam Lista ou linha de tibble com `mtry`, `tree_depth`, `learn_rate`,
#'   `loss_reduction`, `sample_size`, `trees` e `stop_iter`.
#'
#' @returns Objeto `lgb.Booster` invisível.
#'
#' @family Modelagem Preditiva
#'
#' @seealso \code{\link{FitModel}}, \code{\link{PrepareTuneModelFoldsLightGBM}},
#'   \code{\link{TuneModelBoundsLightGBM}}, \code{\link[lightgbm]{lgb.train}}
#'
#' @references
#' Ke, G., Meng, Q., Finley, T., et al. (2017). LightGBM: A highly efficient gradient
#' boosting decision tree. Advances in Neural Information Processing Systems 30.
#'
#' LightGBM Documentation: Parameters.
#' \url{https://lightgbm.readthedocs.io/en/latest/Parameters.html}
#'
#' @examples
#' \dontrun{
#' fittedModel <- FitModelLightGBM(
#'   dataTrain = lgbTrain,
#'   dataValid = lgbValid,
#'   hyperParam = list(
#'     mtry = 20, tree_depth = 6, learn_rate = 0.05, loss_reduction = 0,
#'     sample_size = 0.8, trees = 1000, stop_iter = 50
#'   )
#' )
#' }
#'
#' @importFrom lightgbm lgb.train
#'
#' @export
FitModelLightGBM <- function(
    dataTrain,
    dataValid,
    hyperParam
){
  ## Conversao dos hiperparametros
  # Recupera numero de preditores
  nFeatures <- attr(
    x = dataTrain,
    which = "nFeatures"
  )
  
  # Define fracao de colunas por arvore
  featureFraction <- min(
    x = max(
      as.integer(round(hyperParam$mtry)),
      1L
    ) / nFeatures,
    y = 1
  )
  
  # Define threads internas do fit
  fitThreads <- as.integer(
    Sys.getenv(
      x = "OMP_NUM_THREADS",
      unset = 1L
    )
  )
  
  # Deriva folhas a partir da profundidade
  numLeaves <- as.integer(
    2^as.integer(round(hyperParam$tree_depth)) - 1L
  )
  
  ## Montagem dos parametros
  # Define parametros do LightGBM
  modelParam <- list(
    objective = "binary",
    metric = c(
      "average_precision",
      "binary_logloss"
    ),
    boosting = "gbdt",
    data_sample_strategy = "bagging",
    learning_rate = hyperParam$learn_rate,
    max_depth = as.integer(round(hyperParam$tree_depth)),
    num_leaves = numLeaves,
    min_gain_to_split = hyperParam$loss_reduction,
    bagging_fraction = hyperParam$sample_size,
    bagging_freq = 1L,
    feature_fraction = featureFraction,
    deterministic = TRUE,
    force_col_wise = TRUE,
    seed = 42L,
    data_random_seed = 42L,
    feature_fraction_seed = 42L,
    bagging_seed = 42L,
    num_threads = fitThreads,
    verbosity = -1L
  )
  
  ## Treinamento com parada antecipada
  # Treina modelo
  fittedModel <- lgb.train(
    params = modelParam,
    data = dataTrain,
    nrounds = as.integer(round(hyperParam$trees)),
    valids = list(
      validation = dataValid
    ),
    early_stopping_rounds = as.integer(round(hyperParam$stop_iter)),
    eval_freq = 50L,
    verbose = -1L
  )
  
  ## Retorno do modelo
  # Retorna modelo preditivo
  return(invisible(fittedModel))
}
####
## Fim
# 
