#' @title Ajustar o Modelo Final com XGBoost
#'
#' @usage
#' FitModelXGBoost(trainingSet, hyperParams)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Ajusta o modelo XGBoost binário final com os hiperparâmetros otimizados, salva o modelo
#' em formato JSON compactado em `.zip` na pasta de artefatos e retorna o caminho do
#' arquivo.
#'
#' @details
#' As etapas são:
#'
#' #. divisão interna estratificada da base de treino em 80% para ajuste e 20% para
#'    monitoramento, por `rsample::initial_split()`;
#' #. balanceamento apenas da porção de ajuste, por `BalanceClass()` com a configuração da
#'    opção `predy_balance_class`;
#' #. construção das matrizes `xgb.DMatrix`, com pesos 10 para `"Sim"` e 1 para `"Nao"` na
#'    porção de ajuste;
#' #. treinamento por `xgb.train()` com 6.000 rodadas, árvores `gbtree`, método `hist`,
#'    `max_bin = 1024`, objetivo `binary:logistic` e métrica `aucpr` na porção de
#'    monitoramento;
#' #. gravação do modelo em JSON por `xgb.save.raw()`, compactação em
#'    `predictive_model.zip` e remoção do JSON temporário.
#'
#' A função de perda ponderada minimizada é:
#' \deqn{\mathcal{L} = \sum_i w_i \, \ell(y_i, \hat{y}_i) + \sum_k \Omega(f_k)}
#' com \eqn{w_i = 10} quando \eqn{y_i = 1} e \eqn{w_i = 1} quando \eqn{y_i = 0}.
#'
#' ::: {.callout-important}
#' <i class="fa-solid fa-circle-exclamation"></i> **Hiperparâmetros Não Aplicados:**
#' `max_depth`, `min_child_weight` e `min_split_loss` são lidos de
#' `hyperParams$results$Best_Par[...]`. A lista `results` retornada por `TuneModel()` não
#' contém `Best_Par`; por isso, esses três parâmetros não são definidos e o XGBoost usa os
#' valores padrão. Os valores otimizados estão em `hyperParams$results$max_depth`,
#' `hyperParams$results$min_child_weight` e `hyperParams$results$min_split_loss`.
#' :::
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **Parada Antecipada e Margem Base:**
#' Não há `early_stopping_rounds`: as 6.000 rodadas são sempre executadas, e a porção de
#' monitoramento serve apenas para acompanhamento da métrica. A margem base `baseMargin` é
#' calculada, mas não é usada, pois o argumento `base_margin` está comentado.
#' :::
#'
#' A semente do XGBoost é `42`. A divisão interna não fixa semente; sua reprodutibilidade
#' depende da semente por target definida em `tar_option_set(seed = 42L)`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(FitModelXGBoost, prefix = "##", code = FALSE,
#'   narrow = TRUE), "FitModelXGBoost_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(FitModelXGBoost, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "FitModelXGBoost_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - grava `predictive_model.zip` em `modelRunConfig$paths$artifactsPath`, sobrescrevendo
#'   arquivo existente;
#' - cria e remove o arquivo `predictive_model_{idModel}.json` em `tempdir()`;
#' - depende do objeto global `modelRunConfig`.
#'
#' @param trainingSet Tibble de treino preprocessada, com `TARGET` (níveis `"Sim"` e
#'   `"Nao"`) e as features.
#' @param hyperParams Lista retornada por `TuneModel()`. São usados os elementos de
#'   `results`: `reg_alpha`, `learning_rate`, `reg_lambda`, `max_delta_step`, `subsample`
#'   e `colsample_bytree`.
#'
#' @returns Vetor de caracteres de comprimento 1 com o caminho de `predictive_model.zip`.
#'
#' @family Modelagem Preditiva
#'
#' @seealso \code{\link{FitModel}}, \code{\link{TuneModel}}, \code{\link{BalanceClass}},
#'   \code{\link{PredictModel}}, \code{\link[xgboost]{xgb.train}}
#'
#' @references
#' Chen, T., & Guestrin, C. (2016). XGBoost: A scalable tree boosting system. Proceedings
#' of the 22nd ACM SIGKDD, 785-794.
#' \url{https://doi.org/10.1145/2939672.2939785}
#'
#' Elkan, C. (2001). The foundations of cost-sensitive learning. Proceedings of the 17th
#' International Joint Conference on Artificial Intelligence, 973-978.
#'
#' XGBoost Documentation: Parameters.
#' \url{https://xgboost.readthedocs.io/en/stable/parameter.html}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: modelRunConfig carregado e hiperparâmetros otimizados
#' fileModel <- FitModelXGBoost(trainingSet = trainingSet, hyperParams = hyperParams)
#' }
#'
#' @importFrom xgboost xgb.DMatrix xgb.train xgb.params xgb.save.raw
#' @importFrom rsample initial_split training testing
#'
#' @export
FitModelXGBoost <- function(
    trainingSet,
    hyperParams
){

  ## Divisao interna estratificada
  # Conjunto treino/validacao xgboost
  setInternalSplit <- initial_split(
    data = data.frame(
      rowIndex = seq_len(nrow(trainingSet)),
      TARGET = as.integer(trainingSet$TARGET == "Sim")
    ),
    prop = 0.8,
    strata = TARGET
  )
  
  # Extrai linhas de treino 
  trainRows <- training(setInternalSplit)$rowIndex
  
  ## Balanceamento da porcao de ajuste
  # Aplica o balanceamento de classes exclusivamente aos dados de treinamento
  trainBalanced <- BalanceClass(
    database = trainingSet[trainRows, ],
    balanceClassConfig = opt("predy_balance_class"),
    nThreads = opt("predy_threads_limit")
  )
  
  # Calcula a probabilidade empirica da classe positiva com uma unica
  propPositive <- mean(trainBalanced$TARGET == "Sim")
  
  # Calcula margem base
  baseMargin <- rep_(
    x = log_(propPositive / (1L - propPositive)),
    times = fnrow(trainBalanced)
  )
  
  ## Construcao das matrizes XGBoost
  # Converte porcao de treino xgboost para matrix XGB
  xgbTrain <- xgb.DMatrix(
    data = fselect(trainBalanced, -TARGET),
    label = as.integer(trainBalanced$TARGET == "Sim"),
    # base_margin = baseMargin,
    weight = ifelse(
      test = (trainBalanced$TARGET == "Sim"),
      yes = 10L,
      no = 1L
    ),
    silent = TRUE,
    nthread = opt("predy_threads_limit")
  )
  
  # Linhas para validacao
  validRows <- testing(setInternalSplit)$rowIndex

  # Converte porcao de validacao xgboost para matrix XGB
  xgbValid <- xgb.DMatrix(
    data = fselect(trainingSet[validRows, ], -TARGET),
    label = as.integer(trainingSet$TARGET[validRows] == "Sim"),
    silent = TRUE,
    nthread = opt("predy_threads_limit")
  )
  
  ## Treinamento do modelo
  # Treinamento do modelo
  set.seed(42L)
  fittedModel <- xgboost::xgb.train(
    data                  = xgbTrain,
    evals = list(
      validation          = xgbValid
    ),
    nrounds               = 6000L,
    verbose               = 0L,
    maximize              = TRUE,
    params = xgboost::xgb.params(
      booster             = "gbtree",
      objective           = "binary:logistic",
      eval_metric         = "aucpr",
      grow_policy         = "depthwise",
      device              = "cpu",
      tree_method         = "hist",
      sampling_method     = "uniform",
      max_bin             = 1024L,
      verbosity           = 0L,
      seed                = 42L,
      reg_alpha           = hyperParams$results$reg_alpha,
      learning_rate       = hyperParams$results$learning_rate,
      reg_lambda          = hyperParams$results$reg_lambda,
      max_depth           = hyperParams$results$Best_Par["max_depth"],
      min_child_weight    = hyperParams$results$Best_Par["min_child_weight"],
      min_split_loss      = hyperParams$results$Best_Par["min_split_loss"],
      max_delta_step      = hyperParams$results$max_delta_step,
      subsample           = hyperParams$results$subsample,
      colsample_bytree    = hyperParams$results$colsample_bytree,
      nthread             = opt("predy_threads_limit")
    )
  )
  
  ## Gravacao e compactacao do modelo
  # Gera formato universal do modelo (valido para qualquer linguagem)
  modelRawJson <- xgb.save.raw(
    model = fittedModel,
    raw_format = "json"
  )
  
  # Salva como json temporario
  jsonFile <- glue("{tempdir()}/predictive_model_{modelRunConfig$idModel}.json")
  writeBin(
    con = jsonFile,
    object = modelRawJson
  )
  
  # Compacta arquivo  
  fileModel  <- file.path(modelRunConfig$paths$artifactsPath, "predictive_model.zip")
  zip::zipr(
    zipfile = fileModel,
    files = jsonFile,
    compression_level = 9L
  )
  
  # Remover o arquivo textual transitorio
  file.remove(jsonFile)
  
  # Retorna o caminho do arquivo zip com o modelo
  return(fileModel)
}
####
## Fim
#
