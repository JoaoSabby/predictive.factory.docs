#' @title Gerar o Feature Group de Margem de Contribuição
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_BHL_MARGEM_CONTRIBUICAO(
#'   tabelaClientesValidos,
#'   sufixoTabela = "",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Calcula, para cada cliente válido, medianas mensais da quantidade de produtos, do valor
#' efetivo e da margem de contribuição, e a variabilidade mensal da margem, a partir da
#' tabela `BHL_MARGEM_CONTRIBUICAO` na janela de agregação.
#'
#' @details
#' A agregação é feita em dois níveis. Primeiro, por cliente e mês, sobre os registros com
#' `IND_VLR == 1`. Em seguida, por cliente, sobre a série mensal. Sendo \eqn{M_c} o
#' conjunto de meses com registro do cliente \eqn{c} na janela de agregação:
#' \deqn{\tilde{x}_c = \mathrm{mediana}_{m \in M_c}\left(\sum_{i \in (c, m)} x_i\right)}
#' A mediana é calculada por `APPROX_MEDIAN` do Oracle, que é aproximada.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **Meses sem Registro:**
#' Meses sem registro não são preenchidos com zero: a mediana e o desvio padrão usam
#' apenas os meses presentes em \eqn{M_c}. O desvio padrão é nulo quando o cliente tem um
#' único mês.
#' :::
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_BHL_MARGEM_CONTRIBUICAO_{SUFIXO}`, executa a consulta no Oracle por meio de
#' `dbplyr` e grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela
#' anterior de mesmo nome. A função é descoberta pelos pipelines de dados por meio do
#' prefixo `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo após a junção em
#' `Generate_IM_ML_FEATURE_STORE()`.
#'
#' Os argumentos `dataFeature`, `janelaAgregacao`, `janelaHistorico`,
#' `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no corpo da função; existem
#' para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_BHL_MARGEM_CONTRIBUICAO,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_BHL_MARGEM_CONTRIBUICAO_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_BHL_MARGEM_CONTRIBUICAO,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_BHL_MARGEM_CONTRIBUICAO_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_BHL_MARGEM_CONTRIBUICAO_{SUFIXO}` no
#'   Oracle.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `BHL_MARGEM_CONTRIBUICAO`, `tabelaClientesValidos`            |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA` entre `dataAgregacaoInicial` e              |
#' |                     | `dataAgregacaoFinal`                                          |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`                                           |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | nenhuma                                                       |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_BHL_MARGEM_CONTRIBUICAO_{SUFIXO}`                      |
#' +---------------------+---------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +----------------------------+--------------------------------------------------------+
#' | Coluna                     | Descrição                                              |
#' +============================+========================================================+
#' | `SEQUENCIA_CLIENTE`        | Identificador do cliente                               |
#' +----------------------------+--------------------------------------------------------+
#' | `VerQtdProdutos`           | Mediana mensal do número de produtos Bacen distintos   |
#' |                            | (`COD_PRODUTO_BACEN`); inteiro                         |
#' +----------------------------+--------------------------------------------------------+
#' | `VerTotalMensalVlrEfetivo` | Mediana mensal da soma de `VLR_EFETIVO`; decimal (12,  |
#' |                            | 2)                                                     |
#' +----------------------------+--------------------------------------------------------+
#' | `VerSdMensalVlrMc`         | Desvio padrão amostral da soma mensal de `VLR_MC`;     |
#' |                            | decimal (12, 4)                                        |
#' +----------------------------+--------------------------------------------------------+
#' | `VerTotalMensalVlrMc`      | Mediana mensal da soma de `VLR_MC`; decimal (12, 2)    |
#' +----------------------------+--------------------------------------------------------+
#'
#' O desvio padrão segue \eqn{s_c = \sqrt{\frac{1}{|M_c|-1}\sum_{m \in M_c}(y_{c,m} -
#' \bar{y}_c)^2}}, em que \eqn{y_{c,m}} é a soma mensal de `VLR_MC`.
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `""`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`. Não
#'   utilizado no corpo da função.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_BHL_MARGEM_CONTRIBUICAO_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Oracle Database SQL Language Reference: APPROX_MEDIAN.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/sqlrf/}
#'
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_BHL_MARGEM_CONTRIBUICAO(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_BHL_MARGEM_CONTRIBUICAO <- function(
    tabelaClientesValidos,
    sufixoTabela = "",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_BHL_MARGEM_CONTRIBUICAO_", str_to_upper(sufixoTabela))
  
  ## Agregacao mensal e por cliente
  # Gera preditores da tabela BHL_MARGEM_CONTRIBUICAO 
  Db("BHL_MARGEM_CONTRIBUICAO") |>
    filter(
      (IND_VLR == 1L),
      between(DATA_REFERENCIA, TO_DATE(dataAgregacaoInicial, 'YYYY-MM-DD'), TO_DATE(dataAgregacaoFinal, 'YYYY-MM-DD'))
    ) |>  
    select(
      DATA_REFERENCIA,
      SEQUENCIA_CLIENTE, 
      COD_PRODUTO_BACEN,
      VLR_EFETIVO,
      VLR_MC
    ) |> 
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    group_by(DATA_REFERENCIA, SEQUENCIA_CLIENTE) |> 
    summarize(
      VerQtdProdutos = n_distinct(COD_PRODUTO_BACEN, na.rm = TRUE),
      VerTotalMensalVlrEfetivo = sum(VLR_EFETIVO, na.rm = TRUE),
      VerTotalMensalVlrMc = sum(VLR_MC, na.rm = TRUE)
    ) |> 
    ungroup() |> 
    group_by(SEQUENCIA_CLIENTE) |> 
    summarize(
      VerQtdProdutos = APPROX_MEDIAN(VerQtdProdutos),
      VerTotalMensalVlrEfetivo = APPROX_MEDIAN(VerTotalMensalVlrEfetivo),
      VerSdMensalVlrMc = sd(VerTotalMensalVlrMc, na.rm = TRUE),
      VerTotalMensalVlrMc = APPROX_MEDIAN(VerTotalMensalVlrMc)
    ) |> 
    ungroup() |> 
    DbCast(
      VerQtdProdutos = DbCastToInteger(2L),
      VerTotalMensalVlrEfetivo = DbCastToDouble(12L, 2L),
      VerSdMensalVlrMc = DbCastToDouble(12L, 4L),
      VerTotalMensalVlrMc = DbCastToDouble(12L, 2L)
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  ## Retorno do nome da tabela
  # Retorna nome da tabela
  return(invisible(tabelaFeature))
}
####
## Fim
#
