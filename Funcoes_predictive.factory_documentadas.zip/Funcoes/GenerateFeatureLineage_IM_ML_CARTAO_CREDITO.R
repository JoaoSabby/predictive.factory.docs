#' @title Gerar o Feature Group de Cartão de Crédito
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_CARTAO_CREDITO(
#'   tabelaClientesValidos,
#'   sufixoTabela = "",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Identifica, na data de referência, se o cliente válido possui cartão de crédito e se
#' utiliza o limite do cartão, a partir dos saldos de `MTB_EFETIVO_MENSAL` classificados
#' pela hierarquia de gestão BIB.
#'
#' @details
#' A classificação das contas BIB une `CONTA`, `PRODUTO_GESTAO_BIB` e
#' `SUBGRUPO_GESTAO_BIB`:
#'
#' - possui cartão: contas do grupo de gestão `105` (cartão de crédito);
#' - usa cartão: contas do subgrupo `30107` (limite de cartão de crédito), considerando
#'   apenas `VALOR_PARCELA > 0`.
#'
#' Os dois conjuntos são somados por cliente e unidos por `full_join()`. Cada indicador é
#' `TRUE` quando a soma correspondente existe, e `FALSE` quando o cliente aparece apenas
#' no outro conjunto.
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_CARTAO_CREDITO_{SUFIXO}`, executa a consulta no Oracle por meio de `dbplyr` e
#' grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior de
#' mesmo nome. A função é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' A tabela contém apenas clientes com pelo menos uma das condições. Clientes ausentes da
#' tabela recebem valor nulo nas colunas deste grupo após a junção em
#' `Generate_IM_ML_FEATURE_STORE()`.
#'
#' Os argumentos `janelaAgregacao`, `janelaHistorico`, `dataAgregacaoInicial`,
#' `dataAgregacaoFinal`, `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no
#' corpo da função; existem para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_CARTAO_CREDITO,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_CARTAO_CREDITO_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_CARTAO_CREDITO,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_CARTAO_CREDITO_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_CARTAO_CREDITO_{SUFIXO}` no Oracle.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `MTB_EFETIVO_MENSAL`, `CONTA`, `PRODUTO_GESTAO_BIB`,          |
#' |                     | `SUBGRUPO_GESTAO_BIB`, `tabelaClientesValidos`                |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA == dataFeature`                              |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`; `COD_CONTA_BIB` com `COD_CONTA`          |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | nenhuma                                                       |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_CARTAO_CREDITO_{SUFIXO}`                               |
#' +---------------------+---------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +-----------------------+-----------------------------------------------------------+
#' | Coluna                | Descrição                                                 |
#' +=======================+===========================================================+
#' | `SEQUENCIA_CLIENTE`   | Identificador do cliente                                  |
#' +-----------------------+-----------------------------------------------------------+
#' | `VeqTemCartaoCredito` | Lógico: cliente com saldo em conta do grupo de gestão 105 |
#' +-----------------------+-----------------------------------------------------------+
#' | `VeqUsaCartaoCredito` | Lógico: cliente com valor positivo no subgrupo 30107      |
#' +-----------------------+-----------------------------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `""`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_CARTAO_CREDITO_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_CARTAO_CREDITO(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_CARTAO_CREDITO <- function(
    tabelaClientesValidos,
    sufixoTabela = "",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_CARTAO_CREDITO_", str_to_upper(sufixoTabela))
  
  ## Classificacao das contas BIB
  # Filtro de BIBs com PRODUTO_GESTAO_BIB e SUBGRUPO_GESTAO_BIB  
  contasBibFiltro <- Db("CONTA") |>
    select(COD_CONTA, COD_PRODUTO_GESTAO_BIB) |> 
    inner_join(
      Db("PRODUTO_GESTAO_BIB") |>
        select(COD_PRODUTO_GESTAO, COD_SUBGRUPO_GESTAO) |> 
        inner_join(
          Db("SUBGRUPO_GESTAO_BIB") |>
            select(COD_SUBGRUPO_GESTAO, COD_GRUPO_GESTAO_BIB),
          by = 'COD_SUBGRUPO_GESTAO'
        ),
      by = c('COD_PRODUTO_GESTAO_BIB' = 'COD_PRODUTO_GESTAO')
    )
  
  # Codigos que podem estar em tabela de configuração também
  # GRUPO    105  	CARTAO CREDITO (tem cartao de credito)
  contasBibPossuiCartaoCredito <- contasBibFiltro |> 
    filter(
      COD_GRUPO_GESTAO_BIB == 105L
    )
  
  # SUBGRUPO 30107	LIMITE CARTAO DE CREDITO (usa cartao de credito)
  contasBibUsaCartaoCredito <- contasBibFiltro |> 
    filter(
      COD_SUBGRUPO_GESTAO == 30107L
    )
  
  ## Selecao dos saldos do mes de referencia
  clientesFiltro <- Db("MTB_EFETIVO_MENSAL") |>
    filter(
      (DATA_REFERENCIA == dataFeature)
    ) |> 
    select(SEQUENCIA_CLIENTE, COD_CONTA_BIB, VALOR_PARCELA) |> 
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    )
  
  dadosCartaoPossui <- clientesFiltro |>
    inner_join(
      contasBibPossuiCartaoCredito,
      by = c('COD_CONTA_BIB' = 'COD_CONTA')
    ) |> 
    group_by(SEQUENCIA_CLIENTE) |> 
    summarise(
      VALOR_TEM = sum(VALOR_PARCELA, na.rm = TRUE)
    ) |> 
    ungroup()
  
  dadosCartaoUsa <- clientesFiltro |> 
    filter(
      # Necessario filtrar valor > 0 pois existem registros com valor zero que não devem ser retornados
      VALOR_PARCELA > 0
    ) |> 
    inner_join(
      contasBibUsaCartaoCredito,
      by = c('COD_CONTA_BIB' = 'COD_CONTA')
    ) |> 
    group_by(SEQUENCIA_CLIENTE) |> 
    summarise(
      VALOR_USA = sum(VALOR_PARCELA, na.rm = TRUE)
    ) |> 
    ungroup() 
  
  ## Montagem dos indicadores e gravacao
  dadosCartaoPossui |> 
    full_join(
      dadosCartaoUsa,
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    transmute(
      SEQUENCIA_CLIENTE,
      VeqTemCartaoCredito = ifelse(
        test = !is.na(VALOR_TEM),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      ),
      VeqUsaCartaoCredito = ifelse(
        test = !is.na(VALOR_USA),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      )
    ) |> 
    DbCast(
      SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE(),
      VeqTemCartaoCredito = DbCastToLogical(),
      VeqUsaCartaoCredito = DbCastToLogical()
    ) |>
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  ## Retorno do nome da tabela
  # Nome da tabela 
  return(invisible(tabelaFeature))
}
####
## Fim
#
