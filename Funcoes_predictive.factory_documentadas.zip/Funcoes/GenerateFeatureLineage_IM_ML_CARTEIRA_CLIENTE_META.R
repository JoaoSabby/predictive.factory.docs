#' @title Gerar o Feature Group de Carteira de Clientes
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_CARTEIRA_CLIENTE_META(
#'   tabelaClientesValidos,
#'   sufixoTabela = "",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Identifica, na data de referência, se o cliente válido está vinculado a um funcionário
#' na tabela `CARTEIRA_CLIENTE_META`.
#'
#' @details
#' O indicador `Ve2FunciBanrisul` é `TRUE` quando `COD_FUNCIONARIO` não é nulo e `FALSE`
#' caso contrário. Não há agregação por cliente: a tabela de saída tem uma linha por
#' registro de `CARTEIRA_CLIENTE_META` no mês de `dataFeature`.
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_CARTEIRA_CLIENTE_META_{SUFIXO}`, executa a consulta no Oracle por meio de
#' `dbplyr` e grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela
#' anterior de mesmo nome. A função é descoberta pelos pipelines de dados por meio do
#' prefixo `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo após a junção em
#' `Generate_IM_ML_FEATURE_STORE()`. Se houver mais de um registro por cliente no mês, a
#' junção na feature store replica as linhas desse cliente.
#'
#' Os argumentos `janelaAgregacao`, `janelaHistorico`, `dataAgregacaoInicial`,
#' `dataAgregacaoFinal`, `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no
#' corpo da função; existem para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_CARTEIRA_CLIENTE_META,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_CARTEIRA_CLIENTE_META_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_CARTEIRA_CLIENTE_META,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_CARTEIRA_CLIENTE_META_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_CARTEIRA_CLIENTE_META_{SUFIXO}` no
#'   Oracle.
#'
#' @section Linhagem de Dados:
#' +---------------------+--------------------------------------------------+
#' | Elemento            | Valor                                            |
#' +=====================+==================================================+
#' | Tabelas de origem   | `CARTEIRA_CLIENTE_META`, `tabelaClientesValidos` |
#' +---------------------+--------------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA == dataFeature`                 |
#' +---------------------+--------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`                              |
#' +---------------------+--------------------------------------------------+
#' | Tabelas temporárias | nenhuma                                          |
#' +---------------------+--------------------------------------------------+
#' | Tabela de saída     | `IM_ML_CARTEIRA_CLIENTE_META_{SUFIXO}`           |
#' +---------------------+--------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +---------------------+---------------------------------------------------------------+
#' | Coluna              | Descrição                                                     |
#' +=====================+===============================================================+
#' | `SEQUENCIA_CLIENTE` | Identificador do cliente                                      |
#' +---------------------+---------------------------------------------------------------+
#' | `Ve2FunciBanrisul`  | Lógico: `TRUE` quando há funcionário vinculado                |
#' |                     | (`COD_FUNCIONARIO` não nulo)                                  |
#' +---------------------+---------------------------------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `""`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_CARTEIRA_CLIENTE_META_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_CARTEIRA_CLIENTE_META(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_CARTEIRA_CLIENTE_META <- function(
    tabelaClientesValidos,
    sufixoTabela = "",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_CARTEIRA_CLIENTE_META_", str_to_upper(sufixoTabela))
  
  ## Selecao e gravacao do vinculo com funcionario
  # Carrega dados
  Db("CARTEIRA_CLIENTE_META") |> 
    filter(
      (DATA_REFERENCIA == dataFeature)
    ) |> 
    transmute(
      SEQUENCIA_CLIENTE = !!DbCastTo_SEQUENCIA_CLIENTE(SEQUENCIA_CLIENTE),
      Ve2FunciBanrisul = ifelse(
        test = !is.na(COD_FUNCIONARIO),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      )
    ) |>
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |>
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  ## Retorno do nome da tabela
  # Nome da tabela
  return(invisible(tabelaFeature))
}
####
## Fim
#
