#' @title Gerar o Feature Group de Dados Cadastrais do Cliente
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_CLIENTE(
#'   tabelaClientesValidos,
#'   sufixoTabela = "",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Gera sexo e idade em anos completos de cada cliente da tabela `CLIENTE`, com a idade
#' calculada no último dia do mês de referência.
#'
#' @details
#' A idade é calculada em SQL:
#' \deqn{\mathrm{Idade} = \lfloor \mathrm{MB}(\mathrm{fim}(d), n) / 12 \rfloor}
#' em que \eqn{\mathrm{MB}} é `MONTHS_BETWEEN`, \eqn{d} é `dataFeature` e \eqn{n} é
#' `DATA_NASC_FUND`.
#'
#' A consulta não é restrita aos clientes válidos: a tabela de saída contém todos os
#' registros de `CLIENTE`. A restrição à população ocorre na junção à esquerda feita por
#' `Generate_IM_ML_FEATURE_STORE()`.
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída `IM_ML_CLIENTE_{SUFIXO}`,
#' executa a consulta no Oracle por meio de `dbplyr` e grava o resultado com
#' `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior de mesmo nome. A função
#' é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' ::: {.callout-important}
#' <i class="fa-solid fa-circle-exclamation"></i> **Expressão SQL com Defeito:**
#' No texto passado a `glue_sql()`, o nome `dataFeature` aparece seguido de uma chave de
#' fechamento, sem a chave de abertura correspondente. O `glue` mantém o trecho literal, e
#' o Oracle recebe o nome da variável e a chave como texto SQL, o que constitui uma
#' expressão inválida. Por isso, o valor de `dataFeature` não é interpolado e a criação da
#' tabela falha.
#' :::
#'
#' Os argumentos `tabelaClientesValidos`, `dataFeature`, `janelaAgregacao`,
#' `janelaHistorico`, `dataAgregacaoInicial`, `dataAgregacaoFinal`,
#' `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no corpo da função; existem
#' para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_CLIENTE,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_CLIENTE_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_CLIENTE,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_CLIENTE_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_CLIENTE_{SUFIXO}` no Oracle.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------+
#' | Elemento            | Valor                                             |
#' +=====================+===================================================+
#' | Tabelas de origem   | `CLIENTE`                                         |
#' +---------------------+---------------------------------------------------+
#' | Filtro de período   | nenhum; a idade usa o fim do mês de `dataFeature` |
#' +---------------------+---------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`                               |
#' +---------------------+---------------------------------------------------+
#' | Tabelas temporárias | nenhuma                                           |
#' +---------------------+---------------------------------------------------+
#' | Tabela de saída     | `IM_ML_CLIENTE_{SUFIXO}`                          |
#' +---------------------+---------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +---------------------+--------------------------------------------------------------+
#' | Coluna              | Descrição                                                    |
#' +=====================+==============================================================+
#' | `SEQUENCIA_CLIENTE` | Identificador do cliente                                     |
#' +---------------------+--------------------------------------------------------------+
#' | `Sexo`              | Sexo cadastral (`SEXO`); texto de um caractere               |
#' +---------------------+--------------------------------------------------------------+
#' | `Idade`             | Idade em anos completos no fim do mês de referência; inteiro |
#' +---------------------+--------------------------------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`. Não utilizado no corpo da função.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `""`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`. Não
#'   utilizado no corpo da função.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_CLIENTE_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Oracle Database SQL Language Reference: MONTHS_BETWEEN e LAST_DAY.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/sqlrf/}
#'
#' glue: Interpreted String Literals, glue_sql.
#' \url{https://glue.tidyverse.org/reference/glue_sql.html}
#'
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_CLIENTE(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_CLIENTE <- function(
    tabelaClientesValidos,
    sufixoTabela = "",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_CLIENTE_", str_to_upper(sufixoTabela))
  
  ## Calculo de sexo e idade
  # Gera preditores da tabela CLIENTE
  Db("CLIENTE") |> 
    mutate(
      Idade = !!glue_sql("
        TRUNC(
          MONTHS_BETWEEN(
            LAST_DAY(TO_DATE(dataFeature},   'YYYY-MM-DD')),
                     TO_DATE(DATA_NASC_FUND, 'YYYY-MM-DD')
          ) / 12
        )",
        .con = ConexaoDB()
      )
    ) |> 
    select(SEQUENCIA_CLIENTE, Sexo = SEXO, Idade) |> 
    DbCast(
      SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE(),
      Sexo = DbCastToCharacter(1L),
      Idade = DbCastToInteger(4L)
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  ## Retorno do nome da tabela
  # Retorna sucesso invisivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
