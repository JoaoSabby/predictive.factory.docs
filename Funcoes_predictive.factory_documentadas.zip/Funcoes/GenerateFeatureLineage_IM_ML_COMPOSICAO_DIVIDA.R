#' @title Gerar o Feature Group de Composição de Dívida
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_COMPOSICAO_DIVIDA(
#'   tabelaClientesValidos,
#'   sufixoTabela = "TREINO",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Identifica os clientes válidos com conta de composição de dívida, consignada ou não
#' consignada, em algum mês da janela de agregação.
#'
#' @details
#' As contas de composição de dívida são as dos subgrupos de gestão `11901` (consignada) e
#' `11902` (não consignada), obtidas da hierarquia `CONTA`, `PRODUTO_GESTAO_BIB` e
#' `SUBGRUPO_GESTAO_BIB` e gravadas na tabela temporária `IM_TMP_CDT_{SUFIXO}`. São
#' selecionados os clientes distintos com essas contas em `MTB_EFETIVO_MENSAL`, com
#' `COD_CONTA_BIB` positivo, na janela de agregação.
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_COMPOSICAO_DIVIDA_{SUFIXO}`, executa a consulta no Oracle por meio de `dbplyr` e
#' grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior de
#' mesmo nome. A função é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' A tabela contém apenas os clientes em que a condição foi observada, com o indicador
#' igual a `TRUE`. Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo
#' após a junção em `Generate_IM_ML_FEATURE_STORE()`.
#'
#' Os argumentos `dataFeature`, `janelaAgregacao`, `janelaHistorico`,
#' `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no corpo da função; existem
#' para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_COMPOSICAO_DIVIDA,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_COMPOSICAO_DIVIDA_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_COMPOSICAO_DIVIDA,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_COMPOSICAO_DIVIDA_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_COMPOSICAO_DIVIDA_{SUFIXO}` no Oracle.
#' - cria e remove a tabela temporária `IM_TMP_CDT_{SUFIXO}`, por meio de
#'   `DbCleanTablesMemory()`.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `CONTA`, `PRODUTO_GESTAO_BIB`, `SUBGRUPO_GESTAO_BIB`,         |
#' |                     | `MTB_EFETIVO_MENSAL`, `tabelaClientesValidos`                 |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA` entre `dataAgregacaoInicial` e              |
#' |                     | `dataAgregacaoFinal`                                          |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`; `COD_CONTA_BIB` com `COD_CONTA`          |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | `IM_TMP_CDT_{SUFIXO}`                                         |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_COMPOSICAO_DIVIDA_{SUFIXO}`                            |
#' +---------------------+---------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +-----------------------------+-------------------------------------------------------+
#' | Coluna                      | Descrição                                             |
#' +=============================+=======================================================+
#' | `SEQUENCIA_CLIENTE`         | Identificador do cliente                              |
#' +-----------------------------+-------------------------------------------------------+
#' | `VeqPossuiComposicaoDivida` | Lógico: `TRUE` para clientes com conta de composição  |
#' |                             | de dívida na janela                                   |
#' +-----------------------------+-------------------------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `"TREINO"`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`. Não
#'   utilizado no corpo da função.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_COMPOSICAO_DIVIDA_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_COMPOSICAO_DIVIDA(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_COMPOSICAO_DIVIDA <- function(
    tabelaClientesValidos,
    sufixoTabela = "TREINO",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_COMPOSICAO_DIVIDA_", sufixoTabela)
  
  ## Criacao da tabela temporaria de contas
  # Tabelas temporarias
  tabelaTmpCDT <- str_c("IM_TMP_CDT_", sufixoTabela)
  
  # Tabela de conta
  Db("CONTA") |> 
    select(COD_CONTA, COD_PRODUTO_GESTAO_BIB) |> 
    inner_join(
      Db("PRODUTO_GESTAO_BIB") |> 
        select(COD_PRODUTO_GESTAO, COD_SUBGRUPO_GESTAO) |>
        inner_join(
          Db("SUBGRUPO_GESTAO_BIB") |>
            select(COD_SUBGRUPO_GESTAO, COD_GRUPO_GESTAO_BIB),
          by = "COD_SUBGRUPO_GESTAO"
        ),
      by = c("COD_PRODUTO_GESTAO_BIB" = "COD_PRODUTO_GESTAO")
    ) |> 
    # Codigos que podem estar em tabela de configuração também
    # SUBGRUPOS "COMPOSICAO DIVIDA-CONSIGNADA" E "COMPOSICAO DIVIDA-NAO CONSIG"
    filter(
      COD_SUBGRUPO_GESTAO %in% c(
        11901L, 11902L
      )
    ) |> 
    DbCast(
      COD_CONTA = DbCastTo_COD_CONTA_BIB(),
      COD_PRODUTO_GESTAO_BIB = DbCastTo_COD_PRODUTO_GESTAO_BIB(),
      COD_SUBGRUPO_GESTAO = DbCastTo_COD_SUBGRUPO_GESTAO(), 
      COD_GRUPO_GESTAO_BIB = DbCastTo_COD_GRUPO_GESTAO_BIB()
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaTmpCDT)
  
  ## Selecao dos clientes e gravacao
  # Consulta clientes na tabela MTB_EFETIVO_MENSAL filtrando as datas inicial e final
  Db("MTB_EFETIVO_MENSAL") |> 
    select(SEQUENCIA_CLIENTE, DATA_REFERENCIA, COD_CONTA_BIB) |> 
    filter(
      !is.na(COD_CONTA_BIB),
      (COD_CONTA_BIB > 0L),
      (DATA_REFERENCIA >= dataAgregacaoInicial),
      (DATA_REFERENCIA <= dataAgregacaoFinal)
    ) |> 
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    semi_join(
      Db(tabelaTmpCDT),
      by = c("COD_CONTA_BIB" = "COD_CONTA")
    ) |> 
    distinct(SEQUENCIA_CLIENTE) |> 
    transmute(
      SEQUENCIA_CLIENTE = !!DbCastTo_SEQUENCIA_CLIENTE(SEQUENCIA_CLIENTE),
      VeqPossuiComposicaoDivida = !!DbCastToLogical(TRUE)
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  ## Remocao da tabela temporaria
  # Remove tabela temporaria
  DbCleanTablesMemory(tabelaTmpCDT)
  
  ## Retorno do nome da tabela
  # Retorna sucesso invisiveL
  return(invisible(tabelaFeature)) 
}
####
## Fim
#
