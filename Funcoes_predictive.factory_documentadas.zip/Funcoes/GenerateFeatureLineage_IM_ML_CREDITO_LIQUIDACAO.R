#' @title Gerar o Feature Group de Crédito em Liquidação
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_CREDITO_LIQUIDACAO(
#'   tabelaClientesValidos,
#'   sufixoTabela = "",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Identifica os clientes válidos com operação em crédito em liquidação na data de
#' referência, isto é, operações de `OPERACAO_BANRI` com sistema gestor `BRW`.
#'
#' @details
#' Quando uma operação passa para crédito em liquidação, o sistema gestor passa a ser o
#' `BRW`. A função seleciona os clientes distintos com `SISTEMA_ORIGEM == "BRW"` no mês de
#' `dataFeature`.
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_CREDITO_LIQUIDACAO_{SUFIXO}`, executa a consulta no Oracle por meio de `dbplyr`
#' e grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior
#' de mesmo nome. A função é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' A tabela contém apenas os clientes em que a condição foi observada, com o indicador
#' igual a `TRUE`. Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo
#' após a junção em `Generate_IM_ML_FEATURE_STORE()`.
#'
#' Os argumentos `janelaAgregacao`, `janelaHistorico`, `dataAgregacaoInicial`,
#' `dataAgregacaoFinal`, `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no
#' corpo da função; existem para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_CREDITO_LIQUIDACAO,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_CREDITO_LIQUIDACAO_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_CREDITO_LIQUIDACAO,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_CREDITO_LIQUIDACAO_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_CREDITO_LIQUIDACAO_{SUFIXO}` no Oracle.
#'
#' @section Linhagem de Dados:
#' +---------------------+-------------------------------------------+
#' | Elemento            | Valor                                     |
#' +=====================+===========================================+
#' | Tabelas de origem   | `OPERACAO_BANRI`, `tabelaClientesValidos` |
#' +---------------------+-------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA == dataFeature`          |
#' +---------------------+-------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`                       |
#' +---------------------+-------------------------------------------+
#' | Tabelas temporárias | nenhuma                                   |
#' +---------------------+-------------------------------------------+
#' | Tabela de saída     | `IM_ML_CREDITO_LIQUIDACAO_{SUFIXO}`       |
#' +---------------------+-------------------------------------------+
#'
#' @section Dicionário de Features:
#' +------------------------------+------------------------------------------------------+
#' | Coluna                       | Descrição                                            |
#' +==============================+======================================================+
#' | `SEQUENCIA_CLIENTE`          | Identificador do cliente                             |
#' +------------------------------+------------------------------------------------------+
#' | `VekPossuiCreditoLiquidacao` | Lógico: `TRUE` para clientes com operação em crédito |
#' |                              | em liquidação                                        |
#' +------------------------------+------------------------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `""`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_CREDITO_LIQUIDACAO_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_CREDITO_LIQUIDACAO(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_CREDITO_LIQUIDACAO <- function(
    tabelaClientesValidos,
    sufixoTabela = "",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_CREDITO_LIQUIDACAO_", str_to_upper(sufixoTabela))
  
  ## Selecao dos clientes em credito em liquidacao
  # Quando uma operação vai para CL (Credito Liquidacao), o sistema gestor passa a ser o BRW
  Db("OPERACAO_BANRI") |> 
    filter(
      (SISTEMA_ORIGEM == "BRW"),
      (DATA_REFERENCIA == dataFeature)
    ) |>
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |>
    distinct(SEQUENCIA_CLIENTE) |> 
    transmute(
      SEQUENCIA_CLIENTE = !!DbCastTo_SEQUENCIA_CLIENTE(SEQUENCIA_CLIENTE),
      VekPossuiCreditoLiquidacao = !!DbCastToLogical(TRUE)
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)

  ## Retorno do nome da tabela
  # Retorna sucesso invisivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
