#' @title Gerar o Feature Group de Fonte de Renda
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_FONTE_RENDA(
#'   tabelaClientesValidos,
#'   sufixoTabela = "TREINO",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Soma, por cliente válido, o valor de rendimento e o valor de folha de pagamento na data
#' de referência, excluindo clientes sem renda e valores extremos.
#'
#' @details
#' Após a soma por cliente, são calculados os percentis 99 das duas somas com
#' `DbQuantile()`, \eqn{q_{0,99}^{R}} e \eqn{q_{0,99}^{F}}. Um cliente permanece na tabela
#' quando:
#' \deqn{(R_c > 0 \lor F_c > 0) \land R_c < q_{0,99}^{R} \land F_c < q_{0,99}^{F}}
#' em que \eqn{R_c} é o rendimento e \eqn{F_c} é a folha de pagamento do cliente.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **Tratamento de Extremos:**
#' Os valores extremos não são limitados ao percentil: os clientes acima do corte são
#' removidos da tabela e recebem nulos na feature store, assim como os clientes sem renda.
#' :::
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_FONTE_RENDA_{SUFIXO}`, executa a consulta no Oracle por meio de `dbplyr` e grava
#' o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior de mesmo
#' nome. A função é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo após a junção em
#' `Generate_IM_ML_FEATURE_STORE()`.
#'
#' Os argumentos `janelaAgregacao`, `janelaHistorico`, `dataAgregacaoInicial`,
#' `dataAgregacaoFinal`, `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no
#' corpo da função; existem para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_FONTE_RENDA,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_FONTE_RENDA_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_FONTE_RENDA,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_FONTE_RENDA_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_FONTE_RENDA_{SUFIXO}` no Oracle.
#'
#' @section Linhagem de Dados:
#' +---------------------+----------------------------------------+
#' | Elemento            | Valor                                  |
#' +=====================+========================================+
#' | Tabelas de origem   | `FONTE_RENDA`, `tabelaClientesValidos` |
#' +---------------------+----------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA == dataFeature`       |
#' +---------------------+----------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`                    |
#' +---------------------+----------------------------------------+
#' | Tabelas temporárias | nenhuma                                |
#' +---------------------+----------------------------------------+
#' | Tabela de saída     | `IM_ML_FONTE_RENDA_{SUFIXO}`           |
#' +---------------------+----------------------------------------+
#'
#' @section Dicionário de Features:
#' +----------------------+----------------------------------------------------+
#' | Coluna               | Descrição                                          |
#' +======================+====================================================+
#' | `SEQUENCIA_CLIENTE`  | Identificador do cliente                           |
#' +----------------------+----------------------------------------------------+
#' | `Ve6ValorRendimento` | Soma de `VALOR_RENDIMENTO` no mês; decimal (12, 2) |
#' +----------------------+----------------------------------------------------+
#' | `Ve6ValorFolhaPgto`  | Soma de `VALOR_FOLHA_PGTO` no mês; decimal (12, 2) |
#' +----------------------+----------------------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `"TREINO"`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_FONTE_RENDA_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Hyndman, R. J., & Fan, Y. (1996). Sample quantiles in statistical packages. The
#' American Statistician, 50(4), 361-365.
#' \url{https://doi.org/10.1080/00031305.1996.10473566}
#'
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_FONTE_RENDA(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_FONTE_RENDA <- function(
    tabelaClientesValidos,
    sufixoTabela = "TREINO",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1L])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_FONTE_RENDA_", str_to_upper(sufixoTabela))
  
  ## Agregacao, corte de extremos e gravacao
  # Carrega dados referentes a fonte de renda
  Db("FONTE_RENDA") |> 
    filter(
      (DATA_REFERENCIA == dataFeature)
    ) |> 
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    group_by(SEQUENCIA_CLIENTE) |> 
    summarise(
      Ve6ValorRendimento = sum(VALOR_RENDIMENTO, na.rm = TRUE),
      Ve6ValorFolhaPgto = sum(VALOR_FOLHA_PGTO, na.rm = TRUE)
    ) |>
    ungroup() |> 
    mutate(
      TetoRendimento = !!DbQuantile(Ve6ValorRendimento, 0.99),
      TetoFolha = !!DbQuantile(Ve6ValorFolhaPgto, 0.99)
    ) |>
    filter(
      (Ve6ValorRendimento > 0 | Ve6ValorFolhaPgto > 0),
      (Ve6ValorRendimento < TetoRendimento),
      (Ve6ValorFolhaPgto < TetoFolha)
    ) |> 
    transmute(
      SEQUENCIA_CLIENTE = !!DbCastTo_SEQUENCIA_CLIENTE(SEQUENCIA_CLIENTE),
      Ve6ValorRendimento = !!DbCastToDouble(Ve6ValorRendimento, 12L, 2L),
      Ve6ValorFolhaPgto = !!DbCastToDouble(Ve6ValorFolhaPgto, 12L, 2L)
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  ## Retorno do nome da tabela
  # Retorna sucesso invisivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
