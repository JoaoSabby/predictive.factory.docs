#' @title Gerar o Feature Group de Agência do Cliente
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_HISTORICO_AGENCIA(
#'   tabelaClientesValidos,
#'   sufixoTabela = "",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Associa a cada cliente válido a superintendência regional, a categoria da agência e o
#' indicador de agência digital, na data de referência.
#'
#' @details
#' A agência do cliente é obtida de `POS_KPI_CLIENTE_PF_MES` no mês de `dataFeature`. A
#' categoria vem de `HISTORICO_AGENCIA` no mesmo mês, por `left_join()` entre
#' `COD_AGENCIA` e `COD_VISAO`, considerando apenas categorias não nulas. A agência `1800`
#' é tratada como agência digital; quando `COD_AGENCIA` é nulo, o indicador é nulo, pela
#' tradução de `ifelse()` em `CASE WHEN` sem ramo `ELSE`.
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_HISTORICO_AGENCIA_{SUFIXO}`, executa a consulta no Oracle por meio de `dbplyr` e
#' grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior de
#' mesmo nome. A função é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' A tabela de origem é filtrada no mês de `dataFeature` sem agregação por cliente;
#' espera-se um registro por cliente no mês. Clientes ausentes da tabela recebem valor
#' nulo nas colunas deste grupo após a junção em `Generate_IM_ML_FEATURE_STORE()`. Se
#' `HISTORICO_AGENCIA` tiver mais de uma categoria não nula para a mesma agência no mês, a
#' junção replica as linhas do cliente.
#'
#' Os argumentos `janelaAgregacao`, `janelaHistorico`, `dataAgregacaoInicial`,
#' `dataAgregacaoFinal`, `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no
#' corpo da função; existem para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_HISTORICO_AGENCIA,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_HISTORICO_AGENCIA_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_HISTORICO_AGENCIA,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_HISTORICO_AGENCIA_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_HISTORICO_AGENCIA_{SUFIXO}` no Oracle.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `POS_KPI_CLIENTE_PF_MES`, `HISTORICO_AGENCIA`,                |
#' |                     | `tabelaClientesValidos`                                       |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA == dataFeature` nas duas tabelas             |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`; `COD_AGENCIA` com `COD_VISAO`            |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | nenhuma                                                       |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_HISTORICO_AGENCIA_{SUFIXO}`                            |
#' +---------------------+---------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +---------------------+---------------------------------------------------------------+
#' | Coluna              | Descrição                                                     |
#' +=====================+===============================================================+
#' | `SEQUENCIA_CLIENTE` | Identificador do cliente                                      |
#' +---------------------+---------------------------------------------------------------+
#' | `Vf4Sureg`          | Código da superintendência regional (`COD_SUREG`); texto de   |
#' |                     | até quatro caracteres                                         |
#' +---------------------+---------------------------------------------------------------+
#' | `Vf4Categoria`      | Categoria da agência (`CATEGORIA`); texto de um caractere     |
#' +---------------------+---------------------------------------------------------------+
#' | `AgenciaDigital`    | Lógico: `TRUE` quando `COD_AGENCIA == 1800`                   |
#' +---------------------+---------------------------------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `""`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_HISTORICO_AGENCIA_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_HISTORICO_AGENCIA(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_HISTORICO_AGENCIA <- function(
    tabelaClientesValidos,
    sufixoTabela = "",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_HISTORICO_AGENCIA_", str_to_upper(sufixoTabela))
  
  ## Associacao da agencia e gravacao
  # Busca dados
  Db("POS_KPI_CLIENTE_PF_MES") |> 
    filter(
      (DATA_REFERENCIA == dataFeature)
    ) |> 
    select(SEQUENCIA_CLIENTE, COD_AGENCIA, COD_SUREG) |> 
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    left_join(
      Db("HISTORICO_AGENCIA") |> 
        filter(
          !is.na(CATEGORIA),
          (DATA_REFERENCIA == dataFeature)
        ) |> 
        select(COD_AGENCIA = COD_VISAO, CATEGORIA),
      by = "COD_AGENCIA"
    ) |> 
    transmute(
      SEQUENCIA_CLIENTE = !!DbCastTo_SEQUENCIA_CLIENTE(SEQUENCIA_CLIENTE),
      Vf4Sureg = !!DbCastToCharacter(COD_SUREG, 4L),
      Vf4Categoria = !!DbCastToCharacter(CATEGORIA, 1L),
      AgenciaDigital = ifelse(
        test = (COD_AGENCIA == 1800L),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      )
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  ## Retorno do nome da tabela
  # Retorna sucesso invisivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
