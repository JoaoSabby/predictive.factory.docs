#' @title Gerar o Feature Group de Portabilidade de Crédito
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_PORTABILIDADE_CREDITO(
#'   tabelaClientesValidos,
#'   sufixoTabela = "",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Calcula, para cada cliente válido, as medianas mensais dos valores de portabilidade de
#' crédito de entrada e de saída na janela de agregação, o valor líquido de saída e
#' indicadores do tipo de portabilidade.
#'
#' @details
#' Os pedidos de `PORTABILIDADE_BUO` com `VALOR_REF_SLD_CTB_DEV` positivo são
#' classificados pelo CNPJ base da instituição: `92702067` (Banrisul) identifica saída do
#' Banrisul; os demais, entrada no Banrisul. As etapas são:
#'
#' #. truncamento de `DATA_SOLICITACAO` ao mês;
#' #. remoção dos pedidos com valor igual ou superior ao percentil 99 \eqn{q_{0,99}}
#'    calculado sobre todos os pedidos da janela, por `DbQuantile()`;
#' #. soma por cliente, mês e sentido;
#' #. mediana aproximada por cliente e sentido;
#' #. pivotamento em colunas de entrada e saída, com zero para o sentido ausente.
#'
#' O valor líquido de saída é:
#' \deqn{V^{liq}_c = \tilde{S}_c - \tilde{E}_c}
#' em que \eqn{\tilde{S}_c} e \eqn{\tilde{E}_c} são as medianas mensais de saída e de
#' entrada.
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_PORTABILIDADE_CREDITO_{SUFIXO}`, executa a consulta no Oracle por meio de
#' `dbplyr` e grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela
#' anterior de mesmo nome. A função é descoberta pelos pipelines de dados por meio do
#' prefixo `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo após a junção em
#' `Generate_IM_ML_FEATURE_STORE()`.
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Indicador Sempre Falso:**
#' `Vh5TipoPortabilidadeCredito_ES` é `TRUE` apenas quando entrada e saída são iguais a
#' zero. Após o pivotamento, todo cliente tem ao menos um dos valores positivo, de modo
#' que o indicador resulta sempre `FALSE`. Em
#' `GenerateFeatureLineage_IM_ML_PORTABILIDADE_SALARIO()`, o indicador equivalente exige
#' os dois valores positivos.
#' :::
#'
#' Os argumentos `dataFeature`, `janelaAgregacao`, `janelaHistorico`,
#' `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no corpo da função; existem
#' para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_PORTABILIDADE_CREDITO,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_PORTABILIDADE_CREDITO_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_PORTABILIDADE_CREDITO,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_PORTABILIDADE_CREDITO_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_PORTABILIDADE_CREDITO_{SUFIXO}` no
#'   Oracle.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `PORTABILIDADE_BUO`, `tabelaClientesValidos`                  |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | `DATA_SOLICITACAO` entre `dataAgregacaoInicial` e             |
#' |                     | `dataAgregacaoFinal`                                          |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`                                           |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | nenhuma                                                       |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_PORTABILIDADE_CREDITO_{SUFIXO}`                        |
#' +---------------------+---------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +--------------------------------------------+----------------------------------------+
#' | Coluna                                     | Descrição                              |
#' +============================================+========================================+
#' | `SEQUENCIA_CLIENTE`                        | Identificador do cliente               |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh5ValorPortabilidadeCreditoEntrada`      | Mediana mensal do valor de             |
#' |                                            | portabilidade de entrada; decimal (16, |
#' |                                            | 2)                                     |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh5ValorPortabilidadeCreditoSaida`        | Mediana mensal do valor de             |
#' |                                            | portabilidade de saída; decimal (16,   |
#' |                                            | 2)                                     |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh5TipoPortabilidadeCredito_E`            | Lógico: somente entrada (entrada       |
#' |                                            | positiva e saída zero)                 |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh5TipoPortabilidadeCredito_S`            | Lógico: somente saída (entrada zero e  |
#' |                                            | saída positiva)                        |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh5TipoPortabilidadeCredito_ES`           | Lógico: entrada e saída iguais a zero  |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh5ValorLiquidoPortabilidadeCreditoSaida` | Saída menos entrada; decimal (10, 2)   |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh5PossuiPortabilidadeCreditoSaida`       | Lógico: valor líquido de saída         |
#' |                                            | positivo                               |
#' +--------------------------------------------+----------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `""`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`. Não
#'   utilizado no corpo da função.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_PORTABILIDADE_CREDITO_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Banco Central do Brasil. Portabilidade de crédito.
#' \url{https://www.bcb.gov.br/cidadaniafinanceira/portabilidade}
#'
#' Hyndman, R. J., & Fan, Y. (1996). Sample quantiles in statistical packages. The
#' American Statistician, 50(4), 361-365.
#' \url{https://doi.org/10.1080/00031305.1996.10473566}
#'
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_PORTABILIDADE_CREDITO(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_PORTABILIDADE_CREDITO <- function(
    tabelaClientesValidos,
    sufixoTabela = "",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){

  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1L])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_PORTABILIDADE_CREDITO_", str_to_upper(sufixoTabela))
  
  ## Agregacao, pivotamento e gravacao
  # Busca dados
  Db("PORTABILIDADE_BUO") |> 
    select(
      DATA_REFERENCIA = DATA_SOLICITACAO,
      SEQUENCIA_CLIENTE,
      Valor = VALOR_REF_SLD_CTB_DEV,
      CNPJ_Base = CNPJ_BASE_IFO
    ) |> 
    filter(
      (DATA_REFERENCIA >= dataAgregacaoInicial),
      (DATA_REFERENCIA <= dataAgregacaoFinal),
      (Valor > 0)
    ) |>
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    mutate(
      DATA_REFERENCIA = TRUNC(DATA_REFERENCIA,"MM"),
      CNPJ_Banrisul = ifelse(
        test = (CNPJ_Base == 92702067L), 
        yes = !!DbCastToLogical(TRUE), # Saida do Banrisul
        no = !!DbCastToLogical(FALSE)  # Entrada no Banrisul
      ),
      TetoValor = !!DbQuantile(Valor, 0.99)
    ) |> 
    filter(
      Valor < TetoValor
    ) |> 
    group_by(SEQUENCIA_CLIENTE, DATA_REFERENCIA, CNPJ_Banrisul) |> 
    summarise(
      Valor = sum(Valor, na.rm = TRUE)
    ) |> 
    ungroup() |> 
    group_by(SEQUENCIA_CLIENTE, CNPJ_Banrisul) |> 
    summarise(
      Valor = APPROX_MEDIAN(Valor) 
    ) |>   
    ungroup() |>
    mutate(
      Vh5TipoPortabilidadeCredito = ifelse(
        test = (CNPJ_Banrisul == 1L),
        yes = "Saida",
        no = "Entrada"
      )
    ) |> 
    select(-CNPJ_Banrisul) |> 
    DbPivotWider(
      names_from = Vh5TipoPortabilidadeCredito,
      values_from = Valor,
      values_fill = 0,
      names_prefix = "Vh5ValorPortabilidadeCredito"
    ) |> 
    mutate(
      SEQUENCIA_CLIENTE,
      Vh5TipoPortabilidadeCredito_E = ifelse(
        test = ((Vh5ValorPortabilidadeCreditoEntrada > 0) & (Vh5ValorPortabilidadeCreditoSaida == 0)),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      ),
      Vh5TipoPortabilidadeCredito_S = ifelse(
        test = ((Vh5ValorPortabilidadeCreditoEntrada == 0) & (Vh5ValorPortabilidadeCreditoSaida > 0)),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      ),
      Vh5TipoPortabilidadeCredito_ES = ifelse(
        test = ((Vh5ValorPortabilidadeCreditoEntrada == 0) & (Vh5ValorPortabilidadeCreditoSaida == 0)),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      ),
      Vh5ValorLiquidoPortabilidadeCreditoSaida = (Vh5ValorPortabilidadeCreditoSaida - Vh5ValorPortabilidadeCreditoEntrada),
      Vh5PossuiPortabilidadeCreditoSaida = ifelse(
        test = (Vh5ValorLiquidoPortabilidadeCreditoSaida > 0),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      )
    ) |> 
    DbCast(
      SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE(),
      Vh5ValorPortabilidadeCreditoEntrada = DbCastToDouble(16, 2),
      Vh5ValorPortabilidadeCreditoSaida = DbCastToDouble(16, 2),
      Vh5TipoPortabilidadeCredito_E = DbCastToLogical(),
      Vh5TipoPortabilidadeCredito_S = DbCastToLogical(),
      Vh5TipoPortabilidadeCredito_ES = DbCastToLogical(),
      Vh5ValorLiquidoPortabilidadeCreditoSaida = DbCastToDouble(10, 2),
      Vh5PossuiPortabilidadeCreditoSaida = DbCastToLogical()
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  ## Retorno do nome da tabela
  # Retorna sucesso invisivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
