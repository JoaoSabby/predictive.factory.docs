#' @title Gerar o Feature Group de Portabilidade de Salário
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_PORTABILIDADE_SALARIO(
#'   tabelaClientesValidos,
#'   sufixoTabela = "",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Calcula, para cada cliente válido, as medianas mensais dos valores de portabilidade de
#' salário de entrada e de saída na janela de agregação, o valor líquido de saída e
#' indicadores do tipo de portabilidade.
#'
#' @details
#' São considerados os registros de `CONTA_REGISTRO_BHV` com `VALOR` positivo e
#' `TIPO_MOVIMENTACAO` igual a `"E"` (entrada) ou `"S"` (saída). As etapas são:
#'
#' #. conversão de `DATA_REFERENCIA` para ano e mês, por `DbDataAnoMes()`;
#' #. soma por cliente, mês e sentido;
#' #. mediana aproximada por cliente e sentido;
#' #. pivotamento em colunas de entrada e saída, com zero para o sentido ausente.
#'
#' O valor líquido de saída é:
#' \deqn{V^{liq}_c = \tilde{S}_c - \tilde{E}_c}
#' em que \eqn{\tilde{S}_c} e \eqn{\tilde{E}_c} são as medianas mensais de saída e de
#' entrada. Não há corte de valores extremos.
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_PORTABILIDADE_SALARIO_{SUFIXO}`, executa a consulta no Oracle por meio de
#' `dbplyr` e grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela
#' anterior de mesmo nome. A função é descoberta pelos pipelines de dados por meio do
#' prefixo `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo após a junção em
#' `Generate_IM_ML_FEATURE_STORE()`.
#'
#' Os argumentos `dataFeature`, `janelaAgregacao`, `janelaHistorico`,
#' `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no corpo da função; existem
#' para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_PORTABILIDADE_SALARIO,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_PORTABILIDADE_SALARIO_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_PORTABILIDADE_SALARIO,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_PORTABILIDADE_SALARIO_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_PORTABILIDADE_SALARIO_{SUFIXO}` no
#'   Oracle.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `CONTA_REGISTRO_BHV`, `tabelaClientesValidos`                 |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA` entre `dataAgregacaoInicial` e              |
#' |                     | `dataAgregacaoFinal`                                          |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`                                           |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | nenhuma                                                       |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_PORTABILIDADE_SALARIO_{SUFIXO}`                        |
#' +---------------------+---------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +--------------------------------------------+----------------------------------------+
#' | Coluna                                     | Descrição                              |
#' +============================================+========================================+
#' | `SEQUENCIA_CLIENTE`                        | Identificador do cliente               |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh4ValorPortabilidadeSalarioEntrada`      | Mediana mensal do valor de entrada;    |
#' |                                            | decimal (10, 2)                        |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh4ValorPortabilidadeSalarioSaida`        | Mediana mensal do valor de saída;      |
#' |                                            | decimal (10, 2)                        |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh4TipoPortabilidadeSalario_E`            | Lógico: somente entrada                |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh4TipoPortabilidadeSalario_S`            | Lógico: somente saída                  |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh4TipoPortabilidadeSalario_ES`           | Lógico: entrada e saída positivas      |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh4ValorLiquidoPortabilidadeSalarioSaida` | Saída menos entrada; decimal (10, 2)   |
#' +--------------------------------------------+----------------------------------------+
#' | `Vh4PossuiPortabilidadeSalarioSaida`       | Lógico: valor líquido de saída         |
#' |                                            | positivo                               |
#' +--------------------------------------------+----------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `""`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`. Não
#'   utilizado no corpo da função.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_PORTABILIDADE_SALARIO_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Banco Central do Brasil. Portabilidade de salário.
#' \url{https://www.bcb.gov.br/cidadaniafinanceira/portabilidade}
#'
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_PORTABILIDADE_SALARIO(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_PORTABILIDADE_SALARIO <- function(
    tabelaClientesValidos,
    sufixoTabela = "",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_PORTABILIDADE_SALARIO_", str_to_upper(sufixoTabela))
  
  ## Agregacao, pivotamento e gravacao
  # Busca dados
  Db("CONTA_REGISTRO_BHV") |> 
    filter(
      !is.na(VALOR),
      (VALOR > 0),
      TIPO_MOVIMENTACAO %in% c("E", "S"), # Entrada ou Saida
      (DATA_REFERENCIA >= dataAgregacaoInicial),
      (DATA_REFERENCIA <= dataAgregacaoFinal)
    ) |> 
    transmute(
      SEQUENCIA_CLIENTE = !!DbCastTo_SEQUENCIA_CLIENTE(SEQUENCIA_CLIENTE),
      DATA_REFERENCIA = !!DbDataAnoMes(DATA_REFERENCIA),
      TipoMovimentacao = ifelse(
        test = (TIPO_MOVIMENTACAO == "E"),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      ),
      Valor = VALOR
    ) |>
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    group_by(SEQUENCIA_CLIENTE, DATA_REFERENCIA, TipoMovimentacao) |> 
    summarise(
      Valor = sum(Valor, na.rm = TRUE)
    ) |> 
    ungroup() |> 
    group_by(SEQUENCIA_CLIENTE, TipoMovimentacao) |> 
    summarise(
      Valor = APPROX_MEDIAN(Valor)
    ) |> 
    ungroup() |> 
    mutate(
      Vh4ValorPortabilidadeSalario = ifelse(
        test = (TipoMovimentacao == 1L),
        yes = "Entrada",
        no = "Saida"
      )
    ) |>  
    select(-TipoMovimentacao) |> 
    DbPivotWider(
      names_from = Vh4ValorPortabilidadeSalario,
      values_from = Valor,
      values_fill = 0,
      names_prefix = "Vh4ValorPortabilidadeSalario"
    ) |> 
    mutate(
      Vh4TipoPortabilidadeSalario_E = ifelse(
        test = ((Vh4ValorPortabilidadeSalarioEntrada > 0) & (Vh4ValorPortabilidadeSalarioSaida == 0)),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      ),
      Vh4TipoPortabilidadeSalario_S = ifelse(
        test = ((Vh4ValorPortabilidadeSalarioEntrada == 0) & (Vh4ValorPortabilidadeSalarioSaida > 0)),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      ),
      Vh4TipoPortabilidadeSalario_ES = ifelse(
        test = ((Vh4ValorPortabilidadeSalarioEntrada > 0) & (Vh4ValorPortabilidadeSalarioSaida > 0)),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      ),
      Vh4ValorLiquidoPortabilidadeSalarioSaida = (Vh4ValorPortabilidadeSalarioSaida - Vh4ValorPortabilidadeSalarioEntrada),
      Vh4PossuiPortabilidadeSalarioSaida = ifelse(
        test = (Vh4ValorLiquidoPortabilidadeSalarioSaida > 0),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      )
    ) |> 
    DbCast(
      SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE(),
      Vh4ValorPortabilidadeSalarioSaida = DbCastToDouble(10, 2),
      Vh4ValorPortabilidadeSalarioEntrada = DbCastToDouble(10, 2),
      Vh4TipoPortabilidadeSalario_E = DbCastToLogical(),
      Vh4TipoPortabilidadeSalario_S = DbCastToLogical(),
      Vh4TipoPortabilidadeSalario_ES = DbCastToLogical(),
      Vh4ValorLiquidoPortabilidadeSalarioSaida = DbCastToDouble(10, 2),
      Vh4PossuiPortabilidadeSalarioSaida = DbCastToLogical()
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  ## Retorno do nome da tabela
  # Retorna sucesso invisivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
