#' @title Gerar o Feature Group de Recência, Frequência e Valor Monetário
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_RFM(
#'   sufixoTabela = "TREINO",
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   dataFeature = "2026-05-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-12-01",
#'   dataAgregacaoFinal = "2026-05-31",
#'   dataHistoricaInicial = "2023-06-01",
#'   dataHistoricaFinal = "2026-05-31"
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Calcula, para cada cliente válido, indicadores de recência, frequência e valor
#' monetário (RFM) de movimentações de crédito, de captação e de compras, a partir da
#' série mensal da janela histórica, resumidos na janela de agregação e na data de
#' referência.
#'
#' @details
#' O cálculo usa variáveis de ligação (`DbBindVariables()`) e cinco tabelas temporárias,
#' todas removidas ao final:
#'
#' #. `..._RFM_1_`: por cliente e mês da janela histórica, soma de `VALOR_PARCELA` de
#'    `MTB_EFETIVO_MENSAL` com `IND_VALOR_PARCELA == 1`, separada em crédito (`IND_CONTA
#'    == "A"`) e captação (`IND_CONTA == "C"`) por `TAXONOMIA_MISTA3`;
#' #. `..._RFM_2_`: meses com compra em `TRANSACOES` (`IND_VALOR == 1`);
#' #. `..._RFM_3_`: grade de meses de `HISTORICO_CLIENTE` do cliente, completada com zero
#'    nos meses sem movimento, e saldos defasados em um mês;
#' #. `..._RFM_4_`: recências e contagens de redução por cliente, em ordem de mês;
#' #. `..._RFM_5_`: frequências acumuladas, restritas à janela de agregação.
#'
#' Sendo \eqn{t} a posição do mês na série do cliente e \eqn{e_s} o indicador do evento no
#' mês \eqn{s}, a recência é o número de meses desde a última ocorrência:
#' \deqn{R_t = t - \max(\{s \le t : e_s = 1\} \cup \{0\})}
#' A quantidade de reduções aplica a mesma fórmula ao evento \eqn{y_s \ge y_{s-1}}, em que
#' \eqn{y} é o saldo; mede, portanto, os meses consecutivos de redução do saldo. As
#' frequências acumuladas são:
#' \deqn{F_t = \sum_{s \le t} e_s, \qquad F^{rel}_t = \mathrm{round}(F_t / t, 6)}
#'
#' A tabela de saída combina as medianas aproximadas dos saldos e do volume na janela de
#' agregação com os demais indicadores do mês de `dataFeature`.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **Limites de Tipo:**
#' As recências e as contagens de redução são convertidas para `NUMBER(2)`, o que comporta
#' séries de até 99 meses. A janela histórica deve respeitar esse limite.
#' :::
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída `IM_ML_RFM_{SUFIXO}`,
#' executa a consulta no Oracle por meio de `dbplyr` e grava o resultado com
#' `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior de mesmo nome. A função
#' é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo após a junção em
#' `Generate_IM_ML_FEATURE_STORE()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_RFM, prefix = "##", code = FALSE,
#'   narrow = TRUE), "GenerateFeatureLineage_IM_ML_RFM_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_RFM,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_RFM_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_RFM_{SUFIXO}` no Oracle.
#' - cria e remove as tabelas temporárias `IM_TMP_ML_RFM_1_{SUFIXO}` a
#'   `IM_TMP_ML_RFM_5_{SUFIXO}`, por meio de `DbDropMemoryTable()`;
#' - consulta a tabela final com `hintRESULT_CACHE = TRUE`, carregando o resultado no
#'   cache de resultados do Oracle.
#'
#' @section Linhagem de Dados:
#' +-----------------+-------------------------------------------------------------------+
#' | Elemento        | Valor                                                             |
#' +=================+===================================================================+
#' | Tabelas de      | `MTB_EFETIVO_MENSAL`, `TAXONOMIA_MISTA3`, `TRANSACOES`,           |
#' | origem          | `HISTORICO_CLIENTE`, `tabelaClientesValidos`                      |
#' +-----------------+-------------------------------------------------------------------+
#' | Filtro de       | Série em `dataHistoricaInicial` a `dataHistoricaFinal`; medianas  |
#' | período         | em `dataAgregacaoInicial` a `dataAgregacaoFinal`; demais          |
#' |                 | indicadores em `dataFeature`                                      |
#' +-----------------+-------------------------------------------------------------------+
#' | Chave de junção | `SEQUENCIA_CLIENTE` e `DATA_REFERENCIA`; `COD_CONTA_BIB` com      |
#' |                 | `COD_CONTA`                                                       |
#' +-----------------+-------------------------------------------------------------------+
#' | Tabelas         | `IM_TMP_ML_RFM_1_{SUFIXO}` a `IM_TMP_ML_RFM_5_{SUFIXO}`           |
#' | temporárias     |                                                                   |
#' +-----------------+-------------------------------------------------------------------+
#' | Tabela de saída | `IM_ML_RFM_{SUFIXO}`                                              |
#' +-----------------+-------------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +-------------------------------------------+-----------------------------------------+
#' | Coluna                                    | Descrição                               |
#' +===========================================+=========================================+
#' | `SEQUENCIA_CLIENTE`                       | Identificador do cliente                |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqCreditoSaldo`                         | Mediana mensal do saldo de crédito na   |
#' |                                           | janela de agregação; decimal (14, 2)    |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqCaptacaoSaldo`                        | Mediana mensal do saldo de captação na  |
#' |                                           | janela de agregação; decimal (14, 2)    |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqVolumeTransacoesMensaisTotal`         | Mediana mensal do volume total; decimal |
#' |                                           | (14, 2)                                 |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqIncidenciaCompra`                     | Lógico: movimento em                    |
#' |                                           | `MTB_EFETIVO_MENSAL` no mês de          |
#' |                                           | referência                              |
#' +-------------------------------------------+-----------------------------------------+
#' | `VfpIncidenciaCompraUso`                  | Lógico: compra em `TRANSACOES` no mês   |
#' |                                           | de referência                           |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqCreditoIncidencia`                    | Lógico: saldo de crédito diferente de   |
#' |                                           | zero no mês de referência               |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqCaptacaoIncidencia`                   | Lógico: saldo de captação diferente de  |
#' |                                           | zero no mês de referência               |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqQtdTransacoesMensaisUnica`            | Número de registros de movimento no mês |
#' |                                           | de referência; inteiro                  |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqRecenciaCompra`                       | Meses desde o último movimento; inteiro |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqCreditoRecencia`                      | Meses desde a última incidência de      |
#' |                                           | crédito; inteiro                        |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqCaptacaoRecencia`                     | Meses desde a última incidência de      |
#' |                                           | captação; inteiro                       |
#' +-------------------------------------------+-----------------------------------------+
#' | `VfpRecenciaCompraUso`                    | Meses desde a última compra; inteiro    |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqCreditoQtdReducao`                    | Meses consecutivos de redução do saldo  |
#' |                                           | de crédito; inteiro                     |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqCaptacaoQtdReducao`                   | Meses consecutivos de redução do saldo  |
#' |                                           | de captação; inteiro                    |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqFreqMensalAcumulada`                  | Meses acumulados com movimento          |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqFreqMensalAcumuladaRelativa`          | Fração dos meses da série com           |
#' |                                           | movimento; decimal (7, 6)               |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqFreqMensalAcumuladaCredito`           | Meses acumulados com incidência de      |
#' |                                           | crédito                                 |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqFreqMensalAcumuladaCreditoRelativa`   | Fração dos meses com incidência de      |
#' |                                           | crédito                                 |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqFreqMensalAcumuladaCaptacao`          | Meses acumulados com incidência de      |
#' |                                           | captação                                |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqFreqMensalAcumuladaCaptacaoRelativa`  | Fração dos meses com incidência de      |
#' |                                           | captação                                |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqFreqMensalAcumuladaCompraUso`         | Meses acumulados com compra             |
#' +-------------------------------------------+-----------------------------------------+
#' | `VeqFreqMensalAcumuladaCompraUsoRelativa` | Fração dos meses com compra             |
#' +-------------------------------------------+-----------------------------------------+
#'
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `"TREINO"`, sobrescrito pelos pipelines.
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`. Valor padrão de referência:
#'   `"IM_ML_CLIENTES_VALIDOS_TREINO"`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`. Valor
#'   padrão de referência: `"2026-05-01"`, sobrescrito pelos pipelines.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Valor
#'   padrão de referência: `6L`, sobrescrito pelos pipelines.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Valor padrão
#'   de referência: `36L`, sobrescrito pelos pipelines.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`. Valor padrão de referência: `"2025-12-01"`, sobrescrito pelos
#'   pipelines.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#'   Valor padrão de referência: `"2026-05-31"`, sobrescrito pelos pipelines.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Valor padrão de referência: `"2023-06-01"`, sobrescrito pelos
#'   pipelines.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Valor padrão de referência: `"2026-05-31"`, sobrescrito pelos pipelines.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_RFM_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Hughes, A. M. (1994). Strategic Database Marketing. Probus Publishing.
#'
#' Fader, P. S., Hardie, B. G. S., & Lee, K. L. (2005). RFM and CLV: Using iso-value
#' curves for customer base analysis. Journal of Marketing Research, 42(4), 415-430.
#' \url{https://doi.org/10.1509/jmkr.2005.42.4.415}
#'
#' Oracle Database SQL Tuning Guide: Optimizer Hints.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/tgsql/}
#'
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_RFM(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_RFM <- function(
    sufixoTabela = "TREINO",
    tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
    dataFeature = "2026-05-01",
    janelaAgregacao = 6L,
    janelaHistorico = 36L,
    dataAgregacaoInicial = "2025-12-01",
    dataAgregacaoFinal = "2026-05-31",
    dataHistoricaInicial = "2023-06-01",
    dataHistoricaFinal = "2026-05-31"
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  # Bind variables  
  bindVariables <- tibble(
    dataFeature = dataFeature,
    janelaAgregacao = janelaAgregacao,
    janelaHistorico = janelaHistorico,
    dataAgregacaoInicial = dataAgregacaoInicial,
    dataAgregacaoFinal = dataAgregacaoFinal,
    dataHistoricaInicial = dataHistoricaInicial,
    dataHistoricaFinal = dataHistoricaFinal
  )
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1L])
  
  # Monta nome da tabela
  tabelaFeature    <- str_c("IM_ML_RFM_", str_to_upper(sufixoTabela))
  
  # Tabelas temporarias
  tabelaFeatureTemp1 <- str_c("IM_TMP_ML_RFM_1_", str_to_upper(sufixoTabela))
  tabelaFeatureTemp2 <- str_c("IM_TMP_ML_RFM_2_", str_to_upper(sufixoTabela))
  tabelaFeatureTemp3 <- str_c("IM_TMP_ML_RFM_3_", str_to_upper(sufixoTabela))
  tabelaFeatureTemp4 <- str_c("IM_TMP_ML_RFM_4_", str_to_upper(sufixoTabela))
  tabelaFeatureTemp5 <- str_c("IM_TMP_ML_RFM_5_", str_to_upper(sufixoTabela))
  
  ## Series mensais de movimentos e compras
  # Processamento das incidencias de creditos e captacao
  Db("MTB_EFETIVO_MENSAL", hintsON = FALSE) |>  
    filter(
      (IND_VALOR_PARCELA == 1L),
      between(
        DATA_REFERENCIA, 
        TO_DATE(!!DbBindVariables("dataHistoricaInicial"), 'YYYY-MM-DD'), 
        TO_DATE(!!DbBindVariables("dataHistoricaFinal"), 'YYYY-MM-DD')
      )
    ) |>
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    inner_join(
      Db("TAXONOMIA_MISTA3") |> 
        select(COD_CONTA, IND_CONTA) |> 
        filter(
          IND_CONTA %in% c("A", "C")
        ),
      by = c("COD_CONTA_BIB" = "COD_CONTA")
    ) |> 
    group_by(DATA_REFERENCIA, SEQUENCIA_CLIENTE) |>
    summarise(
      VeqVolumeTransacoesMensaisTotal = sum(VALOR_PARCELA, na.rm = TRUE),
      VeqQtdTransacoesMensaisUnica = n(),
      VeqCreditoSaldo = sum(
        ifelse(
          test = (IND_CONTA == "A"), 
          yes = VALOR_PARCELA, 
          no = 0
        ),
        na.rm = TRUE
      ),
      VeqCaptacaoSaldo = sum(
        ifelse(
          test = (IND_CONTA == "C"), 
          yes = VALOR_PARCELA, 
          no = 0
        ),
        na.rm = TRUE
      ),
      .groups = "drop"
    ) |>
    mutate(
      VeqCreditoIncidencia = ifelse(
        test = (VeqCreditoSaldo != 0),
        yes = 1L,
        no = 0L
      ),
      VeqCaptacaoIncidencia = ifelse(
        test = (VeqCaptacaoSaldo != 0),
        yes = 1L,
        no = 0L
      ),
      VeqIncidenciaCompra = !!DbCastToLogical(TRUE)
    ) |>
    DbCast(
      SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE(),
      DATA_REFERENCIA = DbCastToDate(),
      VeqVolumeTransacoesMensaisTotal = DbCastToDouble(14L, 2L),
      VeqQtdTransacoesMensaisUnica = DbCastToInteger(6L),
      VeqCreditoSaldo = DbCastToDouble(14L, 2L),
      VeqCaptacaoSaldo = DbCastToDouble(14L, 2L),
      VeqCreditoIncidencia = DbCastToLogical(),
      VeqCaptacaoIncidencia = DbCastToLogical(),
      VeqIncidenciaCompra = DbCastToLogical()
    ) |> 
    DbCreateTableMemoryFromQuery(
      nomeTabela = tabelaFeatureTemp1,
      bindVariables = bindVariables,
      gatherStats = TRUE
    )
  
  # Carrga incidencias de compras
  Db("TRANSACOES", hintsON = FALSE,
     hintsAdditional = glue::glue("
    PARALLEL(8) LEADING({tabelaClientesValidos} TRANSACOES) PQ_DISTRIBUTE(TRANSACOES, NONE, NONE) PX_JOIN_FILTER(TRANSACOES) 
    USE_HASH(TRANSACOES) HASH_SJ USE_HASH_AGGREGATION INMEMORY_PRUNE({tabelaClientesValidos}) 
    NO_GATHER_PLAN_STATISTICS NO_ADAPTIVE_PLAN DYNAMIC_SAMPLING(0) NO_MONITOR NO_CACHE NO_RESULT_CACHE 
  ")
  ) |>
    filter(
      (IND_VALOR == 1L),
      between(
        DATA_REFERENCIA, 
        TO_DATE(!!DbBindVariables("dataHistoricaInicial"), 'YYYY-MM-DD'), 
        TO_DATE(!!DbBindVariables("dataHistoricaFinal"), 'YYYY-MM-DD')
      )
    ) |>
    semi_join(
      Db(tabelaClientesValidos, hintRESULT_CACHE = TRUE),
      by = "SEQUENCIA_CLIENTE"
    ) |>
    distinct(DATA_REFERENCIA, SEQUENCIA_CLIENTE) |>
    mutate(
      VfpIncidenciaCompraUso = !!DbCastToLogical(TRUE)
    ) |>
    DbCreateTableMemoryFromQuery(
      nomeTabela = tabelaFeatureTemp2, 
      bindVariables = bindVariables
    )
  
  ## Grade mensal completa e defasagens
  # Apuracao do periodo historico
  Db("HISTORICO_CLIENTE", hintsON = FALSE,
     hintsAdditional = glue::glue("
       PARALLEL(8) BIND_AWARE 
       LEADING({tabelaClientesValidos} HISTORICO_CLIENTE {tabelaFeatureTemp1} {tabelaFeatureTemp2}) 
       PQ_DISTRIBUTE(HISTORICO_CLIENTE, NONE, NONE) PX_JOIN_FILTER(HISTORICO_CLIENTE) 
       PQ_DISTRIBUTE({tabelaFeatureTemp2}, NONE, NONE) 
       PQ_DISTRIBUTE({tabelaFeatureTemp1}, NONE, NONE) 
       HASH_SJ USE_HASH(HISTORICO_CLIENTE) USE_HASH({tabelaFeatureTemp1}) USE_HASH({tabelaFeatureTemp2}) 
       INMEMORY({tabelaClientesValidos}) INMEMORY_PRUNE({tabelaClientesValidos}) 
       INMEMORY({tabelaFeatureTemp1}) INMEMORY_PRUNE({tabelaFeatureTemp1}) 
       INMEMORY({tabelaFeatureTemp2}) INMEMORY_PRUNE({tabelaFeatureTemp2}) 
       OPT_PARAM('pga_aggregate_target', '8G') OPT_PARAM('_pga_max_size', '2G')  OPT_PARAM('_smm_max_size', '1048576') 
       NO_GATHER_PLAN_STATISTICS NO_ADAPTIVE_PLAN DYNAMIC_SAMPLING(0) NO_MONITOR NO_CACHE NO_RESULT_CACHE 
    ")
  ) |>
    select(DATA_REFERENCIA, SEQUENCIA_CLIENTE) |>
    semi_join(
      Db(tabelaClientesValidos, hintRESULT_CACHE = TRUE),
      by = "SEQUENCIA_CLIENTE"
    ) |>
    filter(
      between(
        DATA_REFERENCIA, 
        TO_DATE(!!DbBindVariables("dataHistoricaInicial"), 'YYYY-MM-DD'), 
        TO_DATE(!!DbBindVariables("dataHistoricaFinal"), 'YYYY-MM-DD')
      )
    ) |>
    left_join(
      Db(tabelaFeatureTemp1, hintRESULT_CACHE = TRUE),
      by = c("DATA_REFERENCIA", "SEQUENCIA_CLIENTE")
    ) |>  
    left_join(
      Db(tabelaFeatureTemp2, hintRESULT_CACHE = TRUE),
      by = c("DATA_REFERENCIA", "SEQUENCIA_CLIENTE")
    ) |>
    mutate(
      VeqCreditoSaldo = coalesce(VeqCreditoSaldo, 0),
      VeqCaptacaoSaldo = coalesce(VeqCaptacaoSaldo, 0),
      VeqVolumeTransacoesMensaisTotal = coalesce(VeqVolumeTransacoesMensaisTotal, 0),
      VeqIncidenciaCompra = coalesce(VeqIncidenciaCompra, 0),
      VfpIncidenciaCompraUso = coalesce(VfpIncidenciaCompraUso, 0),
      VeqCreditoIncidencia = coalesce(VeqCreditoIncidencia, 0),
      VeqCaptacaoIncidencia = coalesce(VeqCaptacaoIncidencia, 0),
      VeqQtdTransacoesMensaisUnica = coalesce(VeqQtdTransacoesMensaisUnica, 0)
    ) |>
    group_by(SEQUENCIA_CLIENTE) |>
    mutate(
      VeqCreditoSaldoLag = lag(
        x = VeqCreditoSaldo,
        n = 1L,
        default = 0L,
        order_by = DATA_REFERENCIA
      ),
      VeqCaptacaoSaldoLag = lag(
        x = VeqCaptacaoSaldo,
        n = 1L,
        default = 0L,
        order_by = DATA_REFERENCIA
      )
    ) |>
    ungroup() |>
    DbCast(
      DATA_REFERENCIA = DbCastToDate(),
      SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE(),
      VeqCreditoSaldo = DbCastToDouble(14L, 2L),
      VeqCreditoSaldoLag = DbCastToDouble(14L, 2L),
      VeqCaptacaoSaldo = DbCastToDouble(14L, 2L),
      VeqCaptacaoSaldoLag = DbCastToDouble(14L, 2L),
      VeqVolumeTransacoesMensaisTotal = DbCastToDouble(14L, 2L),
      VeqIncidenciaCompra = DbCastToLogical(),
      VfpIncidenciaCompraUso = DbCastToLogical(),
      VeqCreditoIncidencia = DbCastToLogical(),
      VeqCaptacaoIncidencia = DbCastToLogical(),
      VeqQtdTransacoesMensaisUnica = DbCastToInteger(6L)
    ) |>
    DbCreateTableMemoryFromQuery(
      nomeTabela = tabelaFeatureTemp3, 
      bindVariables = bindVariables
    )
  
  DbDropMemoryTable(tabelaFeatureTemp1)
  DbDropMemoryTable(tabelaFeatureTemp2)
  
  ## Recencias, frequencias e consolidacao
  # Calcula recencias e frequencias
  Db(tabelaFeatureTemp3, hintsON = FALSE,
     hintsAdditional = glue::glue("
      PARALLEL({tabelaFeatureTemp3}, 8) 
      PQ_DISTRIBUTE(TABELAFEATURETEMP3, HASH) 
      INMEMORY({tabelaFeatureTemp3}) INMEMORY_PRUNE({tabelaFeatureTemp3}) VECTOR_TRANSFORM 
      OPT_PARAM('pga_aggregate_target', '8G') OPT_PARAM('_pga_max_size', '2G') 
      NO_GATHER_PLAN_STATISTICS NO_ADAPTIVE_PLAN DYNAMIC_SAMPLING(0) NO_MONITOR NO_CACHE NO_RESULT_CACHE 
    ")   
  ) |>   
    group_by(SEQUENCIA_CLIENTE) |>
    window_order(DATA_REFERENCIA) |>
    mutate(
      LinhaAtual = row_number(),
      
      # Mapeamento vetorial que registra a linha de ocorrencia do evento
      EvtCompra = ifelse(VeqIncidenciaCompra == 1L, LinhaAtual, 0L),
      EvtCredito = ifelse(VeqCreditoIncidencia == 1L, LinhaAtual, 0L),
      EvtCaptacao = ifelse(VeqCaptacaoIncidencia == 1L, LinhaAtual, 0L),
      EvtCompraUso = ifelse(VfpIncidenciaCompraUso == 1L, LinhaAtual, 0L),
      
      EvtRedCred = ifelse(VeqCreditoSaldo >= VeqCreditoSaldoLag, LinhaAtual, 0L),
      EvtRedCap = ifelse(VeqCaptacaoSaldo >= VeqCaptacaoSaldoLag, LinhaAtual, 0L),
      
      VeqRecenciaCompra = LinhaAtual - cummax(EvtCompra),
      VeqCreditoRecencia = LinhaAtual - cummax(EvtCredito),
      VeqCaptacaoRecencia = LinhaAtual - cummax(EvtCaptacao),
      VfpRecenciaCompraUso = LinhaAtual - cummax(EvtCompraUso),
      VeqCreditoQtdReducao = LinhaAtual - cummax(EvtRedCred),
      VeqCaptacaoQtdReducao = LinhaAtual - cummax(EvtRedCap)
    ) |>
    ungroup() |>
    select(
      -LinhaAtual, -starts_with("Evt")
    ) |>
    mutate(
      across(
        c(
          VeqRecenciaCompra, VeqCreditoRecencia, VeqCaptacaoRecencia,
          VfpRecenciaCompraUso, VeqCreditoQtdReducao, VeqCaptacaoQtdReducao
        ),
        ~ sql(paste0('CAST("', cur_column(), '" AS NUMBER(2))'))
      )
    ) |>
    DbCreateTableMemoryFromQuery(
      nomeTabela = tabelaFeatureTemp4,
      bindVariables = bindVariables
    )
  
  DbDropMemoryTable(tabelaFeatureTemp3)
  
  Db(tabelaFeatureTemp4, hintsON = FALSE,
     hintsAdditional = glue::glue("
      PARALLEL({tabelaFeatureTemp4}, 8) BIND_AWARE
      INMEMORY({tabelaFeatureTemp4}) INMEMORY_PRUNE({tabelaFeatureTemp4})
      PQ_DISTRIBUTE({tabelaFeatureTemp4}, NONE, NONE) VECTOR_TRANSFORM
      OPT_PARAM('pga_aggregate_target', '8G') OPT_PARAM('_pga_max_size', '2G') OPT_PARAM('_smm_max_size', '1048576') 
      NO_GATHER_PLAN_STATISTICS NO_ADAPTIVE_PLAN DYNAMIC_SAMPLING(0) NO_MONITOR NO_CACHE NO_RESULT_CACHE 
    ")   
  ) |>
    group_by(SEQUENCIA_CLIENTE) |> 
    window_order(DATA_REFERENCIA) |>
    mutate(
      VeqFreqMensalAcumulada = cumsum(VeqIncidenciaCompra),
      VeqFreqMensalAcumuladaRelativa = round(VeqFreqMensalAcumulada / cumsum(1L), digits = 6L),
      
      VeqFreqMensalAcumuladaCredito = cumsum(VeqCreditoIncidencia),
      VeqFreqMensalAcumuladaCreditoRelativa = round(VeqFreqMensalAcumuladaCredito / cumsum(1L), digits = 6L),
      
      VeqFreqMensalAcumuladaCaptacao = cumsum(VeqCaptacaoIncidencia),
      VeqFreqMensalAcumuladaCaptacaoRelativa = round(VeqFreqMensalAcumuladaCaptacao / cumsum(1L), digits = 6L),
      
      VeqFreqMensalAcumuladaCompraUso = cumsum(VfpIncidenciaCompraUso),
      VeqFreqMensalAcumuladaCompraUsoRelativa = round(VeqFreqMensalAcumuladaCompraUso / cumsum(1L), digits = 6L)
    ) |> 
    ungroup() |> 
    filter(
      between(
        DATA_REFERENCIA, 
        TO_DATE(!!DbBindVariables("dataAgregacaoInicial"), 'YYYY-MM-DD'), 
        TO_DATE(!!DbBindVariables("dataAgregacaoFinal"), 'YYYY-MM-DD')
      )
    ) |>
    DbCreateTableMemoryFromQuery(
      nomeTabela = tabelaFeatureTemp5,
      bindVariables = bindVariables
    )
  
  DbDropMemoryTable(tabelaFeatureTemp4)
  
  Db(tabelaFeatureTemp5, hintsON = FALSE,
     hintsAdditional = glue::glue("
      PARALLEL(8) BIND_AWARE INMEMORY({tabelaFeatureTemp5}) INMEMORY_PRUNE({tabelaFeatureTemp5}) 
      USE_HASH_AGGREGATION 
      OPT_PARAM('approx_for_aggregation', 'true')
      OPT_PARAM('pga_aggregate_target', '8G') 
      OPT_PARAM('_pga_max_size', '2G') OPT_PARAM('_smm_max_size', '1048576') 
      NO_GATHER_PLAN_STATISTICS NO_ADAPTIVE_PLAN DYNAMIC_SAMPLING(0) NO_MONITOR NO_CACHE NO_RESULT_CACHE 
    ")   
  ) |>
    group_by(SEQUENCIA_CLIENTE) |> 
    summarise(
      VeqCreditoSaldo = APPROX_MEDIAN(VeqCreditoSaldo), 
      VeqCaptacaoSaldo = APPROX_MEDIAN(VeqCaptacaoSaldo),
      VeqVolumeTransacoesMensaisTotal = APPROX_MEDIAN(VeqVolumeTransacoesMensaisTotal),
      .groups = "drop"
    ) |> 
    left_join(
      Db(tabelaFeatureTemp5, hintsON = FALSE,
        hintsAdditional = glue::glue("
          INMEMORY({tabelaFeatureTemp5}) INMEMORY_PRUNE({tabelaFeatureTemp5}) 
        ")   
      ) |>
        filter(
          (DATA_REFERENCIA == !!DbBindVariables("dataFeature"))
        ) |> 
        select(
          SEQUENCIA_CLIENTE,
          VeqIncidenciaCompra, VfpIncidenciaCompraUso, VeqCreditoIncidencia, VeqCaptacaoIncidencia,
          VeqQtdTransacoesMensaisUnica, VeqCreditoQtdReducao, VeqCaptacaoQtdReducao,
          VeqRecenciaCompra, VeqCreditoRecencia, VeqCaptacaoRecencia, VfpRecenciaCompraUso,
          VeqFreqMensalAcumulada, VeqFreqMensalAcumuladaRelativa, 
          VeqFreqMensalAcumuladaCredito, VeqFreqMensalAcumuladaCreditoRelativa,
          VeqFreqMensalAcumuladaCaptacao, VeqFreqMensalAcumuladaCaptacaoRelativa, 
          VeqFreqMensalAcumuladaCompraUso, VeqFreqMensalAcumuladaCompraUsoRelativa
        ),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    DbCast(
      SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE(),
      VeqCreditoSaldo = DbCastToDouble(14L, 2L), 
      VeqCaptacaoSaldo = DbCastToDouble(14L, 2L),
      VeqVolumeTransacoesMensaisTotal = DbCastToDouble(14L, 2L),
      
      VeqIncidenciaCompra = DbCastToLogical(),
      VfpIncidenciaCompraUso = DbCastToLogical(),
      VeqCreditoIncidencia = DbCastToLogical(),
      VeqCaptacaoIncidencia = DbCastToLogical(),
      
      VeqRecenciaCompra = DbCastToInteger(2L),
      
      VeqCreditoQtdReducao = DbCastToInteger(2L),
      VeqCaptacaoQtdReducao = DbCastToInteger(2L),
      VeqQtdTransacoesMensaisUnica = DbCastToInteger(6L),
      
      VeqCreditoRecencia = DbCastToInteger(2L),
      VeqCaptacaoRecencia = DbCastToInteger(2L),
      VfpRecenciaCompraUso = DbCastToInteger(2L),
      
      VeqFreqMensalAcumulada = DbCastToDouble(14L, 2L),
      VeqFreqMensalAcumuladaRelativa = DbCastToDouble(7L, 6L),
      
      VeqFreqMensalAcumuladaCredito = DbCastToDouble(14L, 2L),
      VeqFreqMensalAcumuladaCreditoRelativa = DbCastToDouble(7L, 6L),
      VeqFreqMensalAcumuladaCaptacao = DbCastToDouble(14L, 2L),
      VeqFreqMensalAcumuladaCaptacaoRelativa = DbCastToDouble(7L ,6L),
      VeqFreqMensalAcumuladaCompraUso = DbCastToDouble(14L, 2L),
      VeqFreqMensalAcumuladaCompraUsoRelativa = DbCastToDouble(7L, 6L)
    ) |> 
    DbCreateTableMemoryFromQuery(
      nomeTabela = tabelaFeature,
      bindVariables = bindVariables
    )
  
  DbDropMemoryTable(tabelaFeatureTemp5)
  
  # Carrega resultado em cache
  invisible(Db(tabelaFeature, exibirTabela = FALSE, hintRESULT_CACHE = TRUE))
  
  ## Retorno do nome da tabela
  # Retorna sucesso invisivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
