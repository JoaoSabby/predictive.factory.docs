#' @title Gerar o Feature Group de Risco e Limites do Cliente
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_RISCO_CLIENTE(
#'   tabelaClientesValidos,
#'   sufixoTabela,
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Gera, para cada cliente válido, a classificação de risco, o score, o perfil, os
#' indicadores de funcionalismo público e de crédito na data de referência, e as medianas
#' mensais dos limites de crédito na janela de agregação.
#'
#' @details
#' O processamento usa duas tabelas temporárias:
#'
#' #. `IM_TMP_ML_RISCO_CLIENTE_TEMP1_{SUFIXO}`: para cada cliente e mês da janela de
#'    agregação, mantém o registro de `RISCO_CLIENTE` com o maior `DATE_HORA_GERACAO` e,
#'    em caso de empate, a primeira linha; associa o indicador de funcionalismo público,
#'    verdadeiro quando a descrição do perfil em `TIPO_PERFIL_CLIENTE` contém `INDIRETA`,
#'    `PUB` ou `BANRISUL`;
#' #. `IM_TMP_ML_RISCO_CLIENTE_TEMP2_{SUFIXO}`: seleciona os atributos categóricos e o
#'    score do mês de `dataFeature`.
#'
#' A tabela de saída une, por `inner_join()`, as medianas aproximadas dos limites na
#' janela com os atributos do mês de referência. Por isso, apenas clientes com registro no
#' mês de `dataFeature` permanecem na tabela.
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Precisão do Score:**
#' `VegTotScore` é convertido com `DbCastToDouble(2L, 2L)`, isto é, `NUMBER(2, 2)` no
#' Oracle, que aceita apenas valores absolutos menores que 1. Se `TOT_SCORE_CLI` tiver
#' valores iguais ou superiores a 1, o Oracle rejeita a conversão.
#' :::
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_RISCO_CLIENTE_{SUFIXO}`, executa a consulta no Oracle por meio de `dbplyr` e
#' grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior de
#' mesmo nome. A função é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo após a junção em
#' `Generate_IM_ML_FEATURE_STORE()`.
#'
#' Os argumentos `janelaAgregacao`, `janelaHistorico`, `dataHistoricaInicial`,
#' `dataHistoricaFinal` não são usados no corpo da função; existem para manter a
#' assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_RISCO_CLIENTE,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_RISCO_CLIENTE_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_RISCO_CLIENTE,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_RISCO_CLIENTE_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_RISCO_CLIENTE_{SUFIXO}` no Oracle.
#' - cria e remove as tabelas temporárias `IM_TMP_ML_RISCO_CLIENTE_TEMP1_{SUFIXO}` e
#'   `IM_TMP_ML_RISCO_CLIENTE_TEMP2_{SUFIXO}`, por meio de `DbDropMemoryTable()`.
#'
#' @section Linhagem de Dados:
#' +-------------------+-----------------------------------------------------------------+
#' | Elemento          | Valor                                                           |
#' +===================+=================================================================+
#' | Tabelas de origem | `RISCO_CLIENTE`, `TIPO_PERFIL_CLIENTE`, `tabelaClientesValidos` |
#' +-------------------+-----------------------------------------------------------------+
#' | Filtro de período | `DATA_REFERENCIA` entre `dataAgregacaoInicial` e                |
#' |                   | `dataAgregacaoFinal`; atributos categóricos em `dataFeature`    |
#' +-------------------+-----------------------------------------------------------------+
#' | Chave de junção   | `SEQUENCIA_CLIENTE`; `PERFIL_CLIENTE` com `COD_PERFIL_RISCO`    |
#' +-------------------+-----------------------------------------------------------------+
#' | Tabelas           | `IM_TMP_ML_RISCO_CLIENTE_TEMP1_{SUFIXO}`,                       |
#' | temporárias       | `IM_TMP_ML_RISCO_CLIENTE_TEMP2_{SUFIXO}`                        |
#' +-------------------+-----------------------------------------------------------------+
#' | Tabela de saída   | `IM_ML_RISCO_CLIENTE_{SUFIXO}`                                  |
#' +-------------------+-----------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +-------------------------+-----------------------------------------------------------+
#' | Coluna                  | Descrição                                                 |
#' +=========================+===========================================================+
#' | `SEQUENCIA_CLIENTE`     | Identificador do cliente                                  |
#' +-------------------------+-----------------------------------------------------------+
#' | `VegLimiteCalculado`    | Mediana mensal de `LIMITE_CALCULADO`; decimal (12, 2)     |
#' +-------------------------+-----------------------------------------------------------+
#' | `VegLimiteFinal`        | Mediana mensal de `LIMITE_FINAL`; decimal (12, 2)         |
#' +-------------------------+-----------------------------------------------------------+
#' | `VegLimiteMaximo`       | Mediana mensal de `LIMITE_MAXIMO`; decimal (12, 2)        |
#' +-------------------------+-----------------------------------------------------------+
#' | `VegLimiteCartao`       | Mediana mensal de `LIMITE_CARTAO`; decimal (12, 2)        |
#' +-------------------------+-----------------------------------------------------------+
#' | `VegClassificacaoRisco` | Classificação de risco no mês de referência; texto de     |
#' |                         | dois caracteres                                           |
#' +-------------------------+-----------------------------------------------------------+
#' | `VegTotScore`           | Score total do cliente no mês de referência; decimal (2,  |
#' |                         | 2)                                                        |
#' +-------------------------+-----------------------------------------------------------+
#' | `VegPerfilCliente`      | Código do perfil do cliente; texto de quatro caracteres   |
#' +-------------------------+-----------------------------------------------------------+
#' | `VegFuncPublico`        | Lógico: perfil de funcionalismo público ou do Banrisul    |
#' +-------------------------+-----------------------------------------------------------+
#' | `VegTemCredito`         | Lógico: `IND_TEM_CREDITO == "S"`; nulo quando o indicador |
#' |                         | é nulo                                                    |
#' +-------------------------+-----------------------------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_RISCO_CLIENTE_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_RISCO_CLIENTE(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_RISCO_CLIENTE <- function(
    tabelaClientesValidos,
    sufixoTabela,
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1L])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_RISCO_CLIENTE_", str_to_upper(sufixoTabela))
  tabelaFeatureTemp1 <- str_c("IM_TMP_ML_RISCO_CLIENTE_TEMP1_", str_to_upper(sufixoTabela))
  tabelaFeatureTemp2 <- str_c("IM_TMP_ML_RISCO_CLIENTE_TEMP2_", str_to_upper(sufixoTabela))
  
  ## Selecao do registro mensal mais recente
  Db("RISCO_CLIENTE") |> 
    select(
      DATA_REFERENCIA,
      SEQUENCIA_CLIENTE, 
      DATE_HORA_GERACAO,
      CLASSIFICACAO_RISCO, 
      TOT_SCORE_CLI, 
      LIMITE_CALCULADO, 
      LIMITE_FINAL, 
      LIMITE_MAXIMO,
      PERFIL_CLIENTE, 
      IND_TEM_CREDITO, 
      LIMITE_CARTAO
    ) |> 
    filter(
      between(
        DATA_REFERENCIA, 
        TO_DATE(dataAgregacaoInicial, 'YYYY-MM-DD'), 
        TO_DATE(dataAgregacaoFinal, 'YYYY-MM-DD')
      )
    ) |>
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    group_by(DATA_REFERENCIA, SEQUENCIA_CLIENTE) |> 
    filter(
      (DATE_HORA_GERACAO == max(DATE_HORA_GERACAO))
    ) |> 
    filter(
      (row_number(SEQUENCIA_CLIENTE) == 1L)
    ) |> 
    ungroup() |> 
    left_join(
      Db("TIPO_PERFIL_CLIENTE") |> 
        filter(
          ((DESCR_PERFIL_RICSO %like% "%INDIRETA%") | (DESCR_PERFIL_RICSO %like% "%PUB%") | (DESCR_PERFIL_RICSO %like% "%BANRISUL%"))
        ) |> 
        distinct(COD_PERFIL_RISCO) |> 
        mutate(
          VegFuncPublico = 1L
        ),
      by = c("PERFIL_CLIENTE" = "COD_PERFIL_RISCO")
    ) |> 
    transmute(
      DATA_REFERENCIA,
      SEQUENCIA_CLIENTE,
      VegFuncPublico = coalesce(VegFuncPublico, 0L),
      VegTemCredito = ifelse(
        test = (IND_TEM_CREDITO == "S"),
        yes = 1L,
        no = 0L
      ),
      VegClassificacaoRisco = CLASSIFICACAO_RISCO,
      VegTotScore = TOT_SCORE_CLI, 
      VegPerfilCliente = PERFIL_CLIENTE,
      VegLimiteCalculado = LIMITE_CALCULADO,
      VegLimiteFinal = LIMITE_FINAL, 
      VegLimiteMaximo = LIMITE_MAXIMO,
      VegLimiteCartao = LIMITE_CARTAO
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeatureTemp1)
  
  Db(tabelaFeatureTemp1) |> 
    filter(
      (DATA_REFERENCIA == dataFeature)
    ) |> 
    select(
      SEQUENCIA_CLIENTE, 
      VegClassificacaoRisco,
      VegTotScore,
      VegPerfilCliente,
      VegFuncPublico,
      VegTemCredito
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeatureTemp2)
  
  ## Atributos do mes, medianas dos limites e gravacao
  # Sumarizacoes
  Db(tabelaFeatureTemp1) |> 
    group_by(SEQUENCIA_CLIENTE) |> 
    summarise(
      VegLimiteCalculado = APPROX_MEDIAN(VegLimiteCalculado),
      VegLimiteFinal     = APPROX_MEDIAN(VegLimiteFinal),
      VegLimiteMaximo    = APPROX_MEDIAN(VegLimiteMaximo),
      VegLimiteCartao    = APPROX_MEDIAN(VegLimiteCartao)
    ) |> 
    ungroup() |> 
    inner_join(
      Db(tabelaFeatureTemp2),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    DbCast(
      SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE(),
      VegLimiteCalculado = DbCastToDouble(12L, 2L),
      VegLimiteFinal = DbCastToDouble(12L, 2L), 
      VegLimiteMaximo = DbCastToDouble(12L, 2L),  
      VegLimiteCartao = DbCastToDouble(12L, 2L),  
      VegClassificacaoRisco = DbCastToCharacter(2L),  
      VegTotScore = DbCastToDouble(2L, 2L),  
      VegPerfilCliente = DbCastToCharacter(4L),
      VegFuncPublico = DbCastToLogical(),
      VegTemCredito = DbCastToLogical()
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  ## Remocao das tabelas temporarias
  DbDropMemoryTable(tabelaFeatureTemp1)
  DbDropMemoryTable(tabelaFeatureTemp2)
  
  ## Retorno do nome da tabela
  # Retorna sucesso invisivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
