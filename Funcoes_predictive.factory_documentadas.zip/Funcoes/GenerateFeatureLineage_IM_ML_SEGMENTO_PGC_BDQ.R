#' @title Gerar o Feature Group de Segmento PGC
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_SEGMENTO_PGC_BDQ(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2026-01-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-08-01",
#'   dataAgregacaoFinal = "2026-01-31",
#'   dataHistoricaInicial = "2023-02-01",
#'   dataHistoricaFinal = "2026-01-31"
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Seleciona, na data de referência, a descrição do segmento PGC de cada cliente válido em
#' `POS_CLIENTE_SEGMENTO_PGC_BDQ`, com espaços substituídos por underline.
#'
#' @details
#' Antes da consulta, `ConferirETL("POS_KPI_C")` verifica a carga da tabela de origem. São
#' excluídos os registros com `COD_SEGMENTO_PGC == 999`. A descrição é convertida para
#' texto de até 22 caracteres.
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_SEGMENTO_PGC_BDQ_{SUFIXO}`, executa a consulta no Oracle por meio de `dbplyr` e
#' grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior de
#' mesmo nome. A função é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' Espera-se um registro por cliente no mês. Clientes ausentes da tabela recebem valor
#' nulo nas colunas deste grupo após a junção em `Generate_IM_ML_FEATURE_STORE()`.
#'
#' ::: {.callout-important}
#' <i class="fa-solid fa-circle-exclamation"></i> **Encadeamento Interrompido:**
#' A linha `arrange(desc(DATA_REFERENCIA))` não termina com o operador `|>`. O R
#' interpreta a consulta como duas expressões: a primeira ordena a tabela e é descartada;
#' a segunda chama `filter()` sem dados de entrada, o que termina com erro. Por isso, a
#' tabela de saída não é criada.
#' :::
#'
#' Os argumentos `janelaAgregacao`, `janelaHistorico`, `dataAgregacaoInicial`,
#' `dataAgregacaoFinal`, `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no
#' corpo da função; existem para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_SEGMENTO_PGC_BDQ,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_SEGMENTO_PGC_BDQ_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_SEGMENTO_PGC_BDQ,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_SEGMENTO_PGC_BDQ_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_SEGMENTO_PGC_BDQ_{SUFIXO}` no Oracle.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------+
#' | Elemento            | Valor                                                   |
#' +=====================+=========================================================+
#' | Tabelas de origem   | `POS_CLIENTE_SEGMENTO_PGC_BDQ`, `tabelaClientesValidos` |
#' +---------------------+---------------------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA == dataFeature`                        |
#' +---------------------+---------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`                                     |
#' +---------------------+---------------------------------------------------------+
#' | Tabelas temporárias | nenhuma                                                 |
#' +---------------------+---------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_SEGMENTO_PGC_BDQ_{SUFIXO}`                       |
#' +---------------------+---------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +---------------------+---------------------------------------------------------------+
#' | Coluna              | Descrição                                                     |
#' +=====================+===============================================================+
#' | `SEQUENCIA_CLIENTE` | Identificador do cliente                                      |
#' +---------------------+---------------------------------------------------------------+
#' | `Segmento`          | Descrição do segmento PGC com underline no lugar de espaços;  |
#' |                     | texto de até 22 caracteres                                    |
#' +---------------------+---------------------------------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`. Valor padrão de referência:
#'   `"IM_ML_CLIENTES_VALIDOS_TREINO"`, sobrescrito pelos pipelines.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `"TREINO"`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`. Valor
#'   padrão de referência: `"2026-01-01"`, sobrescrito pelos pipelines.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função. Valor padrão de referência: `6L`, sobrescrito pelos
#'   pipelines.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função. Valor padrão de referência: `36L`, sobrescrito pelos pipelines.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função. Valor padrão de referência:
#'   `"2025-08-01"`, sobrescrito pelos pipelines.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função. Valor padrão de referência: `"2026-01-31"`,
#'   sobrescrito pelos pipelines.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função. Valor padrão de referência:
#'   `"2023-02-01"`, sobrescrito pelos pipelines.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função. Valor padrão de referência: `"2026-01-31"`,
#'   sobrescrito pelos pipelines.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_SEGMENTO_PGC_BDQ_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_SEGMENTO_PGC_BDQ(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_SEGMENTO_PGC_BDQ <- function(
    tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
    sufixoTabela = "TREINO",
    dataFeature = "2026-01-01",
    janelaAgregacao = 6L,
    janelaHistorico = 36L,
    dataAgregacaoInicial = "2025-08-01",
    dataAgregacaoFinal = "2026-01-31",
    dataHistoricaInicial = "2023-02-01",
    dataHistoricaFinal = "2026-01-31"
){

  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1L])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_SEGMENTO_PGC_BDQ_", str_to_upper(sufixoTabela))
  ## Verificacao da carga da tabela de origem
  ConferirETL("POS_KPI_C")
  ## Selecao do segmento e gravacao
  # Busca dados
  Db("POS_CLIENTE_SEGMENTO_PGC_BDQ") |> 
    arrange(desc(DATA_REFERENCIA))
    filter(
      (COD_SEGMENTO_PGC != 999L),
      (DATA_REFERENCIA == dataFeature)
    ) |>
    select(
      SEQUENCIA_CLIENTE, DESC_SEGMENTO_PGC
    ) |> 
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    mutate(
      DESC_SEGMENTO_PGC = str_replace_all(
        string = DESC_SEGMENTO_PGC, 
        pattern = " ",
        replacement = "_"
      )
    ) |>          
    transmute(
      SEQUENCIA_CLIENTE = !!DbCastTo_SEQUENCIA_CLIENTE(SEQUENCIA_CLIENTE),
      Segmento = !!DbCastToCharacter(DESC_SEGMENTO_PGC, 22L)
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)

  ## Retorno do nome da tabela
  # Retorna sucesso invisivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
