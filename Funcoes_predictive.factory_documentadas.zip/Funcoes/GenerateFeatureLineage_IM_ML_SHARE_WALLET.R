#' @title Gerar o Feature Group de Participação na Carteira de Crédito
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_SHARE_WALLET(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = ymd("2025-11-01"),
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = ymd("2025-06-01"),
#'   dataAgregacaoFinal = ymd("2025-11-01"),
#'   dataHistoricaInicial = ymd("2022-12-01"),
#'   dataHistoricaFinal = ymd("2025-11-01")
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Calcula, para cada cliente válido e na data de referência, os montantes de crédito no
#' Sistema Financeiro Nacional e no Banrisul por grupo de modalidade Bacen, a participação
#' do Banrisul (share of wallet) por grupo e geral, e as quantidades de operações e de
#' instituições no SFN.
#'
#' @details
#' Quando a tabela `BACEN_TAXONOMIA_MODALIDADE` não existe, ela é carregada por
#' `LoadAppendix_bacen_taxonomia_modalidade()`. As etapas são:
#'
#' #. montante no SFN por cliente e grupo (`DESC_GRUPO`), somando `VLR_VENCIDO`,
#'    `VLR_VINCENDO` e `VLR_LIMITE` de `OPERACAO_SFN_BMZ`, mantendo montantes positivos;
#' #. montante no Banrisul pela mesma regra em `OPERACAO_BANRI`, excluindo operações sem
#'    saldo e operações apenas com valor baixado e mais de \eqn{5 \times 365} dias de
#'    atraso;
#' #. união completa por cliente e grupo, com zero para o montante ausente, e cálculo da
#'    participação;
#' #. totais por cliente, participação geral e pivotamento por grupo;
#' #. junção das quantidades de `RESP_CLIENTE_SFN`.
#'
#' Sendo \eqn{B} e \eqn{S} os montantes no Banrisul e no SFN, a participação do Banrisul
#' é:
#'
#' - \eqn{SoW = 1}, quando \eqn{B > S};
#' - \eqn{SoW = \mathrm{round}(B / S, 6)}, quando \eqn{B \le S} e \eqn{S > 0};
#' - \eqn{SoW = 0}, nos demais casos.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-table-columns"></i> **Colunas Dinâmicas:**
#' As colunas por grupo são criadas a partir dos valores de `DESC_GRUPO` presentes no mês.
#' Grupos sem ocorrência não geram coluna, e o conjunto de colunas pode variar entre
#' treino e predição.
#' :::
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_SHARE_WALLET_{SUFIXO}`, executa a consulta no Oracle por meio de `dbplyr` e
#' grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior de
#' mesmo nome. A função é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo após a junção em
#' `Generate_IM_ML_FEATURE_STORE()`.
#'
#' Os argumentos `janelaAgregacao`, `janelaHistorico`, `dataAgregacaoInicial`,
#' `dataAgregacaoFinal`, `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no
#' corpo da função; existem para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_SHARE_WALLET,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_SHARE_WALLET_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_SHARE_WALLET,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_SHARE_WALLET_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_SHARE_WALLET_{SUFIXO}` no Oracle.
#' - cria e remove as tabelas temporárias `IM_TMP_ML_SHARE_WALLET_{SUFIXO}_SFN`,
#'   `IM_TMP_ML_SHARE_WALLET_{SUFIXO}_BAN` e `IM_TMP_ML_SHARE_WALLET_{SUFIXO}_SHW`;
#' - pode criar a tabela `BACEN_TAXONOMIA_MODALIDADE`, por meio de
#'   `LoadAppendix_bacen_taxonomia_modalidade()`.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `OPERACAO_SFN_BMZ`, `OPERACAO_BANRI`,                         |
#' |                     | `BACEN_TAXONOMIA_MODALIDADE`, `RESP_CLIENTE_SFN`,             |
#' |                     | `tabelaClientesValidos`                                       |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA == dataFeature`                              |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`; `COD_MODALIDADE`; `DESC_GRUPO`           |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | `IM_TMP_ML_SHARE_WALLET_{SUFIXO}_SFN`, `..._BAN`, `..._SHW`   |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_SHARE_WALLET_{SUFIXO}`                                 |
#' +---------------------+---------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +-------------------------+-----------------------------------------------------------+
#' | Coluna                  | Descrição                                                 |
#' +=========================+===========================================================+
#' | `SEQUENCIA_CLIENTE`     | Identificador do cliente                                  |
#' +-------------------------+-----------------------------------------------------------+
#' | `Montante_BAN`          | Soma dos montantes no Banrisul em todos os grupos         |
#' +-------------------------+-----------------------------------------------------------+
#' | `Montante_SFN`          | Soma dos montantes no SFN em todos os grupos              |
#' +-------------------------+-----------------------------------------------------------+
#' | `ShareOfWallet_GERAL`   | Participação geral do Banrisul, pela fórmula de detalhes  |
#' +-------------------------+-----------------------------------------------------------+
#' | `Montante_SFN_{GRUPO}`  | Montante no SFN por grupo de modalidade; zero quando      |
#' |                         | ausente                                                   |
#' +-------------------------+-----------------------------------------------------------+
#' | `Montante_BAN_{GRUPO}`  | Montante no Banrisul por grupo de modalidade; zero quando |
#' |                         | ausente                                                   |
#' +-------------------------+-----------------------------------------------------------+
#' | `ShareOfWallet_{GRUPO}` | Participação do Banrisul por grupo de modalidade          |
#' +-------------------------+-----------------------------------------------------------+
#' | `QtdOperacoesSFN`       | Quantidade de operações no SFN; inteiro de quatro dígitos |
#' +-------------------------+-----------------------------------------------------------+
#' | `QtdInstituicoesSFN`    | Quantidade de instituições financeiras no SFN; inteiro de |
#' |                         | quatro dígitos                                            |
#' +-------------------------+-----------------------------------------------------------+
#' | `QtdInstituicoesOUTRAS` | \eqn{\max(\mathrm{QtdInstituicoesSFN} - 1, 0)}; inteiro   |
#' |                         | de quatro dígitos                                         |
#' +-------------------------+-----------------------------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`. Valor padrão de referência:
#'   `"IM_ML_CLIENTES_VALIDOS_TREINO"`, sobrescrito pelos pipelines.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `"TREINO"`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`. Valor
#'   padrão de referência: `ymd("2025-11-01")`, sobrescrito pelos pipelines.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função. Valor padrão de referência: `6L`, sobrescrito pelos
#'   pipelines.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função. Valor padrão de referência: `36L`, sobrescrito pelos pipelines.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função. Valor padrão de referência:
#'   `ymd("2025-06-01")`, sobrescrito pelos pipelines.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função. Valor padrão de referência: `ymd("2025-11-01")`,
#'   sobrescrito pelos pipelines.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função. Valor padrão de referência:
#'   `ymd("2022-12-01")`, sobrescrito pelos pipelines.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função. Valor padrão de referência: `ymd("2025-11-01")`,
#'   sobrescrito pelos pipelines.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_SHARE_WALLET_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Banco Central do Brasil. Sistema de Informações de Crédito (SCR).
#' \url{https://www.bcb.gov.br/estabilidadefinanceira/scr}
#'
#' Cooil, B., Keiningham, T. L., Aksoy, L., & Hsu, M. (2007). A longitudinal analysis of
#' customer satisfaction and share of wallet. Journal of Marketing, 71(1), 67-83.
#' \url{https://doi.org/10.1509/jmkg.71.1.067}
#'
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_SHARE_WALLET(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_SHARE_WALLET <- function(
    tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
    sufixoTabela = "TREINO",
    dataFeature = ymd("2025-11-01"),
    janelaAgregacao = 6L,
    janelaHistorico = 36L,
    dataAgregacaoInicial = ymd("2025-06-01"),
    dataAgregacaoFinal = ymd("2025-11-01"),
    dataHistoricaInicial = ymd("2022-12-01"),
    dataHistoricaFinal = ymd("2025-11-01")
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_SHARE_WALLET_", str_to_upper(sufixoTabela))
  tabelaFeatureTmp_SFN <- str_c("IM_TMP_ML_SHARE_WALLET_", str_to_upper(sufixoTabela), "_SFN")
  tabelaFeatureTmp_BAN <- str_c("IM_TMP_ML_SHARE_WALLET_", str_to_upper(sufixoTabela), "_BAN")
  tabelaFeatureTmp_SHW <- str_c("IM_TMP_ML_SHARE_WALLET_", str_to_upper(sufixoTabela), "_SHW")
  
  ## Carga da taxonomia de modalidades
  # Se nao possui tabela de agrupoador de modalidades
  if(!DbExists(Db("BACEN_TAXONOMIA_MODALIDADE"))){
    LoadAppendix_bacen_taxonomia_modalidade()
  } 
  
  ## Montantes por grupo no SFN e no Banrisul
  # Dados SFN
  Db("OPERACAO_SFN_BMZ") %>% 
    filter(
      (DATA_REFERENCIA == dataFeature)
    ) |> 
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |>
    inner_join(
      Db("BACEN_TAXONOMIA_MODALIDADE") |> 
        select(COD_MODALIDADE, DESC_GRUPO),
      by = "COD_MODALIDADE"
    ) |> 
    group_by(SEQUENCIA_CLIENTE, DESC_GRUPO) |> 
    summarise(
      VLR_VENCIDO  = sum(VLR_VENCIDO, na.rm = TRUE),
      VLR_VINCENDO = sum(VLR_VINCENDO, na.rm = TRUE),
      VLR_LIMITE   = sum(VLR_LIMITE, na.rm = TRUE)
    ) |> 
    ungroup() |> 
    mutate(
      Montante_SFN = (VLR_VENCIDO + VLR_VINCENDO + VLR_LIMITE)
    ) |> 
    filter(
      (Montante_SFN > 0) # Evita divisao por zeros
    ) |> 
    select(SEQUENCIA_CLIENTE, DESC_GRUPO, Montante_SFN) |> 
    DbCreateTableMemoryFromQuery(tabelaFeatureTmp_SFN)

  # Dados Banrisul
  Db("OPERACAO_BANRI") %>% 
    filter(
      (DATA_REFERENCIA == dataFeature),
      !((VLR_VENCIDO == 0) & (VLR_VINCENDO == 0) & (VLR_LIMITE == 0) & (VLR_BAIXADO == 0)),
      !((VLR_VENCIDO == 0) & (VLR_VINCENDO == 0) & (VLR_LIMITE == 0) & (VLR_BAIXADO != 0) & (DIAS_ATRASO > (365L * 5L)))
    ) |> 
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |>
    inner_join(
      Db("BACEN_TAXONOMIA_MODALIDADE"),
      by = "COD_MODALIDADE"
    ) |> 
    group_by(SEQUENCIA_CLIENTE, DESC_GRUPO) |> 
    summarise(
      VLR_VENCIDO = sum(VLR_VENCIDO, na.rm = TRUE),
      VLR_VINCENDO = sum(VLR_VINCENDO, na.rm = TRUE),
      VLR_LIMITE = sum(VLR_LIMITE, na.rm = TRUE)
    ) |> 
    ungroup() |> 
    mutate(
      Montante_BAN = (VLR_VENCIDO + VLR_VINCENDO + VLR_LIMITE)
    ) |> 
    filter(
      (Montante_BAN > 0) 
    ) |> 
    select(SEQUENCIA_CLIENTE, DESC_GRUPO, Montante_BAN) |> 
    DbCreateTableMemoryFromQuery(tabelaFeatureTmp_BAN)
  
  # Unifica SFN e BAN 
  Db(tabelaFeatureTmp_SFN) |> 
    full_join(
      Db(tabelaFeatureTmp_BAN),
      by = c("SEQUENCIA_CLIENTE", "DESC_GRUPO")
    ) |> 
    mutate(
      Montante_BAN = coalesce(Montante_BAN, 0),
      Montante_SFN = coalesce(Montante_SFN, 0),
      ShareOfWallet = case_when(
        (Montante_BAN > Montante_SFN)             ~ 1L,
        (Montante_SFN > 0L)                       ~ round((Montante_BAN / Montante_SFN), digits = 6L),
        TRUE                                      ~ 0L
      )
    ) |> 
    select(SEQUENCIA_CLIENTE, DESC_GRUPO, Montante_BAN, Montante_SFN, ShareOfWallet) |> 
    DbCreateTableMemoryFromQuery(tabelaFeatureTmp_SHW)
  
  # Limpa memoria
  DbDropMemoryTable(tabelaFeatureTmp_SFN)
  DbDropMemoryTable(tabelaFeatureTmp_BAN)
  
  ## Participacao, consolidacao por cliente e gravacao
  # Tabela final
  Db(tabelaFeatureTmp_SHW) |> 
    select(SEQUENCIA_CLIENTE, Montante_BAN, Montante_SFN) |> 
    group_by(SEQUENCIA_CLIENTE) |> 
    summarise(
      Montante_BAN = sum(Montante_BAN, na.rm = TRUE),
      Montante_SFN = sum(Montante_SFN, na.rm = TRUE)
    ) |> 
    ungroup() |> 
    mutate(
      ShareOfWallet_GERAL = case_when(
        (Montante_BAN > Montante_SFN)             ~ 1L,
        (Montante_SFN > 0L)                       ~ round((Montante_BAN / Montante_SFN), digits = 6L),
        TRUE                                      ~ 0L
      )
    ) |> 
    left_join(
      Db(tabelaFeatureTmp_SHW) |> 
        select(SEQUENCIA_CLIENTE, DESC_GRUPO, Montante_SFN) |> 
        DbPivotWider(
          names_from = DESC_GRUPO,
          values_from = Montante_SFN,
          values_fill = 0,
          names_prefix = "Montante_SFN_"
        ),
      by = "SEQUENCIA_CLIENTE" 
    ) |> 
    left_join(
      Db(tabelaFeatureTmp_SHW) |> 
        select(SEQUENCIA_CLIENTE, DESC_GRUPO, Montante_BAN) |> 
        DbPivotWider(
          names_from = DESC_GRUPO,
          values_from = Montante_BAN,
          values_fill = 0,
          names_prefix = "Montante_BAN_"
        ),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    left_join(
      Db(tabelaFeatureTmp_SHW) |> 
        select(SEQUENCIA_CLIENTE, DESC_GRUPO, ShareOfWallet) |> 
        DbPivotWider(
          names_from = DESC_GRUPO,
          values_from = ShareOfWallet,
          values_fill = 0,
          names_prefix = "ShareOfWallet_"
        ),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    left_join(
      Db("RESP_CLIENTE_SFN") %>%
        filter(
          (DATA_REFERENCIA == dataFeature)
        ) %>% 
        semi_join(
          Db(tabelaClientesValidos),
          by = "SEQUENCIA_CLIENTE"
        ) |>
        transmute(
          SEQUENCIA_CLIENTE = SEQUENCIA_CLIENTE,
          QtdOperacoesSFN = QTD_OPERACOES,
          QtdInstituicoesSFN = QTD_INSTITUICOES_FINANCEIRAS,
          QtdInstituicoesOUTRAS = ifelse(
            test = ((QtdInstituicoesSFN - 1L) < 0),
            yes = as.integer(0L),
            no = (QtdInstituicoesSFN - 1L)
          )
        ) |> 
        DbCast(
          SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE(),
          QtdOperacoesSFN = DbCastToInteger(4L),
          QtdInstituicoesSFN = DbCastToInteger(4L),
          QtdInstituicoesOUTRAS = DbCastToInteger(4L)
        ),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    DbCast(
      SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE()
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  # Limpa tabelas
  DbDropMemoryTable(tabelaFeatureTmp_SHW)
  
  ## Retorno do nome da tabela
  # Retorna sucesso invisivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
