#' @title Gerar o Feature Group de Saldos em Conta Corrente e Poupança
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_SLD_CONTA_CORR_POUP(
#'   tabelaClientesValidos,
#'   sufixoTabela = "",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Calcula, para cada cliente válido, a mediana mensal dos saldos positivos em depósito à
#' vista e em poupança na janela de agregação.
#'
#' @details
#' As contas são classificadas pela hierarquia `CONTA`, `PRODUTO_GESTAO_BIB` e
#' `SUBGRUPO_GESTAO_BIB`, restrita aos grupos de gestão `203` (depósito à vista) e `210`
#' (poupança), e gravadas na tabela temporária `IM_TMP_FILTRO_GRUPOS_{SUFIXO}`. Sobre os
#' registros de `MTB_EFETIVO_MENSAL` com `VALOR_PARCELA` positivo, os valores são somados
#' por cliente, mês e tipo de saldo e resumidos pela mediana aproximada. Após o
#' pivotamento, o tipo ausente recebe zero.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **Nomes das Colunas:**
#' O prefixo `VeqSaldo` é aplicado por `names_prefix` sobre valores que já começam com
#' `VeqSaldo`. Por isso, as colunas geradas são `VeqSaldoVeqSaldoContaCorrente` e
#' `VeqSaldoVeqSaldoPoupanca`.
#' :::
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_SLD_CONTA_CORR_POUP_{SUFIXO}`, executa a consulta no Oracle por meio de `dbplyr`
#' e grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior
#' de mesmo nome. A função é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo após a junção em
#' `Generate_IM_ML_FEATURE_STORE()`.
#'
#' Os argumentos `dataFeature`, `janelaAgregacao`, `janelaHistorico`,
#' `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no corpo da função; existem
#' para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_SLD_CONTA_CORR_POUP,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_SLD_CONTA_CORR_POUP_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_SLD_CONTA_CORR_POUP,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_SLD_CONTA_CORR_POUP_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_SLD_CONTA_CORR_POUP_{SUFIXO}` no Oracle.
#' - cria e remove a tabela temporária `IM_TMP_FILTRO_GRUPOS_{SUFIXO}`, por meio de
#'   `DbCleanTablesMemory()`.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `CONTA`, `PRODUTO_GESTAO_BIB`, `SUBGRUPO_GESTAO_BIB`,         |
#' |                     | `MTB_EFETIVO_MENSAL`, `tabelaClientesValidos`                 |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA` entre `dataAgregacaoInicial` e              |
#' |                     | `dataAgregacaoFinal`                                          |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`; `COD_CONTA_BIB` com `COD_CONTA`          |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | `IM_TMP_FILTRO_GRUPOS_{SUFIXO}`                               |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_SLD_CONTA_CORR_POUP_{SUFIXO}`                          |
#' +---------------------+---------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +---------------------------------+---------------------------------------------------+
#' | Coluna                          | Descrição                                         |
#' +=================================+===================================================+
#' | `SEQUENCIA_CLIENTE`             | Identificador do cliente                          |
#' +---------------------------------+---------------------------------------------------+
#' | `VeqSaldoVeqSaldoContaCorrente` | Mediana mensal da soma dos saldos em depósito à   |
#' |                                 | vista; decimal (10, 2)                            |
#' +---------------------------------+---------------------------------------------------+
#' | `VeqSaldoVeqSaldoPoupanca`      | Mediana mensal da soma dos saldos em poupança;    |
#' |                                 | decimal (10, 2)                                   |
#' +---------------------------------+---------------------------------------------------+
#'
#' Para cada tipo de saldo \eqn{t}: \eqn{\tilde{S}_{c,t} = \mathrm{mediana}_{m} \sum_{i
#' \in (c, m, t)} v_i}.
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `""`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`. Não
#'   utilizado no corpo da função.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_SLD_CONTA_CORR_POUP_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_SLD_CONTA_CORR_POUP(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_SLD_CONTA_CORR_POUP <- function(
    tabelaClientesValidos,
    sufixoTabela = "",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_SLD_CONTA_CORR_POUP_", sufixoTabela)
  tabelaTmpFiltraGrupos <- str_c("IM_TMP_FILTRO_GRUPOS_", sufixoTabela)
  
  ## Criacao da tabela temporaria de contas
  # Filtro de GRUPOS "DEPOSITO A VISTA" E "POUPANCA"
  Db("CONTA") |> 
    select(COD_CONTA, COD_PRODUTO_GESTAO_BIB) |> 
    inner_join(
      Db("PRODUTO_GESTAO_BIB") |> # PRODUTO_GESTAO_BIB
        select(COD_PRODUTO_GESTAO, COD_SUBGRUPO_GESTAO) |> 
        inner_join(
          Db("SUBGRUPO_GESTAO_BIB") |> 
            select(COD_SUBGRUPO_GESTAO,COD_GRUPO_GESTAO_BIB) |> 
            filter(
              COD_GRUPO_GESTAO_BIB %in% c(203L, 210L)
            ),
          by = "COD_SUBGRUPO_GESTAO"
        ),
      by = c("COD_PRODUTO_GESTAO_BIB" = "COD_PRODUTO_GESTAO")
    ) |> 
    # Codigos que podem estar em tabela de configuração também
    # GRUPOS "DEPOSITO A VISTA" E "POUPANCA"
    DbCast(
      COD_CONTA = DbCastToInteger(8L),
      COD_PRODUTO_GESTAO_BIB = DbCastToInteger(7L), 
      COD_SUBGRUPO_GESTAO = DbCastToInteger(5L), 
      COD_GRUPO_GESTAO_BIB = DbCastToInteger(3L)
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaTmpFiltraGrupos)
  
  ## Agregacao, pivotamento e gravacao
  # Gera dados
  Db("MTB_EFETIVO_MENSAL") |> 
    select(SEQUENCIA_CLIENTE, DATA_REFERENCIA, COD_CONTA_BIB, VALOR_PARCELA) |> 
    filter(
      between(DATA_REFERENCIA, TO_DATE(dataAgregacaoInicial, 'YYYY-MM-DD'), TO_DATE(dataAgregacaoFinal, 'YYYY-MM-DD')),
      !is.na(COD_CONTA_BIB),
      (COD_CONTA_BIB > 0),
      !is.na(VALOR_PARCELA),
      (VALOR_PARCELA > 0)
    ) |>
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    inner_join(
      Db(tabelaTmpFiltraGrupos),
      by = c("COD_CONTA_BIB" = "COD_CONTA")
    ) |> 
    mutate(
      TipoSaldo = ifelse(
        test = (COD_GRUPO_GESTAO_BIB == 203L),
        yes = !!DbCastToLogical(TRUE), # VeqSaldoContaCorrente
        no = !!DbCastToLogical(FALSE)  # VeqSaldoPoupanca
      )
    ) |> 
    group_by(SEQUENCIA_CLIENTE, DATA_REFERENCIA, TipoSaldo) |> 
    summarise(
      Valor = sum(VALOR_PARCELA, na.rm = TRUE)
    ) |> 
    ungroup() |>
    group_by(SEQUENCIA_CLIENTE, TipoSaldo) |> 
    summarise(
      Valor = APPROX_MEDIAN(Valor)
    ) |> 
    ungroup() |> 
    transmute(
      SEQUENCIA_CLIENTE, 
      VeqSaldo = ifelse(
        test = (TipoSaldo == 1L),
        yes = "VeqSaldoContaCorrente",
        no = "VeqSaldoPoupanca"
      ),
      Valor
    ) |> 
    DbPivotWider(
      names_from = VeqSaldo,
      values_from = Valor,
      values_fill = 0,
      names_prefix = "VeqSaldo"
    ) |> 
    DbCast(
      SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE(),
      VeqSaldoVeqSaldoContaCorrente  = DbCastToDouble(10L, 2L),
      VeqSaldoVeqSaldoPoupanca = DbCastToDouble(10L, 2L)
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  ## Remocao da tabela temporaria
  # Remove tabela temporaria
  DbCleanTablesMemory(tabelaTmpFiltraGrupos)
  
  ## Retorno do nome da tabela
  # Retorna sucesso invisivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
