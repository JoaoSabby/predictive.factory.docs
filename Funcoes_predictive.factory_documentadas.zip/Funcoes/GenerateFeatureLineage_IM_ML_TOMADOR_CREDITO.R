#' @title Gerar o Feature Group de Crédito Tomado
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_TOMADOR_CREDITO(
#'   tabelaClientesValidos,
#'   sufixoTabela = "",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Calcula, para cada cliente, as medianas mensais do crédito tomado no Sistema Financeiro
#' Nacional e no Banrisul na janela de agregação, e a mediana da razão entre o crédito no
#' Banrisul e o crédito no SFN.
#'
#' @details
#' O crédito tomado é a soma de `VLR_VENCIDO` e `VLR_VINCENDO` por cliente e mês, obtido
#' de `OPERACAO_SFN_BMZ` (SFN) e de `OPERACAO_BANRI` (Banrisul) e gravado em tabelas
#' temporárias. As duas séries são unidas por `full_join()` por cliente e mês, e, para
#' cada mês:
#'
#' - \eqn{B = \mathrm{coalesce}(B^{ori}, 0)};
#' - \eqn{S = \mathrm{coalesce}(S^{ori}, B)};
#' - razão \eqn{R = 0} se \eqn{S = 0}; \eqn{R = 1} se \eqn{B \ge S}; caso contrário,
#'   \eqn{R = B / S} arredondada a seis casas.
#'
#' Por fim, cada coluna é resumida pela mediana aproximada por cliente.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **População:**
#' Apenas a série do SFN é restrita aos clientes válidos. Como a série do Banrisul não é
#' filtrada e a junção é completa, a tabela de saída também contém clientes fora da
#' população válida; eles são descartados na junção à esquerda da feature store.
#' :::
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_TOMADOR_CREDITO_{SUFIXO}`, executa a consulta no Oracle por meio de `dbplyr` e
#' grava o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior de
#' mesmo nome. A função é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo após a junção em
#' `Generate_IM_ML_FEATURE_STORE()`.
#'
#' Os argumentos `dataFeature`, `janelaAgregacao`, `janelaHistorico`,
#' `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no corpo da função; existem
#' para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_TOMADOR_CREDITO,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_TOMADOR_CREDITO_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_TOMADOR_CREDITO,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_TOMADOR_CREDITO_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_TOMADOR_CREDITO_{SUFIXO}` no Oracle.
#' - cria e remove as tabelas temporárias `IM_TMP_ML_TOMADOR_CREDITO_TEMP1{SUFIXO}`,
#'   `IM_TMP_ML_TOMADOR_CREDITO_TEMP2{SUFIXO}` e
#'   `IM_TMP_ML_TOMADOR_CREDITO_TEMP3{SUFIXO}`, por meio de `DbDropMemoryTable()`; os
#'   nomes não têm underline antes do sufixo.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `OPERACAO_SFN_BMZ`, `OPERACAO_BANRI`, `tabelaClientesValidos` |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA` entre `dataAgregacaoInicial` e              |
#' |                     | `dataAgregacaoFinal`                                          |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE` e `DATA_REFERENCIA`                       |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | `IM_TMP_ML_TOMADOR_CREDITO_TEMP1{SUFIXO}`,                    |
#' |                     | `..._TEMP2{SUFIXO}`, `..._TEMP3{SUFIXO}`                      |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_TOMADOR_CREDITO_{SUFIXO}`                              |
#' +---------------------+---------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +--------------------------------+----------------------------------------------------+
#' | Coluna                         | Descrição                                          |
#' +================================+====================================================+
#' | `SEQUENCIA_CLIENTE`            | Identificador do cliente                           |
#' +--------------------------------+----------------------------------------------------+
#' | `VelCreditoTomadoSFN_Ori`      | Mediana mensal do crédito tomado no SFN, sem       |
#' |                                | imputação; decimal (12, 2)                         |
#' +--------------------------------+----------------------------------------------------+
#' | `CreditoTomadoSFN`             | Mediana mensal do crédito no SFN, com imputação    |
#' |                                | pelo valor do Banrisul; decimal (12, 2)            |
#' +--------------------------------+----------------------------------------------------+
#' | `VekCreditoTomadoBanrisul_Ori` | Mediana mensal do crédito tomado no Banrisul, sem  |
#' |                                | imputação; decimal (12, 2)                         |
#' +--------------------------------+----------------------------------------------------+
#' | `CreditoTomadoBanrisul`        | Mediana mensal do crédito no Banrisul, com zero    |
#' |                                | para meses ausentes; decimal (12, 2)               |
#' +--------------------------------+----------------------------------------------------+
#' | `RazaoCreditoTomado`           | Mediana mensal da razão Banrisul sobre SFN,        |
#' |                                | limitada a 1; decimal (7, 6)                       |
#' +--------------------------------+----------------------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `""`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`. Não
#'   utilizado no corpo da função.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_TOMADOR_CREDITO_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Banco Central do Brasil. Sistema de Informações de Crédito (SCR).
#' \url{https://www.bcb.gov.br/estabilidadefinanceira/scr}
#'
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_TOMADOR_CREDITO(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_TOMADOR_CREDITO <- function(
    tabelaClientesValidos,
    sufixoTabela = "",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1L])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_TOMADOR_CREDITO_", str_to_upper(sufixoTabela))
  tabelaFeatureTemp1 <- str_c("IM_TMP_ML_TOMADOR_CREDITO_TEMP1", str_to_upper(sufixoTabela))
  tabelaFeatureTemp2 <- str_c("IM_TMP_ML_TOMADOR_CREDITO_TEMP2", str_to_upper(sufixoTabela))
  tabelaFeatureTemp3 <- str_c("IM_TMP_ML_TOMADOR_CREDITO_TEMP3", str_to_upper(sufixoTabela))
  
  ## Serie mensal de credito no SFN
  # Gerar preditores da tabela OPERACAO_SFN_BMZ
  Db("OPERACAO_SFN_BMZ") |> 
    select(
      DATA_REFERENCIA,
      SEQUENCIA_CLIENTE, 
      VLR_VENCIDO,
      VLR_VINCENDO
    ) |> 
    filter(
      between(DATA_REFERENCIA, TO_DATE(dataAgregacaoInicial, 'YYYY-MM-DD'), TO_DATE(dataAgregacaoFinal, 'YYYY-MM-DD'))
    ) |> 
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |> 
    group_by(SEQUENCIA_CLIENTE, DATA_REFERENCIA) |> 
    summarise(
      VelCreditoTomadoSFN_Ori = sum((VLR_VENCIDO + VLR_VINCENDO), na.rm = TRUE)
    ) |> 
    ungroup() |> 
    DbCreateTableMemoryFromQuery(tabelaFeatureTemp1)
  
  ## Serie mensal de credito no Banrisul
  Db("OPERACAO_BANRI") |> 
    select(
      DATA_REFERENCIA,
      SEQUENCIA_CLIENTE, 
      VLR_VENCIDO,
      VLR_VINCENDO
    ) |> 
    filter(
      between(DATA_REFERENCIA, TO_DATE(dataAgregacaoInicial, 'YYYY-MM-DD'), TO_DATE(dataAgregacaoFinal, 'YYYY-MM-DD'))
    ) |> 
    group_by(DATA_REFERENCIA, SEQUENCIA_CLIENTE) |> 
    summarise(
      VekCreditoTomadoBanrisul_Ori = sum((VLR_VENCIDO + VLR_VINCENDO), na.rm = TRUE)
    ) |> 
    ungroup() |> 
    DbCreateTableMemoryFromQuery(tabelaFeatureTemp2)
  
  ## Calculo da razao e mediana por cliente
  Db(tabelaFeatureTemp1) |> 
    full_join(
      Db(tabelaFeatureTemp2),
      by = c("DATA_REFERENCIA", "SEQUENCIA_CLIENTE")
    ) |> 
    mutate(
      CreditoTomadoBanrisul = coalesce(VekCreditoTomadoBanrisul_Ori, 0),
      CreditoTomadoSFN = coalesce(VelCreditoTomadoSFN_Ori, CreditoTomadoBanrisul),
      RazaoCreditoTomado = case_when(
        (CreditoTomadoSFN == 0)                     ~ 0L,
        (CreditoTomadoBanrisul >= CreditoTomadoSFN) ~ 1L,
        TRUE                                        ~ round((CreditoTomadoBanrisul / CreditoTomadoSFN), digits = 6L)
      )
    ) |> 
    select(
      SEQUENCIA_CLIENTE, DATA_REFERENCIA, 
      VelCreditoTomadoSFN_Ori, CreditoTomadoSFN, 
      VekCreditoTomadoBanrisul_Ori, CreditoTomadoBanrisul, RazaoCreditoTomado
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeatureTemp3)
    
  Db(tabelaFeatureTemp3) |> 
    group_by(SEQUENCIA_CLIENTE) |> 
    summarise(
      VelCreditoTomadoSFN_Ori = APPROX_MEDIAN(VelCreditoTomadoSFN_Ori),
      CreditoTomadoSFN = APPROX_MEDIAN(CreditoTomadoSFN),
      VekCreditoTomadoBanrisul_Ori = APPROX_MEDIAN(VekCreditoTomadoBanrisul_Ori),
      CreditoTomadoBanrisul = APPROX_MEDIAN(CreditoTomadoBanrisul),
      RazaoCreditoTomado = APPROX_MEDIAN(RazaoCreditoTomado)
    ) |> 
    ungroup() |> 
    DbCast(
      SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE(),
      VelCreditoTomadoSFN_Ori = DbCastToDouble(12L, 2L),
      CreditoTomadoSFN = DbCastToDouble(12L, 2L),
      VekCreditoTomadoBanrisul_Ori = DbCastToDouble(12L, 2L),
      CreditoTomadoBanrisul = DbCastToDouble(12L, 2L),
      RazaoCreditoTomado = DbCastToDouble(7L, 6L)
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)
  
  DbDropMemoryTable(tabelaFeatureTemp1)
  DbDropMemoryTable(tabelaFeatureTemp2)
  DbDropMemoryTable(tabelaFeatureTemp3)
  
  ## Retorno do nome da tabela
  # Retorna sucesso visivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
