#' @title Gerar o Feature Group de Uso de Canais Digitais
#'
#' @usage
#' GenerateFeatureLineage_IM_ML_USO_DIGITAL(
#'   tabelaClientesValidos,
#'   sufixoTabela = "TREINO",
#'   dataFeature = dataFeatureTreino,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Calcula, para cada cliente válido, a mediana mensal da quantidade de transações
#' financeiras e de consultas realizadas no canal digital na janela de agregação.
#'
#' @details
#' São consideradas as transações de `TRANSACOES` com `COD_SITUACAO_TRANSACAO == "OK"` e
#' `COD_CANAL == 2`. Uma transação é financeira quando `VALOR > 0` e consulta caso
#' contrário. As quantidades são somadas por cliente, mês e tipo, resumidas pela mediana
#' aproximada e pivotadas em colunas, com zero para o tipo ausente:
#' \deqn{\tilde{Q}_{c,t} = \mathrm{mediana}_{m} \sum_{i \in (c, m, t)} q_i}
#'
#' A função segue o contrato comum dos feature groups: registra
#' `on.exit(TerminateTarget())`, monta o nome da tabela de saída
#' `IM_ML_USO_DIGITAL_{SUFIXO}`, executa a consulta no Oracle por meio de `dbplyr` e grava
#' o resultado com `DbCreateTableMemoryFromQuery()`, que remove a tabela anterior de mesmo
#' nome. A função é descoberta pelos pipelines de dados por meio do prefixo
#' `GenerateFeatureLineage_IM_ML_` e executada uma vez para treino e uma vez para
#' predição.
#'
#' Clientes ausentes da tabela recebem valor nulo nas colunas deste grupo após a junção em
#' `Generate_IM_ML_FEATURE_STORE()`.
#'
#' Os argumentos `dataFeature`, `janelaAgregacao`, `janelaHistorico`,
#' `dataHistoricaInicial`, `dataHistoricaFinal` não são usados no corpo da função; existem
#' para manter a assinatura comum chamada por `tar_map()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(GenerateFeatureLineage_IM_ML_USO_DIGITAL,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "GenerateFeatureLineage_IM_ML_USO_DIGITAL_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(GenerateFeatureLineage_IM_ML_USO_DIGITAL,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "GenerateFeatureLineage_IM_ML_USO_DIGITAL_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha as conexões de banco de dados ao final, inclusive em caso de erro, por meio de
#'   `on.exit(TerminateTarget())`;
#' - remove, se existir, e recria a tabela `IM_ML_USO_DIGITAL_{SUFIXO}` no Oracle.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `TRANSACOES`, `tabelaClientesValidos`                         |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | `DATA_REFERENCIA` entre `dataAgregacaoInicial` e              |
#' |                     | `dataAgregacaoFinal`                                          |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`                                           |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | nenhuma                                                       |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_USO_DIGITAL_{SUFIXO}`                                  |
#' +---------------------+---------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +---------------------------+---------------------------------------------------------+
#' | Coluna                    | Descrição                                               |
#' +===========================+=========================================================+
#' | `SEQUENCIA_CLIENTE`       | Identificador do cliente, sem conversão de tipo         |
#' +---------------------------+---------------------------------------------------------+
#' | `VfpQtdDigitalFinanceiro` | Mediana mensal da quantidade de transações financeiras; |
#' |                           | inteiro de quatro dígitos                               |
#' +---------------------------+---------------------------------------------------------+
#' | `VfpQtdDigitalConsulta`   | Mediana mensal da quantidade de consultas; inteiro de   |
#' |                           | quatro dígitos                                          |
#' +---------------------------+---------------------------------------------------------+
#'
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos (`IM_ML_CLIENTES_VALIDOS_{SUFIXO}`), usada para restringir a
#'   população por `semi_join()`.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe o
#'   nome da tabela de saída, como `"TREINO"` ou `"PREDICAO"`. Valor padrão de referência:
#'   `"TREINO"`, sobrescrito pelos pipelines.
#' @param dataFeature Data de referência dos preditores, no formato `"AAAA-MM-DD"`. Não
#'   utilizado no corpo da função. Valor padrão de referência: `dataFeatureTreino`,
#'   sobrescrito pelos pipelines.
#' @param janelaAgregacao Inteiro com o número de meses da janela de agregação. Não
#'   utilizado no corpo da função.
#' @param janelaHistorico Inteiro com o número de meses da janela histórica. Não utilizado
#'   no corpo da função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação, no formato
#'   `"AAAA-MM-DD"`.
#' @param dataAgregacaoFinal Data final da janela de agregação, no formato `"AAAA-MM-DD"`.
#' @param dataHistoricaInicial Data inicial da janela histórica, no formato
#'   `"AAAA-MM-DD"`. Não utilizado no corpo da função.
#' @param dataHistoricaFinal Data final da janela histórica, no formato `"AAAA-MM-DD"`.
#'   Não utilizado no corpo da função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela criada
#'   (`IM_ML_USO_DIGITAL_{SUFIXO}`).
#'
#' @family Geração de Feature Groups
#'
#' @seealso \code{\link{BuildPipelineHistoricalData}},
#'   \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{TerminateTarget}}
#'
#' @references
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: conexão Oracle e tabela de clientes válidos criadas
#' tabelaFeature <- GenerateFeatureLineage_IM_ML_USO_DIGITAL(
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
GenerateFeatureLineage_IM_ML_USO_DIGITAL <- function(
    tabelaClientesValidos,
    sufixoTabela = "TREINO",
    dataFeature = dataFeatureTreino,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Registro da finalizacao de seguranca
  # Define finalizacao da execucao
  on.exit(TerminateTarget())
  
  ## Definicao do nome da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1])
  
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_USO_DIGITAL_", str_to_upper(sufixoTabela))
  
  ## Agregacao, pivotamento e gravacao
  # Gera preditores da tabela TRANSACOES sobre uso digital
  Db("TRANSACOES") |> 
    filter(
      (COD_SITUACAO_TRANSACAO == "OK"),
      (COD_CANAL == 2L),
      between(DATA_REFERENCIA, TO_DATE(dataAgregacaoInicial, 'YYYY-MM-DD'), TO_DATE(dataAgregacaoFinal, 'YYYY-MM-DD'))
    ) |> 
    semi_join(
      Db(tabelaClientesValidos),
      by = "SEQUENCIA_CLIENTE"
    ) |>
    mutate(
      TipoDigital = ifelse(
        test = (VALOR > 0),
        yes = !!DbCastToLogical(TRUE),
        no = !!DbCastToLogical(FALSE)
      )
    ) |> 
    group_by(SEQUENCIA_CLIENTE, DATA_REFERENCIA, TipoDigital) |> 
    summarise(
      QUANTIDADE = sum(QUANTIDADE, na.rm = TRUE)
    ) |> 
    ungroup() |>
    group_by(SEQUENCIA_CLIENTE, TipoDigital) |> 
    summarise(
      QUANTIDADE = APPROX_MEDIAN(QUANTIDADE)
    ) |> 
    ungroup() |> 
    mutate(
      QUANTIDADE = !!DbCastToInteger(QUANTIDADE, 4),
      VfpQtdDigital = ifelse(
        test = (TipoDigital == 1L),
        yes = "Financeiro",
        no = "Consulta"
      ),
    ) |>
    select(SEQUENCIA_CLIENTE, QUANTIDADE, VfpQtdDigital) |> 
    DbPivotWider(
      names_from = VfpQtdDigital,
      values_from = QUANTIDADE,
      values_fill = 0,
      names_prefix = "VfpQtdDigital"
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature)

  ## Retorno do nome da tabela
  # Retorna sucesso invisivel
  return(invisible(tabelaFeature))
}
####
## Fim
#
