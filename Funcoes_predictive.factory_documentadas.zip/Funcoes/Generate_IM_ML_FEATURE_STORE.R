#' @title Consolidar os Feature Groups na Feature Store In-Memory
#'
#' @usage
#' Generate_IM_ML_FEATURE_STORE(
#'   nomesTabelas = list(
#'     "IM_ML_BHL_MARGEM_CONTRIBUICAO_PREDICAO", "IM_ML_CARTAO_CREDITO_PREDICAO",
#'     "IM_ML_CARTEIRA_CLIENTE_META_PREDICAO", "IM_ML_CLIENTE_PREDICAO",
#'     "IM_ML_COMPOSICAO_DIVIDA_PREDICAO", "IM_ML_CREDITO_LIQUIDACAO_PREDICAO",
#'     "IM_ML_DEBITO_AUTOMATICO_PREDICAO", "IM_ML_FONTE_RENDA_PREDICAO",
#'     "IM_ML_HISTORICO_AGENCIA_PREDICAO", "IM_ML_HISTORICO_CLIENTE_PREDICAO",
#'     "IM_ML_LIMITE_CLI_MES_PREDICAO", "IM_ML_PERFIL_RISCO_PREDICAO",
#'     "IM_ML_PORTABILIDADE_CREDITO_PREDICAO", "IM_ML_PORTABILIDADE_SALARIO_PREDICAO",
#'     "IM_ML_POS_KPI_CLIENTE_PF_MES_PREDICAO", "IM_ML_RFM_PREDICAO",
#'     "IM_ML_RISCO_CLIENTE_PREDICAO", "IM_ML_SEGMENTO_GPC", "IM_ML_SHARE_WALLET",
#'     "IM_ML_SLD_CONTA_CORR_POUP_PREDICAO", "IM_ML_TOMADOR_CREDITO_PREDICAO",
#'     "IM_ML_TRANSACOES_PREDICAO", "IM_ML_USO_DIGITAL_PREDICAO"
#'   ),
#'   tabelaClientesValidos,
#'   sufixoTabela = "",
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Une, por `SEQUENCIA_CLIENTE`, a tabela de clientes válidos e todas as tabelas de
#' feature groups em uma única tabela in-memory `IM_ML_FEATURE_STORE_{SUFIXO}`, acrescida
#' das colunas de contexto da referência e das janelas.
#'
#' @details
#' A consolidação é executada no Oracle em uma única consulta:
#'
#' #. cria o join group `IM_JG_ML_FEATURE_STORE_{SUFIXO}` sobre `SEQUENCIA_CLIENTE` para
#'    as tabelas de `nomesTabelas`, por meio de `DbCreateJoinGroup()`, o que acelera as
#'    junções em tabelas in-memory;
#' #. parte da tabela de clientes válidos, com os hints `FULL`, `USE_HASH` para as tabelas
#'    de features e `PARALLEL 8`;
#' #. aplica `left_join()` sucessivos com cada tabela de feature group, por meio de
#'    `purrr::reduce()`;
#' #. acrescenta `DATA_REFERENCIA_FEATURE`, `JANELA_AGREGACAO` e `JANELA_HISTORICO` e
#'    converte os tipos com `DbCast()`;
#' #. grava o resultado com `DbCreateTableMemoryFromQuery()`, com quatro threads de
#'    inserção.
#'
#' Como as junções são `left_join()` a partir da população válida, o número de linhas da
#' feature store é igual ao número de clientes válidos, desde que cada feature group tenha
#' no máximo uma linha por cliente. Clientes sem registro em um feature group recebem
#' nulos nas colunas daquele grupo.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **Valores Padrão de Referência:**
#' A lista padrão de `nomesTabelas` reflete um conjunto antigo de tabelas de predição e
#' contém nomes que não seguem o padrão `_PREDICAO` (por exemplo, `IM_ML_SEGMENTO_GPC`).
#' Nos pipelines, o argumento é sempre informado com os nomes retornados pelos targets
#' `trainingFeatureGroupTable_*` ou `predictionFeatureGroupTable_*`.
#' :::
#'
#' Os argumentos `dataAgregacaoInicial`, `dataAgregacaoFinal`, `dataHistoricaInicial` e
#' `dataHistoricaFinal` não são usados no corpo da função.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(Generate_IM_ML_FEATURE_STORE, prefix = "##", code = FALSE,
#'   narrow = TRUE), "Generate_IM_ML_FEATURE_STORE_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(Generate_IM_ML_FEATURE_STORE,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "Generate_IM_ML_FEATURE_STORE_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - cria o join group `IM_JG_ML_FEATURE_STORE_{SUFIXO}` no Oracle;
#' - remove, se existir, e recria a tabela `IM_ML_FEATURE_STORE_{SUFIXO}`.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `tabelaClientesValidos` e as tabelas `IM_ML_{GRUPO}_{SUFIXO}` |
#' |                     | de `nomesTabelas`                                             |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | nenhum; o período já está aplicado em cada feature group      |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | `SEQUENCIA_CLIENTE`                                           |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | join group `IM_JG_ML_FEATURE_STORE_{SUFIXO}`                  |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `IM_ML_FEATURE_STORE_{SUFIXO}`                                |
#' +---------------------+---------------------------------------------------------------+
#'
#' @section Dicionário de Features:
#' +---------------------------+---------------------------------------------------------+
#' | Coluna                    | Descrição                                               |
#' +===========================+=========================================================+
#' | `SEQUENCIA_CLIENTE`       | Identificador do cliente                                |
#' +---------------------------+---------------------------------------------------------+
#' | `DATA_REFERENCIA_FEATURE` | Data de referência dos preditores (`dataFeature`), tipo |
#' |                           | data                                                    |
#' +---------------------------+---------------------------------------------------------+
#' | `JANELA_AGREGACAO`        | Janela de agregação em meses, inteiro de dois dígitos   |
#' +---------------------------+---------------------------------------------------------+
#' | `JANELA_HISTORICO`        | Janela histórica em meses, inteiro de dois dígitos      |
#' +---------------------------+---------------------------------------------------------+
#' | demais colunas            | Preditores de cada feature group, conforme a função     |
#' |                           | `GenerateFeatureLineage_IM_ML_*` correspondente         |
#' +---------------------------+---------------------------------------------------------+
#'
#' @param nomesTabelas Lista de nomes de tabelas de feature groups no Oracle. O valor
#'   padrão é uma lista de referência com 23 tabelas de predição.
#' @param tabelaClientesValidos Vetor de caracteres de comprimento 1 com o nome da tabela
#'   de clientes válidos, base das junções.
#' @param sufixoTabela Vetor de caracteres; o primeiro elemento, em maiúsculas, compõe os
#'   nomes do join group e da tabela de saída (padrão: `""`).
#' @param dataFeature Data de referência dos preditores, gravada em
#'   `DATA_REFERENCIA_FEATURE`.
#' @param janelaAgregacao Inteiro gravado em `JANELA_AGREGACAO`.
#' @param janelaHistorico Inteiro gravado em `JANELA_HISTORICO`.
#' @param dataAgregacaoInicial Data inicial da janela de agregação. Não utilizada no corpo
#'   da função.
#' @param dataAgregacaoFinal Data final da janela de agregação. Não utilizada no corpo da
#'   função.
#' @param dataHistoricaInicial Data inicial da janela histórica. Não utilizada no corpo da
#'   função.
#' @param dataHistoricaFinal Data final da janela histórica. Não utilizada no corpo da
#'   função.
#'
#' @returns Vetor de caracteres de comprimento 1, invisível, com o nome da tabela
#'   `IM_ML_FEATURE_STORE_{SUFIXO}`.
#'
#' @family Feature Store
#'
#' @seealso \code{\link{DefineValidCustomers}}, \code{\link{ConsolidateHistoricalData}},
#'   \code{\link{BuildPipelineHistoricalData}}, \code{\link[purrr]{reduce}}
#'
#' @references
#' Hermann, J., & Del Balso, M. (2017). Meet Michelangelo: Uber's Machine Learning
#' Platform. Uber Engineering Blog.
#' \url{https://www.uber.com/blog/michelangelo-machine-learning-platform/}
#'
#' Oracle Database In-Memory Guide: Join Groups.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' dbplyr: A dplyr back end for databases.
#' \url{https://dbplyr.tidyverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: tabelas de feature groups criadas no Oracle
#' tabelaFeatureStore <- Generate_IM_ML_FEATURE_STORE(
#'   nomesTabelas = list("IM_ML_CLIENTE_TREINO", "IM_ML_RFM_TREINO"),
#'   tabelaClientesValidos = "IM_ML_CLIENTES_VALIDOS_TREINO",
#'   sufixoTabela = "TREINO",
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @importFrom purrr map reduce
#'
#' @export
Generate_IM_ML_FEATURE_STORE <- function(
    nomesTabelas = list(
      "IM_ML_BHL_MARGEM_CONTRIBUICAO_PREDICAO",
      "IM_ML_CARTAO_CREDITO_PREDICAO",
      "IM_ML_CARTEIRA_CLIENTE_META_PREDICAO",        
      "IM_ML_CLIENTE_PREDICAO",       
      "IM_ML_COMPOSICAO_DIVIDA_PREDICAO",
      "IM_ML_CREDITO_LIQUIDACAO_PREDICAO",
      "IM_ML_DEBITO_AUTOMATICO_PREDICAO",
      "IM_ML_FONTE_RENDA_PREDICAO",
      "IM_ML_HISTORICO_AGENCIA_PREDICAO",
      "IM_ML_HISTORICO_CLIENTE_PREDICAO",
      "IM_ML_LIMITE_CLI_MES_PREDICAO",
      "IM_ML_PERFIL_RISCO_PREDICAO",
      "IM_ML_PORTABILIDADE_CREDITO_PREDICAO",
      "IM_ML_PORTABILIDADE_SALARIO_PREDICAO",
      "IM_ML_POS_KPI_CLIENTE_PF_MES_PREDICAO",
      "IM_ML_RFM_PREDICAO",
      "IM_ML_RISCO_CLIENTE_PREDICAO",
      "IM_ML_SEGMENTO_GPC",
      "IM_ML_SHARE_WALLET",
      "IM_ML_SLD_CONTA_CORR_POUP_PREDICAO",
      "IM_ML_TOMADOR_CREDITO_PREDICAO",
      "IM_ML_TRANSACOES_PREDICAO",
      "IM_ML_USO_DIGITAL_PREDICAO"
    ),
    tabelaClientesValidos,
    sufixoTabela = "",
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Normalizacao do sufixo da tabela
  # Sufixo em maiusculo
  sufixoTabela <- str_to_upper(sufixoTabela[1L])
  
  ## Criacao do join group
  # Cria join group para acelerar processamento de joins
  DbCreateJoinGroup(
    tableName = glue::glue("IM_JG_ML_FEATURE_STORE_{sufixoTabela}"),
    keyJoin = "SEQUENCIA_CLIENTE",
    tablesJoin = unlist(nomesTabelas)
  )
  
  ## Montagem das referencias das tabelas
  # Monta nome da tabela
  tabelaFeature <- str_c("IM_ML_FEATURE_STORE_", str_to_upper(sufixoTabela))
  
  # Transforma os textos puros nos ponteiros virtuais de banco de dados
  listaPonteirosDbplyr <- map(nomesTabelas, Db, exibirTabela = FALSE, hintFULL = TRUE)
  
  ## Consolidacao e gravacao da feature store
  # Processa left_joins
  reduce(
    .x = listaPonteirosDbplyr,
    .f = ~ left_join(
      x = .x, 
      y = .y, 
      by = "SEQUENCIA_CLIENTE"
    ),
    .init = Db(
      tabela = tabelaClientesValidos, 
      exibirTabela = FALSE, 
      hintFULL = TRUE,
      hintUSE_HASH = unlist(nomesTabelas) ,
      hintPARALLEL = 8L
    )
  ) |> 
    mutate(
      DATA_REFERENCIA_FEATURE = as.Date(dataFeature),
      JANELA_AGREGACAO = as.integer(janelaAgregacao),
      JANELA_HISTORICO =  as.integer(janelaHistorico)
    ) |> 
    select(
      SEQUENCIA_CLIENTE, 
      DATA_REFERENCIA_FEATURE, 
      JANELA_AGREGACAO, JANELA_HISTORICO, 
      everything()
    ) |> 
    DbCast(
      SEQUENCIA_CLIENTE = DbCastTo_SEQUENCIA_CLIENTE(),
      DATA_REFERENCIA_FEATURE = DbCastToDate(),
      JANELA_AGREGACAO = DbCastToInteger(2L),
      JANELA_HISTORICO =  DbCastToInteger(2L)
    ) |> 
    DbCreateTableMemoryFromQuery(tabelaFeature, nThreadsInsert = 4L)
  
  

  ## Retorno do nome da tabela
  # Retorna sucesso
  return(invisible(tabelaFeature))
}
####
## Fim
#
