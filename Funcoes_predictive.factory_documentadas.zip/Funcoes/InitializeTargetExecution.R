#' @title Inicializar a Execução de um Target
#'
#' @usage
#' InitializeTargetExecution()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Prepara o processo antes da execução de cada target do pipeline, encerrando todas as
#' conexões de banco de dados abertas.
#'
#' @details
#' `BuildPipeline()` registra esta função com `tarchetypes::tar_hook_before()` em todos os
#' targets. Como os targets podem executar em workers `crew` que reaproveitam processos, a
#' desconexão prévia evita o uso de conexões herdadas de targets anteriores, inválidas ou
#' ligadas a outro contexto.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(InitializeTargetExecution, prefix = "##", code = FALSE,
#'   narrow = TRUE), "InitializeTargetExecution_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(InitializeTargetExecution, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "InitializeTargetExecution_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha todas as conexões de banco de dados abertas no processo, por meio de
#'   `DbDisconnectAll()`.
#'
#' @returns `NULL` invisível.
#'
#' @family Orquestração do Pipeline
#'
#' @seealso \code{\link{TerminateTarget}}, \code{\link{BuildPipeline}},
#'   \code{\link[tarchetypes]{tar_hook_before}}
#'
#' @references
#' tarchetypes: Archetypes for Targets.
#' \url{https://docs.ropensci.org/tarchetypes/}
#'
#' DBI: R Database Interface.
#' \url{https://dbi.r-dbi.org/}
#'
#' @examples
#' \dontrun{
#' InitializeTargetExecution()
#' }
#'
#' @export
InitializeTargetExecution <- function(){
  
  ## Encerramento das conexoes de banco de dados
  DbDisconnectAll()
  
  ## Retorno invisivel
  # Funcao sem retorno
  invisible()
}
####
## Fim
# 