#' @title Carregar um Artefato Persistido em Parquet ou qs2
#'
#' @usage
#' LoadArtifacts(fileArtifacts, msgProcess = TRUE)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Localiza e carrega um artefato gravado por `PersistArtifacts()`: tabelas em Parquet,
#' lidas por meio do DuckDB, ou demais objetos em formato `qs2`.
#'
#' @details
#' #. procura em `dirname(fileArtifacts)` o primeiro arquivo cujo nome corresponde ao
#'    padrão `basename(fileArtifacts)`, sem diferenciar maiúsculas e minúsculas;
#' #. quando nenhum arquivo é encontrado, emite alerta e retorna `FALSE` invisível;
#' #. para arquivos `.parquet`, lê com `read_parquet()` em uma instância DuckDB em
#'    memória, converte colunas de texto com até 100 categorias em fator por
#'    `ConverterTextoParaFator()` e reordena os níveis de `TARGET` binário;
#' #. para os demais arquivos, lê com `qs2::qs_read()` com verificação de checksum.
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Pontos de Atenção:**
#' O nome do arquivo é usado como expressão regular em `list.files()`; caracteres como `.`
#' são interpretados como curinga. No ramo `qs2`, a leitura usa `fileArtifacts` e não o
#' caminho localizado, de modo que `fileArtifacts` deve conter a extensão. A reordenação
#' de `TARGET` usa o primeiro nível atual como referência e, portanto, não altera a ordem
#' dos níveis. A função não é chamada por nenhum pipeline do projeto.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(LoadArtifacts, prefix = "##", code = FALSE,
#'   narrow = TRUE), "LoadArtifacts_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(LoadArtifacts, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "LoadArtifacts_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - abre e encerra uma instância DuckDB em memória para arquivos Parquet;
#' - escreve no console as mensagens de progresso quando `msgProcess` é `TRUE`.
#'
#' @param fileArtifacts Caminho do artefato. O nome do arquivo é tratado como padrão de
#'   busca.
#' @param msgProcess Lógico: exibe mensagens de progresso (padrão: `TRUE`).
#'
#' @returns O objeto carregado: tibble para Parquet ou o objeto R original para `qs2`.
#'   Retorna `FALSE` invisível quando o arquivo não é encontrado.
#'
#' @family Persistência de Artefatos
#'
#' @seealso \code{\link{PersistArtifacts}}, \code{\link[qs2]{qs_read}}
#'
#' @references
#' Raasveldt, M., & Mühleisen, H. (2019). DuckDB: an Embeddable Analytical Database.
#' Proceedings of the 2019 International Conference on Management of Data, 1981-1984.
#' \url{https://doi.org/10.1145/3299869.3320212}
#'
#' Apache Parquet Documentation.
#' \url{https://parquet.apache.org/docs/}
#'
#' qs2: Efficient Serialization of R Objects.
#' \url{https://cran.r-project.org/package=qs2}
#'
#' @examples
#' \dontrun{
#' dadosTreino <- LoadArtifacts(
#'   fileArtifacts = file.path(artifactsPath, "trainingSet.parquet")
#' )
#' }
#'
#' @importFrom qs2 qs_read
#' @importFrom DBI dbConnect dbGetQuery dbDisconnect
#'
#' @export
LoadArtifacts <- function(fileArtifacts, msgProcess = TRUE){
  
  ## Localizacao do arquivo
  # Busca endereco e nome completo do arquivo com extensao
  arquivo <- list.files(
    path = dirname(fileArtifacts),
    pattern = basename(fileArtifacts),
    full.names = TRUE,
    all.files = FALSE,
    recursive = FALSE,
    ignore.case = TRUE
  )[1]
  
  ## Retorno quando o arquivo nao existe
  # Se encontrou 
  if(!file.exists(arquivo)){
    
    cli::cli_alert_danger("Arquivo {.file {arquivo}} não encontrado!")
    
    return(invisible(FALSE))
  }
  
  # Mensagem de processamento
  if(msgProcess){
    idPasso <- cli::cli_progress_step(
      msg = "Carregando artefato do arquivo {.file {arquivo}}",
      msg_done = "Artefato carregado com sucesso!"
    )
  }
  
  ## Leitura do artefato
  # Se detectou a extensao parquet
  if(stringr::str_detect(arquivo, "\\.parquet$")){
    
    # Inicia a conexao nativa em memoria com o driver do DuckDB
    conexaoDuck <- DBI::dbConnect(duckdb::duckdb(), dbdir = ":memory:")
    
    # Constroi a query SQL utilizando a funcao nativa read_parquet do DuckDB
    queryLeitura <- glue::glue("SELECT * FROM read_parquet('{arquivo}')")
    
    # Executa a leitura otimizada e armazena o resultado na memoria do R
    objeto <- DBI::dbGetQuery(
      conn = conexaoDuck, 
      statement = queryLeitura
    ) |> 
      tibble::as_tibble()
    
    # Encerra a conexao e desliga a instancia do DuckDB para liberar memoria
    DBI::dbDisconnect(conexaoDuck, shutdown = TRUE)
    
    # Ajusta factores (parquet nao guarda factors)
    objeto <- ConverterTextoParaFator(
      dadosTibble = objeto,
      limiteCategorias = 100L
    )
    
    # Se possui alvo de predicao
    if(!is.null(objeto$TARGET)){
      
      # Se for binario Sim/Nao
      if(length(levels(objeto$TARGET)) == 2L){
        
        # Ajusta o Sim como primeiro valor
        objeto <- objeto |> 
          mutate(
            TARGET = fct_relevel(TARGET, levels(objeto$TARGET)[1L])
          )
      }
    }
    
    
  } else {
    
    # Salva arquivo de artefatos
    objeto <- qs2::qs_read(
      file = fileArtifacts,
      nthreads = getOption("threadsQS", QtdCores()),
      validate_checksum = TRUE
    )
  }
  
  # Mensagem de processamento
  if(msgProcess){
    cli_progress_done(idPasso)
  }
  
  ## Retorno do objeto
  # Retorna objeto
  return(objeto)
}
####
## Fim
# 
