#' @title Carregar a Configuração de Execução do Modelo Preditivo
#'
#' @usage
#' LoadModelRunConfig()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Lê o arquivo `_PredictiveModelRunConfig.yaml` do modelo em execução, converte a data de
#' referência para `Date` e publica a configuração no ambiente global e nas opções da
#' sessão, para uso pelos targets do pipeline.
#'
#' @details
#' O modelo é identificado pela variável de ambiente `GPC_PREDICTIVE_FACTORY_RUN_CONFIG`,
#' definida por `ConfigurePredictiveModelRun()`. Quando a variável não existe, é usado o
#' valor de referência `"DESERCAO_202601_P03_A06_H36"`, útil em sessões interativas de
#' desenvolvimento.
#'
#' O arquivo é procurado em
#' `{DirDados}/gpc.predictive.factory/Dados/{idModel}/_PredictiveModelRunConfig.yaml`. Os
#' elementos da configuração são expostos em quatro níveis no ambiente global: a lista
#' completa e os conteúdos de `configs`, `paths` e `datas`. Por isso, os targets podem
#' referenciar diretamente objetos como `dataFeatureTreino` ou `logsTracesPath`.
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Escrita no Ambiente Global:**
#' Objetos do ambiente global com os mesmos nomes dos elementos da configuração são
#' sobrescritos sem aviso.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(LoadModelRunConfig, prefix = "##", code = FALSE,
#'   narrow = TRUE), "LoadModelRunConfig_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(LoadModelRunConfig, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "LoadModelRunConfig_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - cria ou sobrescreve, em `.GlobalEnv`, os objetos de `modelRunConfig`,
#'   `modelRunConfig$configs`, `modelRunConfig$paths` e `modelRunConfig$datas`;
#' - registra os elementos de primeiro nível da configuração em `options()`;
#' - escreve mensagem de sucesso no console.
#'
#' @returns Lista lida do YAML, com a mesma estrutura retornada por
#'   `ConfigurePredictiveModelRun()` e `configs$dataReferencia` convertido para `Date`. A
#'   execução é interrompida com erro quando o arquivo não existe.
#'
#' @family Orquestração do Pipeline
#'
#' @seealso \code{\link{ConfigurePredictiveModelRun}}, \code{\link{ShowStartupBanner}},
#'   \code{\link[yaml]{read_yaml}}
#'
#' @references
#' YAML Ain't Markup Language, versão 1.2.
#' \url{https://yaml.org/spec/1.2.2/}
#'
#' yaml: Methods to Convert R Data to YAML and Back.
#' \url{https://cran.r-project.org/package=yaml}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: configuração gravada por ConfigurePredictiveModelRun()
#' Sys.setenv(GPC_PREDICTIVE_FACTORY_RUN_CONFIG = "DESERCAO_202601_P03_A06_H36")
#' modelRunConfig <- LoadModelRunConfig()
#' }
#'
#' @importFrom yaml read_yaml
#'
#' @export
LoadModelRunConfig <- function(){
  
  ## Identificacao do modelo em execucao
  # Busca idModel
  idModel <- Sys.getenv("GPC_PREDICTIVE_FACTORY_RUN_CONFIG", unset = "DESERCAO_202601_P03_A06_H36")
  
  # Arquivo de configuracoes
  yamlModelRunConfig <- glue::glue("{Sys.getenv('DirDados')}/gpc.predictive.factory/Dados/{idModel}/_PredictiveModelRunConfig.yaml")
  
  # Arquivo na encontrado
  if(!file.exists(yamlModelRunConfig)){
    stop(glue("Não foi encontrado o arquivo: {yamlModelRunConfig}"))
  }
  
  ## Leitura da configuracao YAML
  # Busca configuracoes
  modelRunConfig <- yaml::read_yaml(
    file = yamlModelRunConfig
  )
  
  # Ajusta datas
  modelRunConfig$configs$dataReferencia <- as.Date(modelRunConfig$configs$dataReferencia)
  
  ## Publicacao no ambiente global e em options
  # Extrai objetos da lista
  list2env(x = modelRunConfig, envir = .GlobalEnv)
  list2env(x = modelRunConfig$configs, envir = .GlobalEnv)
  list2env(x = modelRunConfig$paths, envir = .GlobalEnv)
  list2env(x = modelRunConfig$datas, envir = .GlobalEnv)
  
  # Guarda em options
  options(modelRunConfig)
  
  cli_alert_success(cli::col_br_white("Configurações inicias carregadas com sucesso"))

  # Retorna configuracoes de execucao do modelo
  return(modelRunConfig)
}
####
## Fim
#
