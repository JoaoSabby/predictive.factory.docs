#' @title Executar um Target com Registro de Traces, Telemetria e Auditoria
#'
#' @usage
#' LogPipelineExecution(
#'   targetCommand,
#'   targetName,
#'   logsTracesPath,
#'   logsTelemetryPath,
#'   logsRegistryPath
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Envolve o comando de um target do pipeline: ativa a captura da saída do console
#' (traces) e a telemetria de hardware, avalia o comando, registra o status, a duração e a
#' memória em um arquivo de auditoria diário e devolve o resultado do target.
#'
#' @details
#' `BuildPipeline()` aplica esta função a todos os targets por meio de
#' `tarchetypes::tar_hook_outer()`, que substitui `targetCommand` pela expressão original
#' do target (`.x`). Como os argumentos do R são avaliados sob demanda, o comando só é
#' executado dentro do `tryCatch()`, depois que o monitoramento foi ativado.
#'
#' A sequência é:
#'
#' #. coleta do instante de início, do PID do processo, do PID mestre (variável de
#'    ambiente `MASTER_PID`) e da memória disponível, obtida com `free -m` (coluna
#'    `available`, em MB);
#' #. ativação dos traces por `LogPipelineExecutionTraces()` e da telemetria por
#'    `LogPipelineExecutionTelemetry()`;
#' #. registro, em `on.exit()`, do encerramento da telemetria, dos `sink()` e da conexão
#'    de trace, e da gravação da linha de auditoria por `LogPipelineExecutionRegistry()`;
#' #. avaliação do comando; em caso de erro, o status passa a `"error"`, a mensagem é
#'    gravada sem quebras de linha e sem o caractere `|`, e o erro é relançado para o
#'    `targets`.
#'
#' O processo é considerado worker quando `MASTER_PID` está definido e difere do PID
#' atual.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(LogPipelineExecution, prefix = "##", code = FALSE,
#'   narrow = TRUE), "LogPipelineExecution_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(LogPipelineExecution, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "LogPipelineExecution_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - cria um arquivo de trace e um arquivo de telemetria por execução de target;
#' - redireciona a saída padrão e as mensagens para o arquivo de trace durante a execução
#'   do comando;
#' - acrescenta uma linha ao arquivo de auditoria diário em `logsRegistryPath`;
#' - executa o comando de sistema `free -m` no início e no fim.
#'
#' @param targetCommand Expressão do comando do target, inserida por `tar_hook_outer()`. É
#'   avaliada apenas dentro da função.
#' @param targetName Vetor de caracteres de comprimento 1 com o nome do target, obtido por
#'   `targets::tar_name()`.
#' @param logsTracesPath Caminho da pasta de traces (`logs/traces` do modelo).
#' @param logsTelemetryPath Caminho da pasta de telemetria (`logs/telemetry` do modelo).
#' @param logsRegistryPath Caminho da pasta do registro de auditoria (`logs/registry` do
#'   modelo).
#'
#' @returns O valor produzido pelo comando do target. Em caso de erro, a condição original
#'   é relançada.
#'
#' @family Registro de Execução
#'
#' @seealso \code{\link{LogPipelineExecutionTraces}},
#'   \code{\link{LogPipelineExecutionTelemetry}},
#'   \code{\link{LogPipelineExecutionRegistry}}, \code{\link{BuildPipeline}},
#'   \code{\link[tarchetypes]{tar_hook_outer}}
#'
#' @references
#' Sigelman, B. H., Barroso, L. A., Burrows, M., et al. (2010). Dapper, a Large-Scale
#' Distributed Systems Tracing Infrastructure. Google Technical Report dapper-2010-1.
#' \url{https://research.google/pubs/pub36356/}
#'
#' tarchetypes: Target hooks.
#' \url{https://docs.ropensci.org/tarchetypes/reference/tar_hook_outer.html}
#'
#' autometric: Background Resource Logging.
#' \url{https://wlandau.github.io/autometric/}
#'
#' @examples
#' \dontrun{
#' # Uso típico, por meio de tar_hook_outer() em BuildPipeline()
#' resultado <- LogPipelineExecution(
#'   targetCommand = sum(1:10),
#'   targetName = "exemplo",
#'   logsTracesPath = tempdir(),
#'   logsTelemetryPath = tempdir(),
#'   logsRegistryPath = tempdir()
#' )
#' }
#'
#' @export
LogPipelineExecution <- function(
    targetCommand, 
    targetName,
    logsTracesPath,
    logsTelemetryPath,
    logsRegistryPath
){
  
  ## Coleta dos metadados de inicio
  # Metadados Globais do Ambiente
  sufixoTempo <- format(Sys.time(), "%Y%m%d_%H%M%S")
  masterPid <- Sys.getenv("MASTER_PID")
  workerPid <- Sys.getpid()
  isWorker <- if(masterPid != "") as.character(workerPid) != masterPid else FALSE
  horarioInicio <- Sys.time()
  ramInicial <- tryCatch(system("free -m | awk '/^Mem:/ {print $7}'", intern = TRUE), error = function(e) "NA")
  
  statusExecucao <- "success"
  mensagemErro <- ""
  
  ## Ativacao de traces e telemetria
  # Ativa os Módulos de Monitoramento Contínuo
  conexaoTrace <- LogPipelineExecutionTraces(
    logsTracesPath = logsTracesPath, 
    targetName = targetName, 
    sufixoTempo = sufixoTempo, 
    isWorker = isWorker
  )
  
  # Monitoramento de Telemetria de Hardware
  LogPipelineExecutionTelemetry(
    logsTelemetryPath = logsTelemetryPath, 
    targetName = targetName, 
    sufixoTempo = sufixoTempo, 
    workerPid = workerPid
  )
  
  ## Registro do encerramento e da auditoria
  # Bloco de Encerramento (Executa aconteça o que acontecer, até em caso de falha)
  on.exit({
    horarioFim <- Sys.time()
    ramFinal <- tryCatch(system("free -m | awk '/^Mem:/ {print $7}'", intern = TRUE), error = function(e) "NA")
    
    # Desliga a Telemetria
    if(requireNamespace("autometric", quietly = TRUE)){
      autometric::log_stop()
    }  
    
    # Desliga os Traces
    sink(type = "message")
    sink()
    close(conexaoTrace)
    
    # Grava o resultado final no Registry
    LogPipelineExecutionRegistry(
      logsRegistryPath = logsRegistryPath,
      targetName = targetName, 
      masterPid = masterPid, 
      workerPid = workerPid, 
      horarioInicio = horarioInicio, 
      horarioFim = horarioFim, 
      ramInicial = ramInicial, 
      ramFinal = ramFinal,
      statusExecucao = statusExecucao, 
      mensagemErro = mensagemErro
    )
  }, add = TRUE)
  
  ## Execucao do comando do target
  # Executa a tarefa do usuário interceptando falhas para popular o Registry
  resultado <- tryCatch({
    targetCommand
  }, error = function(e){
    statusExecucao <<- "error"
    mensagemErro <<- gsub("[\r\n|]", " ", as.character(e)) # Evita quebrar o delimitador pipe
    stop(e) # Lança o erro de volta para o targets agir
  })
  
  return(resultado)
}
####
## Fim
# 
