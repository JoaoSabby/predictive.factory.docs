#' @title Gravar a Linha de Auditoria da Execução de um Target
#'
#' @usage
#' LogPipelineExecutionRegistry(
#'   logsRegistryPath,
#'   targetName,
#'   masterPid,
#'   workerPid,
#'   horarioInicio,
#'   horarioFim,
#'   ramInicial,
#'   ramFinal,
#'   statusExecucao,
#'   mensagemErro
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Acrescenta ao arquivo de auditoria do dia uma linha delimitada por `|` com o nome do
#' target, os PIDs, os horários, a duração, a memória disponível e o status da execução.
#'
#' @details
#' O arquivo é `execution_ledger_AAAAMMDD.txt` em `logsRegistryPath`, um por dia. Cada
#' linha contém, nesta ordem:
#'
#' +---------+---------------------------------------------------+
#' | Posição | Campo                                             |
#' +=========+===================================================+
#' | 1       | `targetName`                                      |
#' +---------+---------------------------------------------------+
#' | 2       | `masterPid`                                       |
#' +---------+---------------------------------------------------+
#' | 3       | `workerPid`                                       |
#' +---------+---------------------------------------------------+
#' | 4       | `horarioInicio`, no formato `AAAA-MM-DD HH:MM:SS` |
#' +---------+---------------------------------------------------+
#' | 5       | `horarioFim`, no mesmo formato                    |
#' +---------+---------------------------------------------------+
#' | 6       | duração em minutos, com três casas decimais       |
#' +---------+---------------------------------------------------+
#' | 7       | `ramInicial`, memória disponível em MB            |
#' +---------+---------------------------------------------------+
#' | 8       | `ramFinal`, memória disponível em MB              |
#' +---------+---------------------------------------------------+
#' | 9       | `statusExecucao`                                  |
#' +---------+---------------------------------------------------+
#' | 10      | `mensagemErro`                                    |
#' +---------+---------------------------------------------------+
#'
#' A duração é:
#' \deqn{\Delta t = \mathrm{round}\left(\frac{t_{fim} - t_{inicio}}{60}, 3\right)}
#' com tempos em segundos. A linha é escrita com `cat(..., "\n")`, que insere um espaço
#' antes da quebra de linha.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **Escritas Concorrentes:**
#' Workers paralelos escrevem no mesmo arquivo em modo de acréscimo. Cada chamada grava
#' uma linha curta, mas não há bloqueio explícito de arquivo.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(LogPipelineExecutionRegistry, prefix = "##", code = FALSE,
#'   narrow = TRUE), "LogPipelineExecutionRegistry_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(LogPipelineExecutionRegistry,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "LogPipelineExecutionRegistry_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - cria ou acrescenta uma linha ao arquivo `execution_ledger_AAAAMMDD.txt`.
#'
#' @param logsRegistryPath Caminho da pasta do registro de auditoria.
#' @param targetName Nome do target.
#' @param masterPid PID do processo mestre, lido de `MASTER_PID`; texto vazio quando não
#'   definido.
#' @param workerPid PID do processo que executou o target.
#' @param horarioInicio Instante de início (`POSIXct`).
#' @param horarioFim Instante de término (`POSIXct`).
#' @param ramInicial Memória disponível no início, em MB, como texto, ou `"NA"`.
#' @param ramFinal Memória disponível no término, em MB, como texto, ou `"NA"`.
#' @param statusExecucao `"success"` ou `"error"`.
#' @param mensagemErro Mensagem de erro sem quebras de linha e sem `|`; texto vazio em
#'   caso de sucesso.
#'
#' @returns `NULL` invisível.
#'
#' @family Registro de Execução
#'
#' @seealso \code{\link{LogPipelineExecution}}
#'
#' @references
#' RFC 4180: Common Format and MIME Type for Comma-Separated Values (CSV) Files, usado
#' como referência para arquivos delimitados.
#' \url{https://www.rfc-editor.org/rfc/rfc4180}
#'
#' @examples
#' \dontrun{
#' LogPipelineExecutionRegistry(
#'   logsRegistryPath = tempdir(),
#'   targetName = "exemplo",
#'   masterPid = "",
#'   workerPid = Sys.getpid(),
#'   horarioInicio = Sys.time() - 60,
#'   horarioFim = Sys.time(),
#'   ramInicial = "1024",
#'   ramFinal = "1000",
#'   statusExecucao = "success",
#'   mensagemErro = ""
#' )
#' }
#'
#' @export
LogPipelineExecutionRegistry <- function(
    logsRegistryPath,
    targetName, masterPid, workerPid, 
    horarioInicio, horarioFim, 
    ramInicial, ramFinal, 
    statusExecucao, mensagemErro
){
  
  ## Definicao do arquivo diario
  # Mantém um único ledger consolidado por dia
  arquivoRegistry <- file.path(logsRegistryPath, paste0("execution_ledger_", format(Sys.Date(), "%Y%m%d"), ".txt"))
  
  ## Calculo da duracao
  # Calcula a duração em minutos
  tempoExecucaoMin <- round(as.numeric(difftime(horarioFim, horarioInicio, units = "mins")), 3L)
  
  ## Montagem e gravacao da linha
  # Formata a linha de dados separada por pipe
  linhaAudit <- paste(
    targetName, masterPid, workerPid,
    format(horarioInicio, "%Y-%m-%d %H:%M:%S"),
    format(horarioFim, "%Y-%m-%d %H:%M:%S"),
    tempoExecucaoMin, ramInicial, ramFinal,
    statusExecucao, mensagemErro,
    sep = "|"
  )
  
  # Escreve a linha de forma atômica no arquivo central
  cat(linhaAudit, "\n", file = arquivoRegistry, append = TRUE)
  
  invisible()
}
####
## Fim
# 
