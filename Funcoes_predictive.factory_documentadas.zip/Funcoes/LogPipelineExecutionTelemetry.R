#' @title Iniciar a Telemetria de Hardware de um Target
#'
#' @usage
#' LogPipelineExecutionTelemetry(logsTelemetryPath, targetName, sufixoTempo, workerPid)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Inicia o registro de uso de recursos do processo que executa o target, com leitura a
#' cada segundo, no arquivo `{targetName}_{sufixoTempo}.log`.
#'
#' @details
#' O registro usa `autometric::log_start()`, que grava em segundo plano as métricas do
#' processo identificado por `workerPid`. O encerramento é feito por
#' `autometric::log_stop()` no `on.exit()` de `LogPipelineExecution()`. Quando o pacote
#' autometric não está instalado, a função não executa nenhuma ação.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(LogPipelineExecutionTelemetry, prefix = "##", code = FALSE,
#'   narrow = TRUE), "LogPipelineExecutionTelemetry_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(LogPipelineExecutionTelemetry,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "LogPipelineExecutionTelemetry_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - inicia um processo de registro em segundo plano e cria o arquivo de telemetria.
#'
#' @param logsTelemetryPath Caminho da pasta de telemetria.
#' @param targetName Nome do target, usado no nome do arquivo.
#' @param sufixoTempo Texto `AAAAMMDD_HHMMSS` que identifica a execução.
#' @param workerPid PID do processo monitorado.
#'
#' @returns `NULL` invisível.
#'
#' @family Registro de Execução
#'
#' @seealso \code{\link{LogPipelineExecution}}, \code{\link[autometric]{log_start}}
#'
#' @references
#' autometric: Background Resource Logging.
#' \url{https://wlandau.github.io/autometric/}
#'
#' @examples
#' \dontrun{
#' LogPipelineExecutionTelemetry(
#'   logsTelemetryPath = tempdir(),
#'   targetName = "exemplo",
#'   sufixoTempo = format(Sys.time(), "%Y%m%d_%H%M%S"),
#'   workerPid = Sys.getpid()
#' )
#' autometric::log_stop()
#' }
#'
#' @export
LogPipelineExecutionTelemetry <- function(
    logsTelemetryPath,
    targetName, 
    sufixoTempo, 
    workerPid
){
  
  ## Definicao do arquivo de telemetria
  arquivoTelemetry <- file.path(logsTelemetryPath, paste0(targetName, "_", sufixoTempo, ".log"))
  
  ## Inicio do registro de recursos
  # Verifica se o autometric está instalado antes de tentar iniciar
  if(requireNamespace("autometric", quietly = TRUE)){
    autometric::log_start(
      path = arquivoTelemetry, 
      seconds = 1L, # Lê o hardware a cada 1 segundo (baixo impacto na performance)
      pids = c(worker = workerPid)
    )
  }
  
  return(invisible(NULL))
}
####
## Fim
# 
