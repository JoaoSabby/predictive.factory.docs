#' @title Redirecionar a Saída do Console de um Target para Arquivo
#'
#' @usage
#' LogPipelineExecutionTraces(logsTracesPath, targetName, sufixoTempo, isWorker)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Abre o arquivo de trace `{targetName}_{sufixoTempo}.log` e redireciona para ele a saída
#' padrão e as mensagens do processo que executa o target.
#'
#' @details
#' A saída padrão é redirecionada com `sink(split = !isWorker)`: no processo principal, a
#' saída também continua no console; nos workers, vai apenas para o arquivo. As mensagens
#' (`type = "message"`) vão apenas para o arquivo. O encerramento dos dois `sink()` e da
#' conexão é feito no `on.exit()` de `LogPipelineExecution()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(LogPipelineExecutionTraces, prefix = "##", code = FALSE,
#'   narrow = TRUE), "LogPipelineExecutionTraces_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(LogPipelineExecutionTraces,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "LogPipelineExecutionTraces_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - cria o arquivo de trace e abre uma conexão de escrita;
#' - altera os destinos de saída e de mensagens da sessão até o encerramento.
#'
#' @param logsTracesPath Caminho da pasta de traces.
#' @param targetName Nome do target, usado no nome do arquivo.
#' @param sufixoTempo Texto `AAAAMMDD_HHMMSS` que identifica a execução.
#' @param isWorker Lógico de comprimento 1: `TRUE` quando o processo é um worker.
#'
#' @returns Conexão de arquivo aberta, que deve ser fechada por quem chamou a função.
#'
#' @family Registro de Execução
#'
#' @seealso \code{\link{LogPipelineExecution}}, \code{\link[base]{sink}}
#'
#' @references
#' R Core Team. sink: Send R Output to a File.
#' \url{https://stat.ethz.ch/R-manual/R-devel/library/base/html/sink.html}
#'
#' @examples
#' \dontrun{
#' conexaoTrace <- LogPipelineExecutionTraces(
#'   logsTracesPath = tempdir(),
#'   targetName = "exemplo",
#'   sufixoTempo = format(Sys.time(), "%Y%m%d_%H%M%S"),
#'   isWorker = FALSE
#' )
#' message("registrado no trace")
#' sink(type = "message"); sink(); close(conexaoTrace)
#' }
#'
#' @export
LogPipelineExecutionTraces <- function(
    logsTracesPath, 
    targetName, 
    sufixoTempo, 
    isWorker
){
  
  ## Definicao do arquivo de trace
  arquivoTrace <- file.path(logsTracesPath, paste0(targetName, "_", sufixoTempo, ".log"))
  
  ## Abertura da conexao e redirecionamento
  # Abre a conexão em modo de escrita de texto
  conexaoTrace <- file(arquivoTrace, open = "wt")
  
  # Se for worker, o split=FALSE evita tráfego desnecessário na rede do Oracle Linux.
  # Se for o processo principal, o split=TRUE mostra no seu RStudio ao mesmo tempo.
  sink(conexaoTrace, split = !isWorker)
  sink(conexaoTrace, type = "message")
  
  return(conexaoTrace)
}
####
## Fim
# 
