#' @title Exibir Mensagem de Construção de Pipeline
#'
#' @usage
#' MsgBuildPipeline(pipelineName)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Exibe no console uma etapa de progresso com o nome da função construtora que fez a
#' chamada e a descrição do pipeline em construção.
#'
#' @details
#' O nome da função construtora é obtido de `sys.call(-1)`, isto é, da chamada que invocou
#' `MsgBuildPipeline()`. Por isso, a função deve ser chamada diretamente dentro da função
#' construtora do pipeline, como em `BuildPipelineHistoricalData()`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(MsgBuildPipeline, prefix = "##", code = FALSE,
#'   narrow = TRUE), "MsgBuildPipeline_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(MsgBuildPipeline, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "MsgBuildPipeline_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - inicia uma etapa de progresso com `cli::cli_progress_step()`, encerrada por
#'   `cli_progress_cleanup()` em `BuildPipeline()`.
#'
#' @param pipelineName Vetor de caracteres de comprimento 1 com a descrição do pipeline
#'   exibida na mensagem.
#'
#' @returns `NULL` invisível.
#'
#' @family Construção do Pipeline
#'
#' @seealso \code{\link{BuildPipeline}}, \code{\link[cli]{cli_progress_step}}
#'
#' @references
#' cli: Helpers for Developing Command Line Interfaces.
#' \url{https://cli.r-lib.org/}
#'
#' @examples
#' \dontrun{
#' BuildPipelineExemplo <- function(){
#'   MsgBuildPipeline("feature engineering dos dados usados na modelagem")
#' }
#' BuildPipelineExemplo()
#' }
#'
#' @importFrom cli cli_progress_step
#'
#' @export
MsgBuildPipeline <- function(pipelineName){
  
  ## Exibicao da etapa de progresso
  # Processo atual
  pipelineFunc <-  deparse(sys.call(-1)[[1]])
  cli_progress_step(
    msg = "{cli::style_bold(cli::col_cyan(pipelineFunc))}: {cli::col_cyan(pipelineName)}"
  )
  
  ## Retorno invisivel
  # Sem retorno
  invisible()
}
####
## Fim
# 