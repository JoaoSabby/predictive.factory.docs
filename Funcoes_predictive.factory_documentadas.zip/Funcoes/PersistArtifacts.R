#' @title Persistir um Artefato em Parquet ou qs2
#'
#' @usage
#' PersistArtifacts(objeto, fileArtifacts, msgProcess = TRUE)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Grava um objeto em disco: tibbles em Parquet, por meio do DuckDB, e demais objetos em
#' formato `qs2`, ajustando a extensão do arquivo ao formato.
#'
#' @details
#' A extensão `.qs` ou `.parquet` informada em `fileArtifacts` é removida e substituída
#' conforme o tipo do objeto:
#'
#' +-------------+------------+----------------------------------------------------------+
#' | Tipo do     | Formato    | Gravação                                                 |
#' | objeto      |            |                                                          |
#' +=============+============+==========================================================+
#' | tibble      | `.parquet` | `COPY ... TO` do DuckDB, com `ROW_GROUP_SIZE 250000` e   |
#' |             |            | compressão ZSTD                                          |
#' +-------------+------------+----------------------------------------------------------+
#' | demais      | `.qs`      | `qs2::qs_save()`, com `compress_level = 5` e `shuffle =  |
#' |             |            | TRUE`                                                    |
#' +-------------+------------+----------------------------------------------------------+
#'
#' Data frames que não são tibbles são gravados em `qs2`. O número de threads do `qs2` vem
#' da opção `threadsQS` ou, na ausência dela, de `QtdCores()`. As variáveis locais
#' `nomeObjeto` e `funcaoChamadora` são calculadas, mas não usadas. A função não é chamada
#' por nenhum pipeline do projeto.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(PersistArtifacts, prefix = "##", code = FALSE,
#'   narrow = TRUE), "PersistArtifacts_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(PersistArtifacts, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "PersistArtifacts_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - cria ou sobrescreve o arquivo `.parquet` ou `.qs`;
#' - abre e desconecta uma instância DuckDB em memória para tibbles;
#' - escreve no console as mensagens de progresso quando `msgProcess` é `TRUE`.
#'
#' @param objeto Objeto R a persistir.
#' @param fileArtifacts Caminho do arquivo de destino, com ou sem extensão.
#' @param msgProcess Lógico: exibe mensagens de progresso (padrão: `TRUE`).
#'
#' @returns `NULL` invisível.
#'
#' @family Persistência de Artefatos
#'
#' @seealso \code{\link{LoadArtifacts}}, \code{\link[qs2]{qs_save}}
#'
#' @references
#' Raasveldt, M., & Mühleisen, H. (2019). DuckDB: an Embeddable Analytical Database.
#' Proceedings of the 2019 International Conference on Management of Data, 1981-1984.
#' \url{https://doi.org/10.1145/3299869.3320212}
#'
#' Apache Parquet Documentation.
#' \url{https://parquet.apache.org/docs/}
#'
#' qs2: Efficient Serialization of R Objects.
#' \url{https://cran.r-project.org/package=qs2}
#'
#' @examples
#' \dontrun{
#' PersistArtifacts(
#'   objeto = trainingSet,
#'   fileArtifacts = file.path(artifactsPath, "trainingSet")
#' )
#' }
#'
#' @importFrom qs2 qs_save
#' @importFrom DBI dbConnect dbExecute dbDisconnect
#'
#' @export
PersistArtifacts <- function(objeto, fileArtifacts, msgProcess = TRUE){
  
  ## Definicao do arquivo e do formato
  # Remove extensao
  arquivo <- stringr::str_remove(fileArtifacts, "\\.qs$|\\.parquet$")
  
  # Se for uma tabela de dados
  if(tibble::is_tibble(objeto)){
    arquivo <- stringr::str_c(arquivo, ".parquet")
  } else {
    arquivo <- stringr::str_c(arquivo, ".qs")
  }  
  
  ## Metadados da chamada
  # Nome do objeto passado
  nomeObjeto <- deparse(substitute(objeto))
  
  # Nome da funcao que chamou
  
  funcaoChamadora <- sys.call(-1L)
  
  # Mensagem de processamento
  if(msgProcess){
    idPasso <- cli::cli_progress_step(
      msg = "Persistindo artefato",
      msg_done = "Artefato salvo em\n{.file {arquivo}}"
    )
  }
  
  ## Gravacao do artefato
  # Se for uma tabela de dados
  if(tibble::is_tibble(objeto)){
    
    # Inicia a conexao nativa em memoria com o driver do DuckDB
    conexaoDuck <- DBI::dbConnect(duckdb::duckdb(), dbdir = ":memory:")
    
    dbExecute(conexaoDuck, "SET preserve_insertion_order = false")
    
    # Nome da tabela em memoria
    tableTemp <- glue::glue("DUCKDB_TABLE_TEMP_", stringr::str_sub(uuid::UUIDgenerate(), end = 8L))
    
    # Registra na memoria do DuckDB como uma tabela 
    duckdb::duckdb_register(
      conn = conexaoDuck, 
      name = tableTemp, 
      df = objeto
    )
    
    # Executa a gravacao direta no disco
    DBI::dbExecute(
      conn = conexaoDuck, 
      statement = stringr::str_c(
        glue::glue("COPY {tableTemp} TO '{arquivo}'"), " ",
        "(FORMAT PARQUET, ROW_GROUP_SIZE 250000, COMPRESSION 'ZSTD')"
      ) 
    )
    
    # Desconecta do duck
    DBI::dbDisconnect(conexaoDuck)
    
  } else {
    
    # Salva arquivo de artefatos
    qs2::qs_save(
      object = objeto,
      file = arquivo,
      compress_level = 5L,
      shuffle = TRUE,
      nthreads = getOption("threadsQS", QtdCores())
    )
  }
  
  # Mensagem de processamento
  if(msgProcess){
    cli_progress_done(idPasso)
  }
  
  ## Retorno invisivel
  # Funcao sem retorno
  invisible()
}
####
## Fim
#
