#' @title Executar a Predição Binária com XGBoost
#'
#' @usage
#' PredictModelXGBoost(
#'   data,
#'   model,
#'   positive = "Sim",
#'   negative = "Nao",
#'   probClassThreshold = 0.5
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Calcula a probabilidade da classe positiva com um modelo XGBoost binário e converte a
#' probabilidade em classe predita por um ponto de corte.
#'
#' @details
#' Com objetivo `binary:logistic`, a predição do XGBoost é a probabilidade estimada da
#' classe positiva:
#' \deqn{\hat{p}_i = \frac{1}{1 + e^{-F(x_i)}}}
#' em que \eqn{F(x_i) = \sum_k f_k(x_i)} é a soma das saídas das árvores. A classe predita
#' é `positive` quando \eqn{\hat{p}_i \ge c} e `negative` caso contrário, em que \eqn{c} é
#' `probClassThreshold`. A probabilidade da classe negativa é \eqn{1 - \hat{p}_i}.
#'
#' A função mantém a predição separada do ajuste, o que permite aplicar o mesmo modelo com
#' pontos de corte operacionais diferentes. O fator `.pred_class` tem `positive` como
#' primeiro nível, compatível com `event_level = "first"` do `yardstick`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(PredictModelXGBoost, prefix = "##", code = FALSE,
#'   narrow = TRUE), "PredictModelXGBoost_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(PredictModelXGBoost, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "PredictModelXGBoost_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @param data Objeto `xgb.DMatrix` com as mesmas features usadas no ajuste.
#' @param model Objeto `xgb.Booster` ajustado com objetivo `binary:logistic`.
#' @param positive Rótulo da classe positiva (padrão: `"Sim"`).
#' @param negative Rótulo da classe negativa (padrão: `"Nao"`).
#' @param probClassThreshold Número em \eqn{[0, 1]} usado como ponto de corte (padrão:
#'   `0.5`).
#'
#' @returns Tibble com uma linha por observação e as colunas `.pred_positive` (double),
#'   `.pred_negative` (double) e `.pred_class` (fator com níveis `positive` e `negative`).
#'
#' @family Avaliação do Modelo
#'
#' @seealso \code{\link{PredictModel}}, \code{\link{EvaluateModel}},
#'   \code{\link{TuneModelEvaluateXGBoost}}, \code{\link{EstimateBinaryPerformance}}
#'
#' @references
#' Chen, T., & Guestrin, C. (2016). XGBoost: A scalable tree boosting system. Proceedings
#' of the 22nd ACM SIGKDD, 785-794.
#' \url{https://doi.org/10.1145/2939672.2939785}
#'
#' Friedman, J. H. (2001). Greedy function approximation: A gradient boosting machine. The
#' Annals of Statistics, 29(5), 1189-1232.
#' \url{https://doi.org/10.1214/aos/1013203451}
#'
#' @examples
#' \dontrun{
#' predictionData <- PredictModelXGBoost(
#'   data = xgbHoldoutSet,
#'   model = fittedModel,
#'   positive = "Sim",
#'   negative = "Nao",
#'   probClassThreshold = 0.05
#' )
#' }
#'
#' @importFrom tibble tibble
#'
#' @export
PredictModelXGBoost <- function(
    data,
    model,
    positive = "Sim",
    negative = "Nao",
    probClassThreshold = 0.5
){
  
  ## Predicao probabilistica
  # Executa predicao probabilistica
  predPositive <- predict(model, data, type = "prob")
  
  # Garante vetor numerico
  predPositive <- as.double(predPositive)
  
  ## Montagem das probabilidades e da classe
  # Organiza probabilidades e classe predita
  predictionData <- tibble::tibble(
    .pred_positive = predPositive,
    .pred_negative = 1 - predPositive,
    .pred_class = ifelse(
      test = (.pred_positive >= probClassThreshold),
      yes = positive,
      no = negative
    ) |>
      factor(
        levels = c(
          positive, negative
        )
      )
  )
  
  ## Retorno da predicao
  # Retorna predicao padronizada
  return(predictionData)
}
####
## Fim
#
