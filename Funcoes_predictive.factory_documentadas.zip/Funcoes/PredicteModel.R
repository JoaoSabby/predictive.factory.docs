#' @title Executar a Predição do Modelo sobre a Base de Inferência
#'
#' @usage
#' PredictModel(fileModel, predictionData)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Carrega o modelo XGBoost do arquivo `.zip` gerado no ajuste, aplica-o à base de
#' inferência e retorna, para cada cliente, a classe predita e a probabilidade da classe
#' positiva junto com os dados de entrada.
#'
#' @details
#' #. extrai o JSON do modelo para `tempdir()` e carrega-o com `xgb.load.raw()`;
#' #. constrói a `xgb.DMatrix` com todas as colunas de `predictionData`;
#' #. aplica `PredictModelXGBoost()` com ponto de corte `0.5`;
#' #. acrescenta `TARGET_PRED` e `TARGET_PROB` às colunas de `predictionData` e posiciona
#'    `SEQUENCIA_CLIENTE` em primeiro lugar.
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Colunas da Matriz de Predição:**
#' A matriz é construída com todas as colunas de `predictionData`, inclusive as colunas de
#' contexto, como `SEQUENCIA_CLIENTE`. O modelo é ajustado sem essas colunas, que são
#' removidas por `ConsolidateHistoricalData()`. O XGBoost valida os nomes das features e
#' pode rejeitar a predição quando os conjuntos diferem.
#' :::
#'
#' A função está definida no arquivo `PredicteModel.R`, cujo nome difere do nome da
#' função.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(PredictModel, prefix = "##", code = FALSE,
#'   narrow = TRUE), "PredictModel_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(PredictModel, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "PredictModel_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - extrai o arquivo JSON do modelo em `tempdir()`, sobrescrevendo arquivo existente.
#'
#' @param fileModel Caminho do arquivo `.zip` com o modelo em JSON, retornado por
#'   `FitModelXGBoost()`.
#' @param predictionData Tibble preprocessada por `PrepareDataModel()`, com
#'   `SEQUENCIA_CLIENTE` e as features.
#'
#' @returns Tibble com `SEQUENCIA_CLIENTE`, `TARGET_PRED` (fator com níveis `"Sim"` e
#'   `"Nao"`), `TARGET_PROB` (probabilidade de `"Sim"`) e as demais colunas de
#'   `predictionData`.
#'
#' @family Avaliação do Modelo
#'
#' @seealso \code{\link{PredictModelXGBoost}}, \code{\link{FitModelXGBoost}},
#'   \code{\link{BuildPipelinePredicting}}, \code{\link[xgboost]{xgb.load.raw}}
#'
#' @references
#' XGBoost Documentation: Introduction to Model IO.
#' \url{https://xgboost.readthedocs.io/en/stable/tutorials/saving_model.html}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: modelo ajustado e base de inferência preprocessada
#' predictionResults <- PredictModel(
#'   fileModel = fileModel,
#'   predictionData = predictionData
#' )
#' }
#'
#' @importFrom xgboost xgb.load.raw xgb.DMatrix
#' @importFrom zip unzip
#'
#' @export
PredictModel <- function(
    fileModel,
    predictionData
){
  
  ## Carga do modelo
  # Json file model
  jsonFileModel <- zip::unzip(
    zipfile = fileModel,
    exdir = tempdir(),
    overwrite = TRUE
  )
  
  # busca binario do modelo
  dataRaw <- readBin(
    con = jsonFileModel$path[1L],
    what = "raw",
    n = file.info(jsonFileModel$path[1L])$size
  )
  
  # Carrega modelo
  fittedModel <- xgb.load.raw(
    buffer = dataRaw
  )
  
  ## Construcao da matriz de predicao
  # Gera matrix xgboost predictiion set
  xgbPredictionData <- xgb.DMatrix(
    data = predictionData,
    silent = TRUE,
    nthread = opt("predy_threads_limit")
  )
  
  ## Predicao e montagem do resultado
  # Executa predicao
  predictingResults <- PredictModelXGBoost(
    data = xgbPredictionData,
    model = fittedModel,
    positive = "Sim",
    negative = "Nao"
  ) |> 
    transmute(
      TARGET_PRED = .pred_class,
      TARGET_PROB = .pred_positive
    ) |> 
    bind_cols(predictionData) |> 
    select(SEQUENCIA_CLIENTE, everything())
  
  ## Retorno das predicoes
  # Retorna predicoes
  return(predictingResults)
}
####
##
# 