#' @title Preprocessar os Dados para o Modelo Preditivo
#'
#' @usage
#' PrepareDataModel(dataset)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Prepara uma base tabular para modelagem ou predição: imputa valores ausentes numéricos
#' com zero, codifica variáveis de texto em indicadoras (one-hot), converte colunas
#' binárias em lógicas e remove features constantes, com moda excessivamente frequente ou
#' altamente correlacionadas.
#'
#' @details
#' O número de threads é \eqn{\min(12, \text{predy\_threads\_limit})} e configura
#' `collapse`, `data.table` e `sbyops`. As etapas são:
#'
#' #. colunas inteiras: ausentes substituídos por `0L`;
#' #. colunas `double` que não são datas: ausentes substituídos por `0` e valores
#'    arredondados a seis casas;
#' #. colunas de texto: convertidas em indicadoras por `mltools::one_hot()`, com remoção
#'    da coluna original;
#' #. colunas cujos valores pertencem a \eqn{\{0, 1\}}: convertidas para lógicas;
#' #. remoção de colunas constantes por `sbyops::sby_select_non_constant()`, preservando
#'    `TARGET` e as colunas de contexto (`predy_columns_key_context`);
#' #. remoção de colunas cuja moda ocorre em proporção igual ou superior a
#'    `predy_features_modal_frequency_threshold`;
#' #. remoção de colunas com correlação igual ou superior a
#'    `predy_features_correlation_threshold`.
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Exclusão por Posição:**
#' Nas duas últimas etapas, a exclusão usa `-!!opt("predy_threads_limit")`. Como a opção é
#' numérica, o `tidyselect` interpreta o valor como posição de coluna: é preservada a
#' coluna nessa posição, e não as colunas de contexto.
#' :::
#'
#' ::: {.callout-important}
#' <i class="fa-solid fa-circle-exclamation"></i> **Treino e Predição:**
#' A codificação one-hot e as três seleções de features são recalculadas a cada chamada,
#' com base nos dados recebidos. Aplicada separadamente à base de treino e à base de
#' predição, a função pode produzir conjuntos de colunas diferentes.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(PrepareDataModel, prefix = "##", code = FALSE,
#'   narrow = TRUE), "PrepareDataModel_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(PrepareDataModel, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "PrepareDataModel_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - altera a configuração global de threads de `collapse` e `data.table`;
#' - altera a configuração de `sbyops` (limiares de uso de Fortran e BLAS e número de
#'   threads);
#' - escreve no console as etapas de progresso.
#'
#' @param dataset Data frame ou tibble com a coluna `TARGET` (quando houver), as colunas
#'   de contexto e as features.
#'
#' @returns Tibble com as features preprocessadas, `TARGET` e as colunas de contexto que
#'   não forem removidas pelas etapas de moda e correlação.
#'
#' @family Modelagem Preditiva
#'
#' @seealso \code{\link{ConsolidateHistoricalData}}, \code{\link{BuildPipelineModeling}},
#'   \code{\link{BuildPipelinePredicting}}, \code{\link[mltools]{one_hot}}
#'
#' @references
#' Kuhn, M., & Johnson, K. (2019). Feature Engineering and Selection: A Practical Approach
#' for Predictive Models. Chapman and Hall/CRC.
#' \url{https://www.feat.engineering/}
#'
#' Guyon, I., & Elisseeff, A. (2003). An introduction to variable and feature selection.
#' Journal of Machine Learning Research, 3, 1157-1182.
#' \url{https://www.jmlr.org/papers/v3/guyon03a.html}
#'
#' collapse: Advanced and Fast Data Transformation.
#' \url{https://sebkrantz.github.io/collapse/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: opções definidas por DefineOptionsSetup()
#' dataModel <- PrepareDataModel(dataset = historicalData)
#' }
#'
#' @importFrom mltools one_hot
#' @importFrom collapse set_collapse fmutate
#'
#' @export
PrepareDataModel <- function(dataset){
  
  ## Configuracao de threads
  cli_progress_step("Preprocessamento dos dados para o modelo")
  
  nThreads <- min(12L, opt("predy_threads_limit"))
  
  collapse::set_collapse(nthreads = nThreads)
  data.table::setDTthreads(nThreads)
  sbyops::sby_config(
    sby_config_start_fortran = 10000L,
    sby_config_start_blas = 100000L,
    sby_config_max_threads = nThreads
  )
  
  ## Imputacao de ausentes numericos
  # Ajuses dos data types numericos
  cli_progress_step("Preenchimento de missing values com zeros")
  dataModel <- data.table::as.data.table(dataset) |> 
    collapse::fmutate(across(tidyselect:::where(is.integer), fcoalesce, 0L)) |> 
    collapse::fmutate(across(
      .cols = where(function(x) (!is.Date(x) && is.double(x))),
      .fns = function(x){round(data.table::fcoalesce(x, 0), digits = 6L)}
    )) 
  
  ## Codificacao one-hot e colunas binarias
  # Busca colunas para conversao em dummies
  colDummies <- colnames(select(dataModel, where(~ is.character(.x))))
  
  # Se possui colunas para conversao em dummies
  if(length(colDummies) > 0L){
    
    # Converte para dummies
    cli_progress_step("Criação de features dummies One Hot Encode")
    dataModel <- mltools::one_hot(
      dt = dataModel, 
      cols = colDummies, 
      dropCols = TRUE
    )
  }
  
  # Busca colunas binarias
  cli_progress_step("Tratamento de features binárias")
  
  # Busca colunas binarias
  cols_bin <- colnames(dataModel)[
    vapply(
      X = dataModel, 
      FUN = \(x){collapse::allv((collapse::fmatch(x, c(0L, 1L), overid = 2L, nomatch = 0L) > 0L), value = TRUE)}, 
      FUN.VALUE = logical(1L),
      USE.NAMES = TRUE
    )
  ]
  
  # Se possui colunas binarias
  if(length(cols_bin) > 0){
    
    # Ajusta o data type para logical
    dataModel <- dataModel |> 
      collapse::fmutate(across(cols_bin, as.logical))
  }

  ## Remocao de features constantes
  # Reomove colunas com conteudo constante
  cli_progress_step("Remoção de features com conteúdo constante")
  dataModel <- sbyops::sby_select_non_constant(
    .data = dataModel,
    -any_of("TARGET"), -!!opt("predy_columns_key_context")
  )
  
  ## Remocao por moda e correlacao
  # Reomove colunas com modal excessivamente frequente
  thresholdFrequency <- opt("predy_features_modal_frequency_threshold")
  cli_progress_step("Remoção de features com moda frequente em {thresholdFrequency * 100}% dos registros")
  dataModel <- sbyops::sby_select_modal_frequency(
    .data = dataModel,
    -any_of("TARGET"), -!!opt("predy_threads_limit"),
    threshold = thresholdFrequency
  )
  
  # Reomove colunas altamente correlacionadas 
  cli_progress_step("Remoção de features com correlação igual ou superior a {opt('predy_features_correlation_threshold', default = 0.99) * 100}%")
  dataModel <- sbyops::sby_select_correlation(
    .data = dataModel,
    -any_of("TARGET"), -!!opt("predy_threads_limit"),
    threshold = opt("predy_features_correlation_threshold")
  ) 
  
  ## Conversao para tibble
  # Converte para tibble 
  dataModel <- as_tibble(dataModel)
  
  cli_progress_done()
  
  # Prepara dados para uso no modelo preditivo
  return(dataModel)
}
####
## Fim
# 
