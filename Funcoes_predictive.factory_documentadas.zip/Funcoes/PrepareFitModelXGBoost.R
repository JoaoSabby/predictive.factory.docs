#' @title Preparar as Matrizes Esparsas de Ajuste do XGBoost
#'
#' @usage
#' PrepareFitModelXGBoost(fitSet, nThreads)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Converte a base de ajuste em matriz esparsa no formato coluna comprimida (CSC), sem
#' criar matriz densa intermediária, e cria as matrizes `xgb.DMatrix` de treino e de
#' validação com divisão estratificada e determinística.
#'
#' @details
#' #. o alvo é codificado como `1` para `"Sim"` e `0` para os demais valores;
#' #. para cada classe, as primeiras \eqn{\lfloor 0{,}8 \, n_c \rfloor} linhas, na ordem
#'    original, vão para treino; o restante vai para validação;
#' #. a matriz `dgCMatrix` é montada a partir dos vetores CSC:
#' - \eqn{i}: índices de linha dos valores não nulos, em base zero;
#' - \eqn{p}: ponteiros de início de cada coluna, \eqn{p_0 = 0} e \eqn{p_j = p_{j-1} +
#'   nnz_j};
#' - \eqn{x}: valores não nulos como `double`.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **Valores Ausentes e Tipos:**
#' A seleção `which(featureVector != 0L)` descarta valores `NA`, que passam a ser zeros
#' estruturais da matriz esparsa; o argumento `missing = NA_real_` não os recupera. As
#' features devem ser numéricas ou lógicas. A divisão depende da ordem das linhas e não
#' usa sorteio. A função não é chamada por nenhum pipeline do projeto.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(PrepareFitModelXGBoost, prefix = "##", code = FALSE,
#'   narrow = TRUE), "PrepareFitModelXGBoost_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(PrepareFitModelXGBoost, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "PrepareFitModelXGBoost_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Complexidade Computacional:
#' A montagem é linear no número de linhas e colunas, \eqn{O(n \cdot m)}, e a memória da
#' matriz é proporcional ao número de valores não nulos, \eqn{O(nnz)}.
#'
#' @param fitSet Data frame com `TARGET` e as features numéricas ou lógicas, já
#'   codificadas.
#' @param nThreads Inteiro com o número de threads de construção das matrizes.
#'
#' @returns Lista com `train` e `valid`, objetos `xgb.DMatrix` com rótulos.
#'
#' @family Modelagem Preditiva
#'
#' @seealso \code{\link{FitModelXGBoost}}, \code{\link[Matrix]{dgCMatrix-class}}
#'
#' @references
#' Duff, I. S., Grimes, R. G., & Lewis, J. G. (1989). Sparse matrix test problems. ACM
#' Transactions on Mathematical Software, 15(1), 1-14.
#' \url{https://doi.org/10.1145/62038.62043}
#'
#' Matrix: Sparse and Dense Matrix Classes and Methods.
#' \url{https://cran.r-project.org/package=Matrix}
#'
#' @examples
#' \dontrun{
#' fitXGBoostSet <- PrepareFitModelXGBoost(fitSet = trainingSet, nThreads = 4L)
#' }
#'
#' @importFrom xgboost xgb.DMatrix
#'
#' @export
PrepareFitModelXGBoost <- function(fitSet, nThreads){
  
  ## Codificacao do alvo e das features
  # Codifica o alvo conforme o contrato binario do projeto
  fitTarget <- as.integer(fitSet$TARGET == "Sim")
  
  # Separa as features ja numericas e previamente dummificadas
  fitFeatures <- fitSet[colnames(fitSet) != "TARGET"]
  
  # Preserva a ordem e os nomes das features usadas pelo modelo
  featureNames <- colnames(fitFeatures)
  
  # Define as dimensoes da matriz sem criar objeto denso intermediario
  rowCount <- nrow(fitFeatures)
  colCount <- length(featureNames)
  
  ## Divisao estratificada deterministica
  # Cria indices estratificados e deterministicos por classe
  targetIndexSet <- seq_len(rowCount) |>
    split(f = fitSet$TARGET)
  
  # Seleciona aproximadamente 80 por cento de cada classe para treino
  trainIndex <- targetIndexSet |>
    lapply(
      FUN = function(indexSet){
        indexSet[
          seq_len(
            floor(length(indexSet) * 0.8)
          )
        ]
      }
    ) |>
    unlist(use.names = FALSE) |>
    sort()
  
  # Usa o complemento da amostra de treino como validacao
  validIndex <- setdiff(
    x = seq_len(rowCount),
    y = trainIndex
  )
  
  ## Montagem da matriz esparsa CSC
  # Identifica as posicoes nao nulas por coluna
  nonZeroRowSet <- fitFeatures |>
    lapply(
      FUN = function(featureVector){
        which(featureVector != 0L)
      }
    )
  
  # Extrai somente os valores nao nulos que serao armazenados
  nonZeroValueSet <- Map(
    f = `[`,
    fitFeatures,
    nonZeroRowSet
  )
  
  # Calcula os ponteiros de coluna do formato esparso comprimido
  nonZeroCount <- lengths(
    x = nonZeroRowSet,
    use.names = FALSE
  )
  
  # ponteiros que indicam onde cada coluna começa e termina em i e x
  pVector <- as.integer(
    c(0L, cumsum(nonZeroCount))
  )
  
  # Converte os indices de linha para base zero exigida pela dgCMatrix
  iVector <- as.integer(
    unlist(
      x = nonZeroRowSet,
      use.names = FALSE
    ) - 1L
  )
  
  # Converte os valores nao nulos para double
  xVector <- as.double(
    unlist(
      x = nonZeroValueSet,
      use.names = FALSE
    )
  )
  
  # Monta a matriz esparsa diretamente no formato CSC
  fitFeatureMatrix <- new(
    Class = "dgCMatrix",
    i = iVector,
    p = pVector,
    x = xVector,
    Dim = as.integer(c(rowCount, colCount)),
    Dimnames = list(NULL, featureNames)
  )
  
  ## Criacao das matrizes XGBoost
  # Cria o conjunto de treino no formato nativo do XGBoost
  fitXGBoostSetTrain <- xgb.DMatrix(
    data = fitFeatureMatrix[trainIndex, , drop = FALSE],
    label = fitTarget[trainIndex],
    missing = NA_real_,
    nthread = nThreads
  )
  
  # Cria o conjunto de validacao no formato nativo do XGBoost
  fitXGBoostSetValid <- xgb.DMatrix(
    data = fitFeatureMatrix[validIndex, , drop = FALSE],
    label = fitTarget[validIndex],
    missing = NA_real_,
    nthread = nThreads
  )
  
  # Retorna somente os dois objetos exigidos pela etapa de ajuste
  fitXGBoostSet <- list(
    train = fitXGBoostSetTrain,
    valid = fitXGBoostSetValid
  )
  
  ## Retorno das matrizes
  # Retorna dados de treino e validacao do XGBoost
  return(fitXGBoostSet)
}
####
## Fim
# 
