#' @title Preparar as Matrizes Quantizadas de um Fold do XGBoost
#'
#' @usage
#' PrepareTuneModelFoldXGBoost(
#'   tuneDataFold,
#'   tuneData,
#'   labelData,
#'   targetData,
#'   positive,
#'   negative,
#'   features,
#'   fitThreads
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Divide um fold em treino, validação e teste e cria as matrizes `xgb.QuantileDMatrix`
#' correspondentes, com as matrizes de validação e de teste quantizadas a partir da matriz
#' de treino.
#'
#' @details
#' A partição de análise do fold é dividida em 80% para treino e 20% para validação, de
#' forma estratificada e com semente `42`; a partição de avaliação é o teste externo. As
#' três matrizes usam `max_bin = 512`, `missing = NA` e os nomes de `features`. As
#' matrizes de validação e de teste usam `ref = dataTrain`, de modo que os limites dos
#' histogramas são definidos apenas pelos dados de treino. Não há balanceamento de
#' classes.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(PrepareTuneModelFoldXGBoost, prefix = "##", code = FALSE,
#'   narrow = TRUE), "PrepareTuneModelFoldXGBoost_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(PrepareTuneModelFoldXGBoost,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "PrepareTuneModelFoldXGBoost_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @param tuneDataFold Objeto `rsplit` de `vfold_cv()` sobre a base de índices, com as
#'   colunas `rowId` e `TARGET`.
#' @param tuneData Data frame completo com `TARGET` e as features.
#' @param labelData Vetor inteiro com o rótulo binário de cada linha (1 para a classe
#'   positiva).
#' @param targetData Fator com o alvo observado de cada linha.
#' @param positive Rótulo da classe positiva.
#' @param negative Rótulo da classe negativa.
#' @param features Vetor de caracteres com os nomes das features.
#' @param fitThreads Inteiro com o número de threads de construção das matrizes.
#'
#' @returns Lista invisível com `dataTrain`, `dataValid` e `dataTest` (objetos
#'   `xgb.QuantileDMatrix`), `targetTest` (fator com níveis `positive` e `negative`),
#'   `labelTest`, `positive`, `negative` e `features`.
#'
#' @family Otimização de Hiperparâmetros
#'
#' @seealso \code{\link{PrepareTuneModelFoldsXGBoost}}, \code{\link[rsample]{analysis}},
#'   \code{\link[xgboost]{xgb.QuantileDMatrix}}
#'
#' @references
#' Chen, T., & Guestrin, C. (2016). XGBoost: A scalable tree boosting system. Proceedings
#' of the 22nd ACM SIGKDD, 785-794. Seção 3.3: Weighted Quantile Sketch.
#' \url{https://doi.org/10.1145/2939672.2939785}
#'
#' @examples
#' \dontrun{
#' tuneFold <- PrepareTuneModelFoldXGBoost(
#'   tuneDataFold = tuneDataFolds$splits[[1]],
#'   tuneData = tuneSet,
#'   labelData = labelData,
#'   targetData = tuneSet$TARGET,
#'   positive = "Sim",
#'   negative = "Nao",
#'   features = setdiff(colnames(tuneSet), "TARGET"),
#'   fitThreads = 4L
#' )
#' }
#'
#' @importFrom rsample analysis assessment initial_split training testing
#' @importFrom xgboost xgb.QuantileDMatrix
#'
#' @export
PrepareTuneModelFoldXGBoost <- function(
    tuneDataFold,
    tuneData,
    labelData,
    targetData,
    positive,
    negative,
    features,
    fitThreads
){
  
  ## Divisao em treino, validacao e teste
  # Separa dados de modelagem e teste externo
  modelIndexData <- analysis(tuneDataFold)
  testIndexData <- assessment(tuneDataFold)
  
  # Divide dados de modelagem em treino e validacao
  set.seed(42L)
  modelSplit <- initial_split(
    data = modelIndexData,
    prop = 0.8,
    strata = TARGET
  )
  
  # Recupera indices de treino e validacao
  trainIndexData <- training(modelSplit)
  validIndexData <- testing(modelSplit)
  
  # Recupera indices originais
  trainRows <- trainIndexData$rowId
  validRows <- validIndexData$rowId
  testRows <- testIndexData$rowId
  
  ## Separacao das matrizes e rotulos
  # Separa matrizes do fold
  matrixTrain <- tuneData[trainRows, , drop = FALSE]
  matrixValid <- tuneData[validRows, , drop = FALSE]
  matrixTest  <- tuneData[testRows, , drop = FALSE]
  matrixTrain$TARGET <- NULL
  matrixValid$TARGET <- NULL
  matrixTest$TARGET <- NULL
  
  # Separa labels do fold
  labelTrain <- labelData[trainRows]
  labelValid <- labelData[validRows]
  labelTest  <- labelData[testRows]
  
  # Separa alvo observado do teste externo
  targetTest <- factor(
    x = targetData[testRows],
    levels = c(
      positive, negative
    )
  )
  
  ## Criacao das matrizes quantizadas
  # Cria matriz quantizada de treino
  dataTrain <- xgb.QuantileDMatrix(
    data = matrixTrain,
    label = labelTrain,
    missing = NA,
    feature_names = features,
    max_bin = 512L,
    nthread = fitThreads
  )

  # Cria matriz quantizada de validacao
  dataValid <- xgb.QuantileDMatrix(
    data = matrixValid,
    label = labelValid,
    missing = NA,
    feature_names = features,
    nthread = fitThreads,
    max_bin = 512L,
    ref = dataTrain
  )
  
  # Cria matriz quantizada de teste
  dataTest <- xgb.QuantileDMatrix(
    data = matrixTest,
    label = labelTest,
    missing = NA,
    feature_names = features,
    nthread = fitThreads,
    max_bin = 512L,
    ref = dataTrain
  )
  
  ## Retorno do fold preparado
  # Organiza fold preparado
  tuneFold <- list(
    dataTrain = dataTrain,
    dataValid = dataValid,
    dataTest = dataTest,
    targetTest = targetTest,
    labelTest = labelTest,
    positive = positive,
    negative = negative,
    features = features
  )

  # Retorna fold preparado
  return(invisible(tuneFold))
}
####
## Fim
#
