#' @title Preparar Folds Nativos do XGBoost em Memória
#'
#' @usage
#' PrepareTuneModelFoldsXGBoost(tuneData, nFolds = 10L, fitThreads = 1L)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Cria folds estratificados de validação cruzada e, para cada fold, matrizes quantizadas
#' `xgb.QuantileDMatrix` de treino, validação e teste, mantidas em memória, junto com os
#' metadados de classes e features.
#'
#' @details
#' O primeiro nível de `TARGET` é a classe positiva. A execução é interrompida quando a
#' classe positiva não tem observações. Os folds são criados por `rsample::vfold_cv()`
#' estratificado por `TARGET`, com semente `42`, sobre uma base de índices, e cada fold é
#' preparado por `PrepareTuneModelFoldXGBoost()`. A razão entre classes é:
#' \deqn{r = \frac{n_{neg}}{n_{pos}}}
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **Uso no Projeto:**
#' A função não é chamada pelo pipeline atual. O tuning usa
#' `TuneModelResampleFoldsXGBoost()`, que grava as matrizes em disco e aplica
#' balanceamento de classes.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(PrepareTuneModelFoldsXGBoost, prefix = "##", code = FALSE,
#'   narrow = TRUE), "PrepareTuneModelFoldsXGBoost_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(PrepareTuneModelFoldsXGBoost,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "PrepareTuneModelFoldsXGBoost_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - registra o tempo de preparação com `tic()` e `Toc()`.
#'
#' @param tuneData Data frame com `TARGET` (fator de dois níveis) e as features numéricas.
#' @param nFolds Inteiro com o número de folds (padrão: `10L`).
#' @param fitThreads Inteiro com o número de threads de construção das matrizes (padrão:
#'   `1L`).
#'
#' @returns Lista invisível com `tuneModelFolds` (lista de folds preparados), `positive`,
#'   `negative`, `features`, `nFeatures` e `classRatio`.
#'
#' @family Otimização de Hiperparâmetros
#'
#' @seealso \code{\link{PrepareTuneModelFoldXGBoost}},
#'   \code{\link{TuneModelResampleFoldsXGBoost}}, \code{\link[rsample]{vfold_cv}}
#'
#' @references
#' Kohavi, R. (1995). A study of cross-validation and bootstrap for accuracy estimation
#' and model selection. Proceedings of the 14th IJCAI, 1137-1143.
#'
#' XGBoost Documentation: QuantileDMatrix.
#' \url{https://xgboost.readthedocs.io/en/stable/python/python_api.html}
#'
#' @examples
#' \dontrun{
#' preparedTuneModel <- PrepareTuneModelFoldsXGBoost(
#'   tuneData = tuneSet,
#'   nFolds = 5L,
#'   fitThreads = 4L
#' )
#' }
#'
#' @importFrom rsample vfold_cv
#'
#' @export
PrepareTuneModelFoldsXGBoost <- function(
    tuneData,
    nFolds = 10L,
    fitThreads = 1L
){
  
  ## Definicao do alvo e das classes
  # Define alvo e classes
  targetData <- tuneData$TARGET
  positive <- levels(targetData)[1L]
  negative <- levels(targetData)[2L]
  
  # Cria label binario
  labelData <- as.integer(targetData == positive)

  # Valida presenca da classe positiva
  if(sum(labelData == 1L) == 0L){
    stop("A classe positiva não possui observações!")
  }

  features <- setdiff(colnames(tuneData), "TARGET") 

  ## Metadados das features e das classes
  # Quantidade de features
  nFeatures <- length(features)
    
  # Calcula razao entre classes
  negativeCount <- sum(labelData == 0L)
  positiveCount <- sum(labelData == 1L)
  classRatio <- (negativeCount / positiveCount)
  
  
  ## Criacao dos folds estratificados
  # Cria base de indices
  foldIndexData <- tibble(
    rowId = seq_len(nrow(tuneData)),
    TARGET = targetData
  )
  
  # Cria folds externos
  set.seed(42L)
  tuneDataFolds <- vfold_cv(
    data = foldIndexData,
    v = nFolds,
    strata = TARGET
  )

  # Liberar o MKL para usar os recursos da máquina (ex: 16 núcleos)
  tic()
  ## Preparacao das matrizes por fold
  # Prepara folds nativos
  tuneModelFolds <- lapply(
    X = tuneDataFolds$splits,
    FUN = PrepareTuneModelFoldXGBoost,
    tuneData = tuneData,
    labelData = labelData,
    targetData = targetData,
    positive = positive,
    negative = negative,
    features = features,
    fitThreads = fitThreads
  )
  Toc()
  
  ## Retorno do objeto preparado
  # Organiza objeto preparado
  preparedTuneModel <- list(
    tuneModelFolds = tuneModelFolds,
    positive = positive,
    negative = negative,
    features = features,
    nFeatures = nFeatures,
    classRatio = classRatio
  )
  
  # Retorna objeto preparado
  return(invisible(preparedTuneModel))
}
####
## Fim
#
