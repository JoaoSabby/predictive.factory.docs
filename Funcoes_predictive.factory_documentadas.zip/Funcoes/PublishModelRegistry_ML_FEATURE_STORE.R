#' @title Publicar a Feature Store In-Memory na Tabela Persistente
#'
#' @usage
#' PublishModelRegistry_ML_FEATURE_STORE(
#'   dataFeature,
#'   janelaAgregacao,
#'   janelaHistorico,
#'   dataAgregacaoInicial,
#'   dataAgregacaoFinal,
#'   dataHistoricaInicial,
#'   dataHistoricaFinal
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Acrescenta os registros da feature store in-memory à tabela persistente
#' `ML_FEATURE_STORE` e, em seguida, remove da memória do Oracle as tabelas com prefixo
#' `IM_ML_`.
#'
#' @details
#' A cópia é feita por `DbAppendFromTable()`, que cria a tabela de destino quando ela não
#' existe ou acrescenta os registros, com índice nas colunas `SEQUENCIA_CLIENTE`,
#' `DATA_REFERENCIA`, `JANELA_AGREGACAO` e `JANELA_HISTORICO`.
#'
#' ::: {.callout-important}
#' <i class="fa-solid fa-circle-exclamation"></i> **Implementação Incompleta:**
#' O nome da tabela de origem é montado com a variável `sufixo`, que não é argumento da
#' função. Sem um objeto `sufixo` no ambiente de chamada, a execução termina com erro.
#' Nenhum dos sete argumentos é usado no corpo da função, e a função não é chamada por
#' nenhum pipeline do projeto.
#' :::
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Limpeza Ampla:**
#' `DbCleanTablesMemory(prefixoTabelas = "IM_ML_")` remove todas as tabelas in-memory com
#' prefixo `IM_ML_`, inclusive feature groups e feature stores de outras execuções.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(PublishModelRegistry_ML_FEATURE_STORE,
#'   prefix = "##", code = FALSE, narrow = TRUE),
#'   "PublishModelRegistry_ML_FEATURE_STORE_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(PublishModelRegistry_ML_FEATURE_STORE,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "PublishModelRegistry_ML_FEATURE_STORE_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - cria ou acrescenta registros na tabela `ML_FEATURE_STORE`;
#' - remove do Oracle as tabelas com prefixo `IM_ML_`.
#'
#' @section Linhagem de Dados:
#' +---------------------+---------------------------------------------------------------+
#' | Elemento            | Valor                                                         |
#' +=====================+===============================================================+
#' | Tabelas de origem   | `IM_ML_FEATURE_STORE_{SUFIXO}`                                |
#' +---------------------+---------------------------------------------------------------+
#' | Filtro de período   | nenhum                                                        |
#' +---------------------+---------------------------------------------------------------+
#' | Chave de junção     | nenhuma; índice em `SEQUENCIA_CLIENTE`, `DATA_REFERENCIA`,    |
#' |                     | `JANELA_AGREGACAO`, `JANELA_HISTORICO`                        |
#' +---------------------+---------------------------------------------------------------+
#' | Tabelas temporárias | nenhuma                                                       |
#' +---------------------+---------------------------------------------------------------+
#' | Tabela de saída     | `ML_FEATURE_STORE`                                            |
#' +---------------------+---------------------------------------------------------------+
#'
#' @param dataFeature Data de referência dos preditores. Não utilizada no corpo da função.
#' @param janelaAgregacao Inteiro com a janela de agregação. Não utilizado no corpo da
#'   função.
#' @param janelaHistorico Inteiro com a janela histórica. Não utilizado no corpo da
#'   função.
#' @param dataAgregacaoInicial Data inicial da janela de agregação. Não utilizada no corpo
#'   da função.
#' @param dataAgregacaoFinal Data final da janela de agregação. Não utilizada no corpo da
#'   função.
#' @param dataHistoricaInicial Data inicial da janela histórica. Não utilizada no corpo da
#'   função.
#' @param dataHistoricaFinal Data final da janela histórica. Não utilizada no corpo da
#'   função.
#'
#' @returns `TRUE` invisível.
#'
#' @family Publicação do Modelo
#'
#' @seealso \code{\link{Generate_IM_ML_FEATURE_STORE}}, \code{\link{CheckFeatureStore}},
#'   \code{\link{BuildPipelinePublishing}}
#'
#' @references
#' Oracle Database In-Memory Guide.
#' \url{https://docs.oracle.com/en/database/oracle/oracle-database/19/inmem/}
#'
#' @examples
#' \dontrun{
#' # Requer o objeto sufixo no ambiente de chamada
#' sufixo <- "TREINO"
#' PublishModelRegistry_ML_FEATURE_STORE(
#'   dataFeature = "2025-10-01",
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L,
#'   dataAgregacaoInicial = "2025-05-01",
#'   dataAgregacaoFinal = "2025-10-31",
#'   dataHistoricaInicial = "2022-11-01",
#'   dataHistoricaFinal = "2025-10-31"
#' )
#' }
#'
#' @export
PublishModelRegistry_ML_FEATURE_STORE <- function(
    dataFeature,
    janelaAgregacao,
    janelaHistorico,
    dataAgregacaoInicial,
    dataAgregacaoFinal,
    dataHistoricaInicial,
    dataHistoricaFinal
){
  
  ## Copia para a tabela persistente
  # Cria tabela ou adiciona os registros
  DbAppendFromTable(
    nomeTabelaOrigem = str_c("IM_ML_FEATURE_STORE_", str_to_upper(sufixo)),
    nomeTabelaDestino = "ML_FEATURE_STORE",
    camposIndice = c("SEQUENCIA_CLIENTE", "DATA_REFERENCIA", "JANELA_AGREGACAO", "JANELA_HISTORICO")
  )
  
  ## Limpeza das tabelas in-memory
  # Limpa memoria
  DbCleanTablesMemory(
    prefixoTabelas = "IM_ML_"
  )
  
  ## Retorno invisivel
  # Retorna sucesso
  return(invisible(TRUE))
}
####
## Fim
#
