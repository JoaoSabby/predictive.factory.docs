#' @title Renderizar Cabeçalhos roxygen2 em Páginas Quarto
#'
#' @usage
#' RenderRoxygenToQuarto(
#'   listFunctions = list.files("Funcoes", pattern = "\\.R$", full.names = TRUE),
#'   pathOutputQmd = file.path("docs", "help_functions")
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Lê o cabeçalho roxygen2 de cada arquivo de função informado, converte o conteúdo para
#' Markdown do Quarto e grava uma página `.qmd` por função, com o nome da função definida
#' no arquivo, além de um índice `index.qmd` agrupado por família. A função também audita
#' os cabeçalhos e emite avisos quando encontra divergências entre a documentação e o
#' código.
#'
#' @details
#' O projeto não é estruturado como pacote R. Por esse motivo, a função não utiliza
#' `roxygen2::roxygenise()` nem gera arquivos `.Rd`. A leitura de cada arquivo é feita por
#' `roxygen2::parse_file()` com `env = NULL`, modo em que apenas os comentários `#'` são
#' interpretados e nenhum código é avaliado.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-shield-halved"></i> **Execução Segura:**
#' Nenhuma função documentada é carregada ou executada. O nome e os argumentos de cada
#' função são obtidos por `parse()`, que apenas constrói a árvore sintática do arquivo.
#' :::
#'
#' O processamento segue as etapas:
#'
#' #. leitura da primeira atribuição de primeiro nível de cada arquivo, que define o nome
#'    da página; quando não há atribuição, é usado o nome do arquivo;
#' #. leitura dos blocos roxygen2 e das famílias declaradas em `family`;
#' #. auditoria e conversão do primeiro bloco de cada arquivo em página `.qmd`;
#' #. gravação do índice `index.qmd`, com uma tabela por família.
#'
#' Cada página começa com um cabeçalho YAML, em que `title` é o nome da função e
#' `subtitle` é a tag `title` do roxygen2. As tags são mapeadas para as seções:
#'
#' +-----------------------+----------------------------------------------------+
#' | Tag roxygen2          | Seção da página                                    |
#' +=======================+====================================================+
#' | `usage`               | Uso, em bloco de código R                          |
#' +-----------------------+----------------------------------------------------+
#' | `description`         | Descrição                                          |
#' +-----------------------+----------------------------------------------------+
#' | `param`               | Parâmetros, em tabela                              |
#' +-----------------------+----------------------------------------------------+
#' | `details`             | Detalhes                                           |
#' +-----------------------+----------------------------------------------------+
#' | `section`             | Uma seção por ocorrência, com o título da tag      |
#' +-----------------------+----------------------------------------------------+
#' | `return` ou `returns` | Retorno                                            |
#' +-----------------------+----------------------------------------------------+
#' | `examples`            | Exemplos, em bloco de código R não executado       |
#' +-----------------------+----------------------------------------------------+
#' | `family`              | Família, com links para as demais funções do grupo |
#' +-----------------------+----------------------------------------------------+
#' | `seealso`             | Ver também, em lista com links                     |
#' +-----------------------+----------------------------------------------------+
#' | `references`          | Referências                                        |
#' +-----------------------+----------------------------------------------------+
#'
#' As marcações Rd são convertidas com tratamento de chaves aninhadas:
#'
#' +------------------------+---------------------------------------------------------+
#' | Marcação Rd            | Resultado no Quarto                                     |
#' +========================+=========================================================+
#' | `eqn`                  | Fórmula em linha, entre `$`                             |
#' +------------------------+---------------------------------------------------------+
#' | `deqn`                 | Fórmula em bloco, entre `$$`                            |
#' +------------------------+---------------------------------------------------------+
#' | `link` com pacote      | Referência no formato `pacote::funcao`                  |
#' +------------------------+---------------------------------------------------------+
#' | `link` sem pacote      | Link para a página `.qmd` da função, quando documentada |
#' +------------------------+---------------------------------------------------------+
#' | `code`                 | Código em linha                                         |
#' +------------------------+---------------------------------------------------------+
#' | `href` e `url`         | Link Markdown                                           |
#' +------------------------+---------------------------------------------------------+
#' | `emph` e `strong`      | Itálico e negrito                                       |
#' +------------------------+---------------------------------------------------------+
#' | `dontrun` e `donttest` | Removidas, preservando o código interno                 |
#' +------------------------+---------------------------------------------------------+
#'
#' O selo `lifecycle::badge("estagio")` escrito como código R inline vira imagem com link
#' para a descrição do estágio; o `.svg` é copiado do pacote lifecycle para a subpasta
#' `figures`. Sem o pacote, o selo vira o nome do estágio em negrito. Callouts, ícones,
#' tabelas em grade, listas `#.` e fórmulas `$...$` já estão em sintaxe do Quarto e são
#' copiados sem alteração.
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Seções Omitidas:**
#' As seções Fluxo Lógico e Funções Chamadas contêm código R inline, avaliado apenas na
#' geração de arquivos `.Rd`, e são omitidas das páginas. As tags `export`, `importFrom` e
#' `eval` também são ignoradas, pois dependem da compilação de um pacote.
#' :::
#'
#' ::: {.callout-important}
#' <i class="fa-solid fa-circle-exclamation"></i> **Interrupções e Codificação:**
#' A execução é interrompida com erro quando `listFunctions` está vazio, quando algum
#' arquivo não existe, quando um arquivo tem erro de sintaxe R ou quando uma marcação Rd
#' tem chave sem fechamento. A leitura e a gravação assumem UTF-8; em Linux, a sessão deve
#' usar um locale UTF-8.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(RenderRoxygenToQuarto, prefix = "##", code = FALSE,
#'   narrow = TRUE), "RenderRoxygenToQuarto_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(RenderRoxygenToQuarto, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "RenderRoxygenToQuarto_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Auditoria dos Cabeçalhos:
#' A função emite um aviso (`warning`), sem interromper o processamento, quando:
#'
#' - faltam as tags `title`, `usage`, `description`, `details`, `return` ou `examples`;
#' - alguma linha do bloco roxygen2 excede 90 caracteres;
#' - o nome do arquivo difere do nome da função definida;
#' - existe argumento da função sem `param` ou `param` sem argumento correspondente; a
#'   verificação é omitida quando o objeto definido não é uma `function`;
#' - o arquivo não contém cabeçalho roxygen2, caso em que nenhuma página é gerada.
#'
#' @section Efeitos Colaterais:
#' - grava uma página `.qmd` por função e o índice `index.qmd` em `pathOutputQmd`,
#'   sobrescrevendo arquivos existentes com o mesmo nome;
#' - cria `pathOutputQmd` e a subpasta `figures` quando não existem;
#' - copia os selos de ciclo de vida usados do pacote lifecycle para `figures`;
#' - emite mensagens (`message`) e avisos (`warning`) no console.
#'
#' Nenhum arquivo de `listFunctions` é alterado, e nenhuma conexão externa é aberta.
#'
#' @section Complexidade Computacional:
#' Sendo \eqn{n} o número de arquivos, \eqn{L_i} o número de caracteres do arquivo \eqn{i}
#' e \eqn{k_i} o número de marcações Rd do seu cabeçalho, o custo total é:
#' \deqn{T(n) = O\left(\sum_{i=1}^{n} L_i \, (1 + k_i)\right)}
#' O fator \eqn{k_i} decorre da conversão das marcações, que percorre o texto da tag
#' novamente a cada substituição.
#'
#' @param listFunctions Vetor de caracteres ou lista com os caminhos dos arquivos `.R` a
#'   documentar. Caminhos repetidos são considerados uma vez, e as páginas são geradas em
#'   ordem alfabética de caminho (padrão: todos os arquivos `.R` da pasta `Funcoes`).
#' @param pathOutputQmd Vetor de caracteres de comprimento 1 com a pasta de destino das
#'   páginas `.qmd`. A pasta é criada recursivamente quando não existe (padrão:
#'   `file.path("docs", "help_functions")`).
#'
#' @returns Retorna invisivelmente (`invisible`) um vetor de caracteres com os caminhos
#'   dos arquivos gerados: uma página `.qmd` por arquivo com cabeçalho roxygen2, seguida
#'   do índice `index.qmd`, que é sempre gerado. Os arquivos `.svg` copiados não fazem
#'   parte do vetor retornado.
#'
#' @family Documentação
#'
#' @seealso \code{\link[roxygen2]{parse_file}}, \code{\link[base]{parse}},
#'   \code{\link[lifecycle]{badge}}, \code{\link[tools]{file_path_sans_ext}}
#'
#' @references
#' Knuth, D. E. (1984). Literate Programming. The Computer Journal, 27(2), 97-111.
#' \url{https://doi.org/10.1093/comjnl/27.2.97}
#'
#' Wickham, H., Danenberg, P., Csárdi, G., & Eugster, M. roxygen2: In-Line Documentation
#' for R.
#' \url{https://roxygen2.r-lib.org/}
#'
#' R Core Team. Writing R Extensions: Writing R documentation files.
#' \url{https://cran.r-project.org/doc/manuals/r-release/R-exts.html}
#'
#' Quarto: Markdown Basics, Callout Blocks e Document Options.
#' \url{https://quarto.org/docs/authoring/markdown-basics.html}
#'
#' Pandoc User's Guide: Tables e Ordered Lists.
#' \url{https://pandoc.org/MANUAL.html}
#'
#' Henry, L., & Wickham, H. lifecycle: Lifecycle stages.
#' \url{https://lifecycle.r-lib.org/articles/stages.html}
#'
#' @examples
#' \dontrun{
#' # A partir da raiz do projeto predictive.factory
#' source(file.path("Funcoes", "RenderRoxygenToQuarto.R"))
#'
#' qmdFiles <- RenderRoxygenToQuarto(
#'   listFunctions = list.files("Funcoes", pattern = "\\.R$", full.names = TRUE),
#'   pathOutputQmd = file.path("docs", "help_functions")
#' )
#' }
#'
#' @importFrom roxygen2 parse_file
#'
#' @export
RenderRoxygenToQuarto <- function(
    listFunctions = list.files("Funcoes", pattern = "\\.R$", full.names = TRUE),
    pathOutputQmd = file.path("docs", "help_functions")
){

  ## Validacao dos arquivos de funcoes
  # Normaliza a lista recebida em vetor de caminhos unicos e ordenados
  listFunctions <- sort(unique(as.character(unlist(listFunctions))))

  # Interrompe quando nenhum arquivo foi informado
  if(length(listFunctions) == 0L){
    stop("Nenhum arquivo de função informado em listFunctions")
  }

  # Interrompe quando algum arquivo informado nao existe
  missingFiles <- listFunctions[!file.exists(listFunctions)]
  if(length(missingFiles) > 0L){
    stop("Arquivos de funções não encontrados: ", paste(missingFiles, collapse = ", "))
  }

  ## Preparacao da pasta de saida
  # Cria a pasta de saida quando ela ainda nao existe
  dir.create(pathOutputQmd, recursive = TRUE, showWarnings = FALSE)

  # Pasta dos selos de ciclo de vida e disponibilidade do pacote lifecycle
  figuresDir <- file.path(pathOutputQmd, "figures")
  hasLifecycle <- requireNamespace("lifecycle", quietly = TRUE)

  # Tags exigidas pelo padrao de documentacao do projeto
  requiredTags <- c("title", "usage", "description", "details", "return", "examples")

  # Largura maxima das linhas do bloco roxygen2
  maxLineWidth <- 90L

  ## Definicao das funcoes auxiliares de leitura, conversao e auditoria
  # Le a definicao de primeiro nivel do arquivo, sem executar o codigo. Retorna o
  # nome do objeto definido e, quando o objeto e uma funcao, os seus argumentos.
  GetDefinition <- function(functionFile){
    fileExpressions <- parse(functionFile, keep.source = FALSE, encoding = "UTF-8")
    for(fileExpression in fileExpressions){
      isAssignment <- is.call(fileExpression) &&
        as.character(fileExpression[[1L]]) %in% c("<-", "=") &&
        is.name(fileExpression[[2L]])
      if(isAssignment){
        objectValue <- fileExpression[[3L]]
        isFunction <- is.call(objectValue) &&
          identical(objectValue[[1L]], as.name("function"))
        return(list(
          name = as.character(fileExpression[[2L]]),
          isFunction = isFunction,
          arguments = if(isFunction) names(objectValue[[2L]]) else character(0L)
        ))
      }
    }
    return(NULL)
  }

  # Retorna os valores de todas as ocorrencias de uma ou mais tags
  GetTagValues <- function(tags, tagName){
    selectedTags <- Filter(function(tag) tag$tag %in% tagName, tags)
    lapply(selectedTags, function(tag) tag$val)
  }

  # Localiza a chave que fecha a chave aberta em openPos, respeitando aninhamento
  FindClosingBrace <- function(textChars, openPos){
    braceDepth <- 0L
    for(charPos in seq(openPos, length(textChars))){
      if(textChars[charPos] == "{") braceDepth <- braceDepth + 1L
      if(textChars[charPos] == "}") braceDepth <- braceDepth - 1L
      if(braceDepth == 0L) return(charPos)
    }
    stop("Chave sem fechamento em marcação Rd")
  }

  # Substitui todas as ocorrencias de uma macro Rd pelo texto do formatador.
  # O formatador recebe os argumentos entre chaves e a opcao entre colchetes.
  ReplaceRdMacro <- function(text, macroName, nArgs, Formatter){
    macroPattern <- paste0("\\\\", macroName, "(\\[[^]]*\\])?\\{")
    repeat{
      macroMatch <- regexpr(macroPattern, text)
      if(macroMatch == -1L) break

      # Opcao entre colchetes, como o pacote em link[pacote]
      matchText <- regmatches(text, macroMatch)
      macroOption <- sub("^[^[]*\\[?([^]]*)\\]?\\{$", "\\1", matchText)
      if(!grepl("[", matchText, fixed = TRUE)) macroOption <- ""

      # Le os argumentos entre chaves, um apos o outro
      textChars <- strsplit(text, "")[[1L]]
      openPos <- macroMatch + attr(macroMatch, "match.length") - 1L
      macroArgs <- character(0L)
      for(argIndex in seq_len(nArgs)){
        closePos <- FindClosingBrace(textChars, openPos)
        argChars <- textChars[seq_len(closePos - openPos - 1L) + openPos]
        macroArgs <- c(macroArgs, paste(argChars, collapse = ""))
        endPos <- closePos
        openPos <- closePos + 1L
      }

      # Monta o texto com a macro substituida
      text <- paste0(substr(text, 1L, macroMatch - 1L),
                     Formatter(macroArgs, macroOption),
                     substr(text, endPos + 1L, nchar(text)))
    }
    return(text)
  }

  # Converte `r lifecycle::badge("estagio")` em imagem com link para o estagio.
  # O svg e copiado do pacote lifecycle para a subpasta figures da saida.
  ConvertLifecycleBadge <- function(text){
    badgePattern <- "`r\\s+(lifecycle::)?badge\\(\\s*[\"']([a-z-]+)[\"']\\s*\\)`"
    repeat{
      badgeMatch <- regexpr(badgePattern, text, perl = TRUE)
      if(badgeMatch == -1L) break

      # Estagio informado e nome exibido, como experimental e Experimental
      badgeText <- regmatches(text, badgeMatch)
      lifecycleStage <- sub(badgePattern, "\\2", badgeText, perl = TRUE)
      stageLabel <- paste0(toupper(substr(lifecycleStage, 1L, 1L)),
                           substr(lifecycleStage, 2L, nchar(lifecycleStage)))
      badgeFile <- paste0("lifecycle-", lifecycleStage, ".svg")
      badgeSource <- if(hasLifecycle){
        system.file("help", "figures", badgeFile, package = "lifecycle")
      } else ""

      # Com o svg disponivel, gera imagem com link; sem ele, texto em negrito
      if(badgeSource != ""){
        dir.create(figuresDir, recursive = TRUE, showWarnings = FALSE)
        file.copy(badgeSource, file.path(figuresDir, badgeFile), overwrite = TRUE)
        badgeMarkdown <- paste0(
          "[![", stageLabel, "](figures/", badgeFile, ")]",
          "(https://lifecycle.r-lib.org/articles/stages.html#", lifecycleStage, ")"
        )
      } else {
        badgeMarkdown <- paste0("**[", stageLabel, "]**")
      }

      # Substitui somente a ocorrencia encontrada
      regmatches(text, badgeMatch) <- badgeMarkdown
    }
    return(text)
  }

  # Converte as marcacoes Rd usadas nos cabecalhos para Markdown do Quarto
  ConvertRdToMarkdown <- function(text){

    # Selo de ciclo de vida, antes das demais conversoes
    text <- ConvertLifecycleBadge(text)

    # Link para funcao: do projeto vira link de pagina; de pacote vira pacote::funcao
    text <- ReplaceRdMacro(text, "link", 1L, function(args, option){
      packageName <- sub(":.*$", "", option)
      if(packageName == "" && args[1L] %in% projectFunctions){
        return(paste0("[", args[1L], "](", args[1L], ".qmd)"))
      }
      if(packageName == "") return(args[1L])
      return(paste0(packageName, "::", args[1L]))
    })

    # Links externos
    text <- ReplaceRdMacro(text, "href", 2L, function(args, option){
      paste0("[", args[2L], "](", args[1L], ")")
    })
    text <- ReplaceRdMacro(text, "url", 1L, function(args, option){
      paste0("<", args[1L], ">")
    })

    # Formulas; deqn antes de eqn para nao confundir as duas macros
    text <- ReplaceRdMacro(text, "deqn", 1L, function(args, option){
      paste0("\n$$", trimws(args[1L]), "$$\n")
    })
    text <- ReplaceRdMacro(text, "eqn", 1L, function(args, option){
      paste0("$", trimws(args[1L]), "$")
    })

    # Codigo em linha; um link ja convertido nao recebe crases
    text <- ReplaceRdMacro(text, "code", 1L, function(args, option){
      if(startsWith(args[1L], "[")) return(args[1L])
      paste0("`", args[1L], "`")
    })

    # Enfase
    text <- ReplaceRdMacro(text, "emph", 1L, function(args, option){
      paste0("*", args[1L], "*")
    })
    text <- ReplaceRdMacro(text, "strong", 1L, function(args, option){
      paste0("**", args[1L], "**")
    })

    # Caractere de porcentagem escapado no Rd
    text <- gsub("\\%", "%", text, fixed = TRUE)

    return(trimws(text))
  }

  # Remove os involucros dontrun e donttest dos exemplos, mantendo o codigo
  ConvertExamples <- function(text){
    for(macroName in c("dontrun", "donttest")){
      text <- ReplaceRdMacro(text, macroName, 1L, function(args, option){
        gsub("^\n+|\n+$", "", args[1L])
      })
    }
    text <- gsub("\\%", "%", text, fixed = TRUE)
    return(trimws(text))
  }

  # Protege aspas duplas e barras invertidas em valores do cabecalho YAML
  QuoteYaml <- function(text){
    text <- gsub("\\", "\\\\", text, fixed = TRUE)
    paste0("\"", gsub("\"", "\\\"", text, fixed = TRUE), "\"")
  }

  # Emite aviso de auditoria identificando a funcao
  WarnHeader <- function(functionName, ...){
    warning(functionName, ": ", ..., call. = FALSE)
  }

  ## Leitura das definicoes e dos cabecalhos
  # Nome definido em cada arquivo; arquivos sem definicao usam o nome do arquivo
  definitions <- lapply(listFunctions, GetDefinition)
  functionNames <- vapply(seq_along(listFunctions), function(i){
    if(is.null(definitions[[i]])){
      return(tools::file_path_sans_ext(basename(listFunctions[i])))
    }
    definitions[[i]]$name
  }, character(1L))

  # Nomes das funcoes documentadas, usados para criar links entre as paginas
  projectFunctions <- functionNames

  # Le apenas os comentarios roxygen2 de cada arquivo, sem avaliar codigo
  roxygenFiles <- lapply(listFunctions, roxygen2::parse_file, env = NULL)

  # Familia declarada em cada cabecalho, usada no indice e nas paginas
  functionFamilies <- vapply(roxygenFiles, function(roxygenBlocks){
    if(length(roxygenBlocks) == 0L) return(NA_character_)
    familyValue <- unlist(GetTagValues(roxygenBlocks[[1L]]$tags, "family"))
    if(length(familyValue) == 0L) NA_character_ else trimws(familyValue[1L])
  }, character(1L))

  # Gera a pagina Quarto de um arquivo de funcao. Retorna NULL quando o arquivo
  # nao tem cabecalho, ou uma lista com o caminho gravado, o titulo e a familia.
  RenderFunctionFile <- function(fileIndex){

    # Arquivo, nome da funcao, definicao e blocos roxygen2 ja lidos
    functionFile <- listFunctions[fileIndex]
    functionName <- functionNames[fileIndex]
    functionDefinition <- definitions[[fileIndex]]
    roxygenBlocks <- roxygenFiles[[fileIndex]]

    # Arquivos sem cabecalho sao informados e ignorados
    if(length(roxygenBlocks) == 0L){
      WarnHeader(functionName, "arquivo sem cabeçalho roxygen2")
      return(NULL)
    }

    # Auditoria: nome do arquivo diferente do nome da funcao definida
    fileBaseName <- tools::file_path_sans_ext(basename(functionFile))
    if(!identical(fileBaseName, functionName)){
      WarnHeader(functionName, "definida no arquivo ", basename(functionFile),
                 ", com nome diferente da função")
    }

    # Usa o primeiro bloco, que documenta a funcao do arquivo
    roxygenTags <- roxygenBlocks[[1L]]$tags
    tagNames <- vapply(roxygenTags, function(tag) tag$tag, character(1L))
    tagNames[tagNames == "returns"] <- "return"

    # Auditoria: tags obrigatorias ausentes
    missingTags <- setdiff(requiredTags, tagNames)
    if(length(missingTags) > 0L){
      WarnHeader(functionName, "tags ausentes: ", paste(missingTags, collapse = ", "))
    }

    # Auditoria: linhas do bloco roxygen2 acima da largura maxima
    fileLines <- readLines(functionFile, encoding = "UTF-8", warn = FALSE)
    longLines <- which(startsWith(fileLines, "#'") & nchar(fileLines) > maxLineWidth)
    if(length(longLines) > 0L){
      WarnHeader(functionName, "linhas acima de ", maxLineWidth, " caracteres: ",
                 paste(longLines, collapse = ", "))
    }

    # Extrai cada tag usada no padrao do projeto
    tagTitle       <- unlist(GetTagValues(roxygenTags, "title"))
    tagUsage       <- unlist(GetTagValues(roxygenTags, "usage"))
    tagDescription <- unlist(GetTagValues(roxygenTags, "description"))
    tagParams      <- GetTagValues(roxygenTags, "param")
    tagDetails     <- unlist(GetTagValues(roxygenTags, "details"))
    tagSections    <- unlist(GetTagValues(roxygenTags, "section"))
    tagReturn      <- unlist(GetTagValues(roxygenTags, c("return", "returns")))
    tagExamples    <- unlist(GetTagValues(roxygenTags, "examples"))
    tagSeeAlso     <- unlist(GetTagValues(roxygenTags, "seealso"))
    tagReferences  <- unlist(GetTagValues(roxygenTags, "references"))

    # Auditoria: correspondencia entre param e argumentos reais da funcao. Objetos
    # que nao sao funcoes escritas no arquivo, como um metric_set, nao sao auditados.
    paramNames <- vapply(tagParams, function(param) param$name, character(1L))
    if(is.null(functionDefinition)){
      WarnHeader(functionName, "nenhuma definição encontrada no arquivo ", functionFile)
    } else if(functionDefinition$isFunction){
      functionArguments <- functionDefinition$arguments
      undocumentedArguments <- setdiff(functionArguments, paramNames)
      unknownParams <- setdiff(paramNames, functionArguments)
      if(length(undocumentedArguments) > 0L){
        WarnHeader(functionName, "argumentos sem @param: ",
                   paste(undocumentedArguments, collapse = ", "))
      }
      if(length(unknownParams) > 0L){
        WarnHeader(functionName, "@param sem argumento correspondente: ",
                   paste(unknownParams, collapse = ", "))
      }
    }

    # Cabecalho YAML do Quarto com o nome da funcao e o titulo do roxygen2
    pageTitle <- if(length(tagTitle) > 0L) ConvertRdToMarkdown(tagTitle) else ""
    qmdLines <- c("---", paste0("title: ", QuoteYaml(functionName)))
    if(pageTitle != ""){
      qmdLines <- c(qmdLines, paste0("subtitle: ", QuoteYaml(pageTitle)))
    }
    qmdLines <- c(qmdLines, "---", "")

    # Forma de uso, mantida como bloco de codigo R
    if(length(tagUsage) > 0L){
      qmdLines <- c(qmdLines, "## Uso", "", "```r", trimws(tagUsage), "```", "")
    }

    # Descricao geral da funcao
    if(length(tagDescription) > 0L){
      qmdLines <- c(qmdLines, "## Descrição", "",
                    ConvertRdToMarkdown(tagDescription), "")
    }

    # Parametros em tabela; quebras de linha e barras sao ajustadas para a celula
    if(length(tagParams) > 0L){
      qmdLines <- c(qmdLines, "## Parâmetros", "",
                    "| Parâmetro | Descrição |", "|---|---|")
      for(param in tagParams){
        paramText <- ConvertRdToMarkdown(param$description)
        paramText <- gsub("\\s*\n\\s*", " ", paramText)
        paramText <- gsub("|", "\\|", paramText, fixed = TRUE)
        qmdLines <- c(qmdLines, paste0("| `", param$name, "` | ", paramText, " |"))
      }
      qmdLines <- c(qmdLines, "")
    }

    # Detalhes de funcionamento
    if(length(tagDetails) > 0L){
      qmdLines <- c(qmdLines, "## Detalhes", "", ConvertRdToMarkdown(tagDetails), "")
    }

    # Secoes livres; a primeira linha e o titulo e o restante e o conteudo
    for(tagSection in tagSections){
      sectionTitle <- sub(":?\\s*$", "", sub("\n.*$", "", tagSection))
      sectionText <- if(grepl("\n", tagSection)) sub("^[^\n]*\n", "", tagSection) else ""
      sectionText <- trimws(ConvertLifecycleBadge(sectionText))

      # Codigo R inline, como os diagramas do flow, so e avaliado na geracao de .Rd
      if(grepl("^`r ", sectionText) || sectionText == ""){
        next
      }
      qmdLines <- c(qmdLines, paste0("## ", sectionTitle), "",
                    ConvertRdToMarkdown(sectionText), "")
    }

    # Objeto retornado; remove o recuo das linhas de continuacao da tag
    if(length(tagReturn) > 0L){
      returnText <- gsub("\n[ \t]+", "\n", ConvertRdToMarkdown(tagReturn))
      qmdLines <- c(qmdLines, "## Retorno", "", returnText, "")
    }

    # Exemplos, sem os involucros dontrun e donttest, sem execucao pelo Quarto
    if(length(tagExamples) > 0L){
      qmdLines <- c(qmdLines, "## Exemplos", "", "```r",
                    ConvertExamples(tagExamples), "```", "")
    }

    # Familia: links para as demais funcoes do mesmo grupo
    functionFamily <- functionFamilies[fileIndex]
    if(!is.na(functionFamily)){
      familyMembers <- setdiff(functionNames[functionFamilies %in% functionFamily],
                               functionName)
      qmdLines <- c(qmdLines, "## Família", "", paste0("**", functionFamily, "**"), "")
      if(length(familyMembers) > 0L){
        qmdLines <- c(qmdLines,
                      paste0("- [", familyMembers, "](", familyMembers, ".qmd)"), "")
      }
    }

    # Ver tambem: um item por referencia; nomes simples do projeto viram links
    if(length(tagSeeAlso) > 0L){
      seeAlsoItems <- ConvertRdToMarkdown(tagSeeAlso) |>
        strsplit("[,\n]") |>
        unlist() |>
        trimws()
      seeAlsoItems <- seeAlsoItems[seeAlsoItems != ""]
      seeAlsoItems <- ifelse(
        test = seeAlsoItems %in% projectFunctions,
        yes = paste0("[", seeAlsoItems, "](", seeAlsoItems, ".qmd)"),
        no = ifelse(grepl("^[[:alnum:]._:]+$", seeAlsoItems),
                    paste0("`", seeAlsoItems, "`"),
                    seeAlsoItems)
      )
      qmdLines <- c(qmdLines, "## Ver também", "", paste0("- ", seeAlsoItems), "")
    }

    # Referencias bibliograficas, separadas por linha em branco no cabecalho
    if(length(tagReferences) > 0L){
      qmdLines <- c(qmdLines, "## Referências", "",
                    ConvertRdToMarkdown(tagReferences), "")
    }

    # Rodape indicando a origem, para que a pagina nao seja editada a mao
    qmdLines <- c(qmdLines, "---", "",
                  paste0("*Gerado a partir de `", basename(functionFile), "` em ",
                         format(Sys.Date(), "%d/%m/%Y"),
                         ". Para alterar, edite o cabeçalho roxygen2 do arquivo",
                         " de origem.*"))

    # Grava a pagina Quarto em UTF-8, com o nome da funcao
    qmdFile <- file.path(pathOutputQmd, paste0(functionName, ".qmd"))
    writeLines(enc2utf8(qmdLines), qmdFile, useBytes = TRUE)
    message("Gerado: ", qmdFile)

    # Devolve o arquivo gravado e os dados usados no indice
    return(list(qmdFile = qmdFile, name = functionName, title = pageTitle,
                family = functionFamily))
  }

  ## Geracao de uma pagina Quarto por funcao
  # Gera a pagina de cada arquivo e descarta os arquivos sem cabecalho
  renderedFiles <- lapply(seq_along(listFunctions), RenderFunctionFile) |>
    Filter(f = Negate(is.null))

  ## Gravacao do indice e retorno dos caminhos
  # Tabela de funcoes agrupada por familia; funcoes sem familia ficam ao final
  qmdFiles <- vapply(renderedFiles, function(rendered) rendered$qmdFile, character(1L))
  indexFamilies <- vapply(renderedFiles, function(rendered){
    if(is.na(rendered$family)) "Sem família" else rendered$family
  }, character(1L))
  familyOrder <- c(setdiff(sort(unique(indexFamilies)), "Sem família"),
                   intersect("Sem família", indexFamilies))
  indexLines <- c("---", paste0("title: ", QuoteYaml("Funções do predictive.factory")),
                  "---", "")
  for(familyName in familyOrder){
    familyRows <- renderedFiles[indexFamilies == familyName]
    indexLines <- c(indexLines, paste0("## ", familyName), "",
                    "| Função | Título |", "|---|---|",
                    vapply(familyRows, function(rendered){
                      paste0("| [", rendered$name, "](", rendered$name, ".qmd) | ",
                             rendered$title, " |")
                    }, character(1L)), "")
  }

  # Grava o indice da documentacao
  indexFile <- file.path(pathOutputQmd, "index.qmd")
  writeLines(enc2utf8(indexLines), indexFile, useBytes = TRUE)
  message("Gerado: ", indexFile)

  # Retorna os caminhos gerados sem imprimir no console
  return(invisible(c(qmdFiles, indexFile)))
}
####
## Fim
#
