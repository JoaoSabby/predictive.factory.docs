#' @title Executar o Pipeline Preditivo de um Modelo Alvo
#'
#' @usage
#' RunPipeline(
#'   targetModel,
#'   dataReferencia = DbDataMax(),
#'   horizontePreditivo = 3L,
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L
#' )
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Ponto de entrada da Predictive Factory. Valida o nome do modelo alvo, verifica se o
#' modelo preditivo já foi registrado para a combinação de parâmetros informada e, quando
#' ainda não existe, gera a configuração de execução e dispara o pipeline `targets`.
#'
#' @details
#' A identificação de uma execução é a combinação de `targetModel`, `dataReferencia`,
#' `horizontePreditivo`, `janelaAgregacao` e `janelaHistorico`. A função segue as etapas:
#'
#' #. converte `targetModel` para maiúsculas e valida o formato pela expressão regular
#'    `^[a-zA-Z0-9]+(_[a-zA-Z0-9]+)*$`: apenas letras, números e underline, sem underline
#'    no início, no fim ou repetido;
#' #. consulta `ML_MODEL_REGISTRY` por meio de `CheckPredictiveModelExists()`; se o modelo
#'    existir, encerra sem reprocessar;
#' #. cria pastas, datas e o arquivo YAML de configuração por meio de
#'    `ConfigurePredictiveModelRun()`;
#' #. executa `targets::tar_make()` com o script `_targets.R` do orquestrador, o
#'    repositório do modelo como `store`, relatório `"balanced"` e workers `crew`.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-database"></i> **Idempotência:**
#' Uma segunda chamada com os mesmos parâmetros não reprocessa o modelo: a existência do
#' registro em `ML_MODEL_REGISTRY` interrompe a execução antes da geração de dados.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(RunPipeline, prefix = "##", code = FALSE,
#'   narrow = TRUE), "RunPipeline_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(RunPipeline, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "RunPipeline_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - registra `on.exit(TerminateTarget())`, que fecha todas as conexões de banco de dados
#'   ao final, inclusive em caso de erro;
#' - cria a estrutura de pastas e o arquivo `_PredictiveModelRunConfig.yaml` do modelo,
#'   por meio de `ConfigurePredictiveModelRun()`;
#' - define a variável de ambiente `GPC_PREDICTIVE_FACTORY_RUN_CONFIG` e o lock de
#'   execução do modelo;
#' - executa o pipeline `targets`, que grava o repositório `_targets`, tabelas no banco
#'   Oracle e artefatos do modelo.
#'
#' @param targetModel Vetor de caracteres de comprimento 1 com o nome do alvo de predição
#'   (por exemplo, `"OF_INFLOW_AUTHORISED"`). É convertido para maiúsculas; a execução é
#'   interrompida com erro quando contém caracteres fora de letras, números e underline.
#' @param dataReferencia Data de referência da execução (`Date` ou texto no formato
#'   `"AAAA-MM-DD"`). O padrão `DbDataMax()` usa a data mais recente disponível no banco.
#' @param horizontePreditivo Inteiro com o número de meses à frente a serem previstos
#'   (padrão: `3L`).
#' @param janelaAgregacao Inteiro com o número de meses usados na sumarização dos
#'   preditores (padrão: `6L`).
#' @param janelaHistorico Inteiro com o número de meses de profundidade histórica dos
#'   preditores (padrão: `36L`).
#'
#' @returns Retorna invisivelmente `TRUE`, tanto quando o modelo já existia quanto após a
#'   execução do pipeline. Erros do pipeline são propagados por `tar_make()`.
#'
#' @family Orquestração do Pipeline
#'
#' @seealso \code{\link{CheckPredictiveModelExists}},
#'   \code{\link{ConfigurePredictiveModelRun}}, \code{\link{TerminateTarget}},
#'   \code{\link[targets]{tar_make}}
#'
#' @references
#' Landau, W. M. (2021). The targets R package: a dynamic Make-like function-oriented
#' pipeline toolkit for reproducibility and high-performance computing. Journal of Open
#' Source Software, 6(57), 2959.
#' \url{https://doi.org/10.21105/joss.02959}
#'
#' The targets R Package User Manual.
#' \url{https://books.ropensci.org/targets/}
#'
#' crew: A Distributed Worker Launcher Framework.
#' \url{https://wlandau.github.io/crew/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: ambiente carregado por _Setup.R
#' RunPipeline(
#'   targetModel = "OF_INFLOW_AUTHORISED",
#'   dataReferencia = as.Date("2026-01-01"),
#'   horizontePreditivo = 3L,
#'   janelaAgregacao = 6L,
#'   janelaHistorico = 36L
#' )
#' }
#'
#' @importFrom targets tar_make
#'
#' @export
RunPipeline <- function(
    targetModel,
    dataReferencia = DbDataMax(),
    horizontePreditivo = 3L,
    janelaAgregacao = 6L,
    janelaHistorico = 36L
){
  
  ## Registro da finalizacao de seguranca
  # Finalizacao de seguranca
  on.exit(TerminateTarget())
  
  ## Validacao do nome do modelo alvo
  # Deixa em maiusculo
  targetModel <- toupper(targetModel)
  
  if(!grepl("^[a-zA-Z0-9]+(_[a-zA-Z0-9]+)*$", targetModel)){
    stop("targetModel permite somente letras maiúsculas de A a Z, números e underline.")
  }
  
  ## Verificacao de modelo ja registrado
  # Verifica se o modelo preditivo esta disponivel
  existsPredictiveModel <- CheckPredictiveModelExists(
    targetModel = targetModel,
    dataReferencia = dataReferencia,
    horizontePreditivo = horizontePreditivo,
    janelaAgregacao = janelaAgregacao,
    janelaHistorico = janelaHistorico
  )
  
  # Se o modelo existe
  if(existsPredictiveModel){
    return(invisible(TRUE))
  }
  
  ## Geracao da configuracao de execucao
  # Definicao da configuracao de execucao
  modelRunConfig <- ConfigurePredictiveModelRun(
    targetModel = targetModel,
    dataReferencia = dataReferencia,
    horizontePreditivo = horizontePreditivo,
    janelaAgregacao = janelaAgregacao,
    janelaHistorico = janelaHistorico
  )
  
  ## Execucao do pipeline targets
  # Executa pipeline
  tar_make(
    script = modelRunConfig$paths$scriptPath,
    store = modelRunConfig$paths$modelPath,
    reporter = "balanced",
    use_crew = TRUE
  )
  
  # Retorno invisivel de sucesso
  return(invisible(TRUE))
}
#####
## Fim
#
