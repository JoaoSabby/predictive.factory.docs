#' @title Finalizar a Execução de um Target
#'
#' @usage
#' TerminateTarget()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Executa as finalizações de segurança de um target ou de uma execução do pipeline,
#' encerrando todas as conexões de banco de dados abertas.
#'
#' @details
#' É registrada com `on.exit(TerminateTarget())` em `RunPipeline()` e nas 22 funções
#' `GenerateFeatureLineage_IM_ML_*`. Dessa forma, as conexões são fechadas também quando a
#' função chamadora termina com erro.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(TerminateTarget, prefix = "##", code = FALSE,
#'   narrow = TRUE), "TerminateTarget_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(TerminateTarget, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "TerminateTarget_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - fecha todas as conexões de banco de dados abertas no processo, por meio de
#'   `DbDisconnectAll()`.
#'
#' @returns `NULL` invisível.
#'
#' @family Orquestração do Pipeline
#'
#' @seealso \code{\link{InitializeTargetExecution}}, \code{\link{RunPipeline}},
#'   \code{\link[base]{on.exit}}
#'
#' @references
#' DBI: R Database Interface.
#' \url{https://dbi.r-dbi.org/}
#'
#' @examples
#' \dontrun{
#' funcaoComBanco <- function(){
#'   on.exit(TerminateTarget())
#'   # consultas ao banco de dados
#' }
#' }
#'
#' @export
TerminateTarget <- function(){
  
  ## Encerramento das conexoes de banco de dados
  # Desconecao do banco de dados
  DbDisconnectAll()
  
  ## Retorno invisivel
  # Funcao sem retorno
  invisible()
}
####
## Fim
# 