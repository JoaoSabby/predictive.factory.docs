#' @title Otimizar os Hiperparâmetros do Modelo Binário por Busca Bayesiana
#'
#' @usage
#' TuneModel(trainingSet)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Executa a otimização bayesiana de hiperparâmetros do XGBoost, avaliando cada candidato
#' pela média da área sob a curva precisão-recall em validação cruzada estratificada, e
#' retorna o melhor conjunto já convertido para a escala do modelo.
#'
#' @details
#' As etapas são:
#'
#' #. remoção das colunas de contexto (`predy_columns_key_context`) e montagem de `params`
#'    com motor, limites de threads, número de folds, classes e contagens;
#' #. criação de um cluster PSOCK aninhado por `CreateNestedCluster()`, com
#'    `predy_tune_threads_outer` workers externos, e registro como backend `future`;
#' #. preparação dos folds em disco por `TuneModelResampleFoldsXGBoost()` e dos limites de
#'    busca por `TuneModelBoundsXGBoost()`;
#' #. otimização por `rBayesianOptimization::BayesianOptimization()`, com processo
#'    gaussiano de núcleo exponencial de potência 2 e aquisição por melhoria esperada
#'    (`acq = "ei"`, `eps = 0`);
#' #. conversão do melhor ponto para a escala do XGBoost em `results`.
#'
#' A busca ocorre em escalas transformadas, revertidas por:
#' \deqn{\eta = 10^{u_1}, \quad w = 2^{u_2}}
#' \deqn{\gamma = e^{u_3} - 1, \quad \lambda = 2^{u_4}}
#' em que \eqn{u_1}, \eqn{u_2}, \eqn{u_3} e \eqn{u_4} são `learning_rate_log10`,
#' `min_child_weight_log2`, `min_split_loss_log1p` e `reg_lambda_log2`. Os parâmetros
#' `max_delta_step` e `reg_alpha` são fixos e vêm de `predy_engine_model_xgboost`.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-circle-info"></i> **Número de Avaliações:**
#' Como `TuneModelLastGrid()` retorna `NULL`, a busca usa `init_points = 2` e `n_iter =
#' 1`, isto é, três avaliações de candidatos. Com uma grade inicial, os valores passam a
#' `0` e `10`.
#' :::
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Motor LightGBM:**
#' O ramo `"lightgbm"` compara a variável `engine_model`, que não existe no escopo da
#' função (o valor está em `params$engine_model`), e não define a função objetivo. Apenas
#' o motor `"xgboost"` é operacional.
#' :::
#'
#' Quando `predy_tune_debug` é `TRUE`, cada avaliação é registrada pelo pacote `logger` em
#' `/soft/bdq/log/ufrgs/gpc.predictive.factory/debugger.log`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(TuneModel, prefix = "##", code = FALSE,
#'   narrow = TRUE), "TuneModel_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(TuneModel, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "TuneModel_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - cria um cluster PSOCK e altera o plano `future`; no `on.exit()`, restaura o plano
#'   sequencial, encerra o cluster e restaura a afinidade de CPU original;
#' - grava matrizes `xgb.DMatrix` em `tempdir()`, por meio de
#'   `TuneModelResampleFoldsXGBoost()`;
#' - altera a opção `tmpCount`, usada como contador de iterações;
#' - com depuração ativa, remove e recria o arquivo de log de depuração;
#' - depende do objeto global `dataFeatureTreino`.
#'
#' @section Complexidade Computacional:
#' Sendo \eqn{K} o número de folds, \eqn{I} o número de avaliações e \eqn{T} o custo de um
#' ajuste XGBoost com parada antecipada, o custo é \eqn{O(I \cdot K \cdot T)}, com os
#' \eqn{K} folds de cada avaliação executados em paralelo.
#'
#' @param trainingSet Tibble de treino preprocessada, com `TARGET` (fator cujo primeiro
#'   nível é a classe positiva) e as features.
#'
#' @returns Lista retornada por `BayesianOptimization()` (`Best_Par`, `Best_Value`,
#'   `History` e `Pred`), acrescida de `results`: lista com `colsample_bytree`,
#'   `learning_rate`, `max_delta_step`, `max_depth`, `min_child_weight`, `min_split_loss`,
#'   `reg_alpha`, `reg_lambda` e `subsample` na escala do XGBoost.
#'
#' @family Otimização de Hiperparâmetros
#'
#' @seealso \code{\link{TuneModelResampleFoldsXGBoost}},
#'   \code{\link{TuneModelBoundsXGBoost}}, \code{\link{TuneModelEvaluateXGBoostFolds}},
#'   \code{\link{FitModelXGBoost}},
#'   \code{\link[rBayesianOptimization]{BayesianOptimization}}
#'
#' @references
#' Mockus, J. (1975). On Bayesian methods for seeking the extremum. Optimization
#' Techniques IFIP Technical Conference, 400-404.
#'
#' Jones, D. R., Schonlau, M., & Welch, W. J. (1998). Efficient global optimization of
#' expensive black-box functions. Journal of Global Optimization, 13(4), 455-492.
#' \url{https://doi.org/10.1023/A:1008306431147}
#'
#' Snoek, J., Larochelle, H., & Adams, R. P. (2012). Practical Bayesian optimization of
#' machine learning algorithms. Advances in Neural Information Processing Systems 25.
#'
#' Shahriari, B., Swersky, K., Wang, Z., Adams, R. P., & de Freitas, N. (2016). Taking the
#' human out of the loop: A review of Bayesian optimization. Proceedings of the IEEE,
#' 104(1), 148-175.
#' \url{https://doi.org/10.1109/JPROC.2015.2494218}
#'
#' rBayesianOptimization: Bayesian Optimization of Hyperparameters.
#' \url{https://cran.r-project.org/package=rBayesianOptimization}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: opções definidas por DefineOptionsSetup() e dataFeatureTreino global
#' hyperParams <- TuneModel(trainingSet = trainingSet)
#' hyperParams$results
#' }
#'
#' @importFrom rBayesianOptimization BayesianOptimization
#' @importFrom future plan
#'
#' @export
TuneModel <- function(trainingSet){
  
  ## Montagem dos parametros
  # Remove colunas de contexto
  tuneSet <- trainingSet |> 
    select(-any_of(opt("predy_columns_key_context")))
  
  # Objeto agrupa dor de parametros 
  params <- list()
  
  # Algoritmo utilizado para modelo preditivo
  params$engine_model <- opt("predy_engine_model")
  
  # Busca o limite de threads
  params$threads_limit <- opt("predy_threads_limit")
  
  # Quantidade de fols para media de desempenho
  params$nFolds <- opt("predy_tune_num_folds")

  params$positiveClass <- levels(tuneSet$TARGET)[1L]
  params$negativeClass <- levels(tuneSet$TARGET)[2L]
  params$positiveCount <- sum(tuneSet$TARGET == params$positiveClass)
  params$negativeCount <- sum(tuneSet$TARGET == params$negativeClass)
  params$nLinhas       <- fnrow(tuneSet)
  params$nFeatures     <- fncol(tuneSet) - 1L # Subtrai o TARGET
  params$initialGrid   <- TuneModelLastGrid(dataFeatureTreino)
  
  ## Criacao do cluster de folds
  # Captura a estrategia future ativa antes do registro do cluster PSOCK local.
  # O valor preservado permite restaurar o contexto de execucao pertencente ao
  # targets, ao crew ou a qualquer outro chamador que controle o processo R.
  foldCluster <- CreateNestedCluster(
    outerWorkers = opt("predy_tune_threads_outer")
  )
  
  # Registra o cluster ja inicializado como backend do future. A criacao dos
  # workers e o CPU pinning permanecem centralizados em CreateNestedCluster e
  # nao sao repetidos de forma independente por cada tarefa de fold.
  plan(cluster, workers = foldCluster)
  
  # Registra o cleanup imediatamente depois da criacao bem-sucedida do cluster.
  # A restauracao inicial do plano future remove referencias ao backend
  # aninhado; em seguida, o cluster pode ser encerrado e a afinidade original do
  # chamador pode ser restabelecida. Chamadas independentes de try impedem que
  # uma falha de cleanup suprima as demais operacoes de recuperacao.
  on.exit({
    invisible(try(plan(sequential), silent = TRUE))
    invisible(try(stopCluster(foldCluster), silent = TRUE))
    invisible(try(mcaffinity(attr(foldCluster, "originalAffinity")), silent = TRUE))
  }, add = TRUE)
  
  # Recupera o limite interno calculado a partir das CPUs autorizadas pelo
  # launcher depois da reserva de um nucleo fisico para o chamador. Esse valor
  # unico controla a rotina de balanceamento do cliente e a construcao nativa
  # das matrizes do XGBoost.
  params$innerThreads <- attr(foldCluster, "innerThreads")
  
  ## Preparacao dos folds e da funcao objetivo
  # Se for engine de XGBoost
  if(params$engine_model == "xgboost"){
    
    # Hiperparametros fixos
    params  <- c(params, opt("predy_engine_model_xgboost"))
    
    # Particionamento treino, validacao, teste por fold
    params$splits <- TuneModelResampleFoldsXGBoost(tuneSet, params)
    
    # Prepara bounds para XGBoost
    tuneModelBounds <- TuneModelBoundsXGBoost()
    
    # Indica se deve gerar log debug
    gerarLogDebug <- opt("predy_tune_debug")
    
    # Se deve gerar log de debug
    if(gerarLogDebug){
      fileLog <- file.path("/soft/bdq/log/ufrgs/gpc.predictive.factory/debugger.log")
      try(file.remove(fileLog), silent = TRUE)
      log_appender(appender_file(file.path(fileLog)), namespace = "debugger")
      log_threshold(TRACE, namespace = "debugger")
    }
    
    options(tmpCount = 0L)
    
    # Adapta assinatura para BayesianOptimization
    TuneModelEvaluateFoldsAdapter <- function(
      colsample_bytree      = 0.7285,
      learning_rate_log10   = 1.5005,
      max_depth             = 3L,
      min_child_weight_log2 = 0.7213,
      min_split_loss_log1p  = 0.8319,
      subsample             = 0.9909,
      reg_lambda_log2       = 1.3515
    ){
      
      params$colsample_bytree <- as.double(colsample_bytree)
      params$learning_rate    <- as.double(10L^learning_rate_log10)
      params$max_depth        <- as.integer(round(max_depth, digits = 0L))
      params$min_child_weight <- as.double(2L^min_child_weight_log2)
      params$min_split_loss   <- as.double(expm1(min_split_loss_log1p))
      params$reg_lambda       <- as.double(2L^reg_lambda_log2)
      params$subsample        <- as.double(subsample)
      
      # Avalia o conjutno de hiperparametros candidato
      ini <- Sys.time()
      candidateResult <- TuneModelEvaluateXGBoostFolds(params)
      
      # Incrementa iteracao executada
      iteracao <- getOption("tmpCount") + 1L
      
      # Se deve gerar log de debug
      if(gerarLogDebug){
        log_debug(namespace = "debugger", "\n
        =======================
        iteracao               : [ {iteracao} ]
        =======================
        params$colsample_bytree: {params$colsample_bytree}
        params$learning_rate   : {params$learning_rate}
        params$max_depth       : {params$max_depth}
        params$min_child_weight: {params$min_child_weight}
        params$min_split_loss  : {params$min_split_loss}
        params$reg_lambda      : {params$reg_lambda}
        params$subsample       : {params$subsample}
        candidateResult        : {candidateResult}
        tempo                  : {capture.output(Sys.time() - ini)}
        =======================\n
      ")
      }
      
      options(tmpCount = iteracao)
      
      return(candidateResult)
    }
    
  } else if(engine_model == "lightgbm"){
    
    # Prepara bounds para LightGBM
    tuneModelBounds <- TuneModelBoundsLightGBM()
    
  } else {
    stop("Algoritmo preditivo (engine model) inválido")
  }
  
  ## Definicao do numero de avaliacoes
  nInitPoints <-  if(is.null(params$initialGrid)) 2L else 0L
  
  nIter <-  if(is.null(params$initialGrid)) 1L else 10L
  
  totIter <- nInitPoints + nIter
  
  ## Otimizacao bayesiana
  # Executa otimizacao bayesiana
  hyperParams <- suppressWarnings(
    expr = do.call(
      what = BayesianOptimization,
      args = list(
        FUN = TuneModelEvaluateFoldsAdapter,
        bounds = tuneModelBounds,
        init_grid_dt = params$initialGrid,
        init_points = nInitPoints,
        n_iter = nIter,
        acq = "ei",
        eps = 0.0,
        kernel = list(
          type = "exponential",
          power = 2L
        ),
        verbose = TRUE
      )
    )
  )
  
  ## Conversao dos resultados
  # Resultados para FitModel
  hyperParams$results <- list(
    colsample_bytree = as.double(hyperParams$Best_Par["colsample_bytree"]),
    learning_rate    = as.double(10L^hyperParams$Best_Par["learning_rate_log10"]),
    max_delta_step   = params$max_delta_step,
    max_depth        = as.integer(round(hyperParams$Best_Par["max_depth"], digits = 0L)),
    min_child_weight = as.double(2L^hyperParams$Best_Par["min_child_weight_log2"]),
    min_split_loss   = as.double(expm1(hyperParams$Best_Par["min_split_loss_log1p"])),
    reg_alpha        = params$reg_alpha,
    reg_lambda       = as.double(2L^hyperParams$Best_Par["reg_lambda_log2"]),
    subsample        = as.double(hyperParams$Best_Par["subsample"])
  )
  
  # Retorna resultado da otimizacao
  return(hyperParams)
}
####
## Fim
#
