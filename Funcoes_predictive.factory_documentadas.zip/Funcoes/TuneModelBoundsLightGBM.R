#' @title Definir os Limites da Busca de Hiperparâmetros do LightGBM
#'
#' @usage
#' TuneModelBoundsLightGBM()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Retorna os intervalos de busca para os hiperparâmetros do LightGBM, na nomenclatura do
#' `tidymodels`, incluindo o peso da classe positiva.
#'
#' @details
#' +--------------------+----------------------------------------------------------------+
#' | Parâmetro          | Intervalo                                                      |
#' +====================+================================================================+
#' | `trees`            | \eqn{[500; 3000]}                                              |
#' +--------------------+----------------------------------------------------------------+
#' | `tree_depth`       | \eqn{[3; 10]}                                                  |
#' +--------------------+----------------------------------------------------------------+
#' | `learn_rate`       | \eqn{[0{,}005; 0{,}15]}                                        |
#' +--------------------+----------------------------------------------------------------+
#' | `loss_reduction`   | \eqn{[0; 20]}                                                  |
#' +--------------------+----------------------------------------------------------------+
#' | `sample_size`      | \eqn{[0{,}5; 1]}                                               |
#' +--------------------+----------------------------------------------------------------+
#' | `mtry`             | \eqn{[1; p]}, com \eqn{p} igual a `nFeatures`                  |
#' +--------------------+----------------------------------------------------------------+
#' | `stop_iter`        | \eqn{[20; 100]}                                                |
#' +--------------------+----------------------------------------------------------------+
#' | `scale_pos_weight` | \eqn{[1; \max(1, \min(1000, 2r))]}, com \eqn{r} igual a        |
#' |                    | `classRatio`                                                   |
#' +--------------------+----------------------------------------------------------------+
#'
#' ::: {.callout-warning}
#' <i class="fa-solid fa-triangle-exclamation"></i> **Variáveis Externas:**
#' `classRatio` e `nFeatures` não são argumentos da função; são procurados no ambiente de
#' definição. Sem esses objetos, a execução termina com erro.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(TuneModelBoundsLightGBM, prefix = "##", code = FALSE,
#'   narrow = TRUE), "TuneModelBoundsLightGBM_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(TuneModelBoundsLightGBM, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "TuneModelBoundsLightGBM_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @returns Lista invisível de vetores numéricos de comprimento 2.
#'
#' @family Otimização de Hiperparâmetros
#'
#' @seealso \code{\link{TuneModel}}, \code{\link{TuneModelBoundsXGBoost}},
#'   \code{\link{FitModelLightGBM}}
#'
#' @references
#' LightGBM Documentation: Parameters Tuning.
#' \url{https://lightgbm.readthedocs.io/en/latest/Parameters-Tuning.html}
#'
#' @examples
#' \dontrun{
#' classRatio <- 25
#' nFeatures <- 120L
#' tuneModelBounds <- TuneModelBoundsLightGBM()
#' }
#'
#' @export
TuneModelBoundsLightGBM <- function(){
  
  ## Calculo do peso maximo da classe positiva
  # Define limite superior do peso da classe positiva
  scalePosWeightUpper <- max(
    1,
    min(
      1000,
      2 * classRatio
    )
  )
  
  ## Montagem dos intervalos de busca
  # Organiza limites
  tuneModelBounds <- list(
    trees = c(500L, 3000L),
    tree_depth = c(3L, 10L),
    learn_rate = c(0.005, 0.15),
    loss_reduction = c(0, 20),
    sample_size = c(0.5, 1),
    mtry = c(1L, as.integer(nFeatures)),
    stop_iter = c(20L, 100L),
    scale_pos_weight = c(1, scalePosWeightUpper)
  )
  
  # Retorna limites
  return(invisible(tuneModelBounds))
}
####
## Fim
#
