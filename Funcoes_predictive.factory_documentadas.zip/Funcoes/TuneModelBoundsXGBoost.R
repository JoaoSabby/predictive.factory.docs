#' @title Definir os Limites da Busca de Hiperparâmetros do XGBoost
#'
#' @usage
#' TuneModelBoundsXGBoost()
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Retorna os intervalos de busca da otimização bayesiana para os hiperparâmetros do
#' XGBoost, com transformações de escala que distribuem melhor a busca em parâmetros de
#' efeito multiplicativo.
#'
#' @details
#' +-------------------------+----------------------------------+------------------------+
#' | Parâmetro de busca      | Intervalo                        | Escala do XGBoost      |
#' +=========================+==================================+========================+
#' | `colsample_bytree`      | \eqn{[0{,}60; 1{,}0]}            | linear                 |
#' +-------------------------+----------------------------------+------------------------+
#' | `learning_rate_log10`   | \eqn{[\log_{10} 0{,}015;         | \eqn{\eta = 10^{u}}    |
#' |                         | \log_{10} 0{,}08]}               |                        |
#' +-------------------------+----------------------------------+------------------------+
#' | `max_depth`             | \eqn{[3; 10]}                    | inteiro, arredondado   |
#' +-------------------------+----------------------------------+------------------------+
#' | `min_child_weight_log2` | \eqn{[\log_2 1; \log_2 64]}      | \eqn{w = 2^{u}}        |
#' +-------------------------+----------------------------------+------------------------+
#' | `min_split_loss_log1p`  | \eqn{[\log(1+0); \log(1+10)]}    | \eqn{\gamma = e^{u} -  |
#' |                         |                                  | 1}                     |
#' +-------------------------+----------------------------------+------------------------+
#' | `reg_lambda_log2`       | \eqn{[\log_2 0{,}1; \log_2 64]}  | \eqn{\lambda = 2^{u}}  |
#' +-------------------------+----------------------------------+------------------------+
#' | `subsample`             | \eqn{[0{,}75; 1{,}0]}            | linear                 |
#' +-------------------------+----------------------------------+------------------------+
#'
#' A transformação `log1p` permite incluir o zero no intervalo de `min_split_loss`. A
#' reversão das escalas é feita na função objetivo de `TuneModel()` e na montagem de
#' `results`.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(TuneModelBoundsXGBoost, prefix = "##", code = FALSE,
#'   narrow = TRUE), "TuneModelBoundsXGBoost_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(TuneModelBoundsXGBoost, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "TuneModelBoundsXGBoost_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @returns Lista nomeada de vetores numéricos de comprimento 2 (limite inferior e
#'   superior), no formato esperado pelo argumento `bounds` de `BayesianOptimization()`.
#'
#' @family Otimização de Hiperparâmetros
#'
#' @seealso \code{\link{TuneModel}}, \code{\link{TuneModelBoundsLightGBM}},
#'   \code{\link[rBayesianOptimization]{BayesianOptimization}}
#'
#' @references
#' Bergstra, J., & Bengio, Y. (2012). Random search for hyper-parameter optimization.
#' Journal of Machine Learning Research, 13, 281-305.
#' \url{https://www.jmlr.org/papers/v13/bergstra12a.html}
#'
#' XGBoost Documentation: Parameters.
#' \url{https://xgboost.readthedocs.io/en/stable/parameter.html}
#'
#' @examples
#' \dontrun{
#' tuneModelBounds <- TuneModelBoundsXGBoost()
#' 10^tuneModelBounds$learning_rate_log10
#' }
#'
#' @export
TuneModelBoundsXGBoost <- function(){
  
  ## Montagem dos intervalos de busca
  # Monta intervalos para busca bayesiana inicial
  tuneModelBounds <- list(
    
    # colsample_bytree define a proporcao de colunas avaliadas
    # escala linear e mantida para preservacao da interpretacao direta
    colsample_bytree = c(0.60, 1.0),
    
    # learning_rate atua de forma multiplicativa
    # log10 distribui adequadamente valores pequenos e medios
    learning_rate_log10 = c(log10(0.015), log10(0.08)),
    
    # max_depth controla a complexidade da arvore
    # inteiro direto devido ao dominio util reduzido
    max_depth = c(3L, 10L),
    
    # min_child_weight representa a soma minima de hessianos
    # reducao do limite superior para 64l foca a busca em zonas de maior ganho
    min_child_weight_log2 = c(log2(1L), log2(64L)),
    
    # min_split_loss aceita zero em sua definicao
    # log1p mantem a busca multiplicativa e viabiliza a inclusao do zero
    min_split_loss_log1p = c(log1p(0L), log1p(10L)),
    
    # reg_lambda aplica penalidade l2 nos pesos das folhas
    # log2 evita a concentracao excessiva em valores altos de regularizacao
    # limite inferior reduzido para permitir modelos com menor penalizacao
    reg_lambda_log2 = c(log2(0.1), log2(64L)),
    
    # subsample define a proporcao de observacoes por arvore
    # escala linear atende perfeitamente o requisito de amostragem
    subsample = c(0.75, 1.0)
    
  )
  
  ## Retorno dos limites
  # Retorna limites
  return(tuneModelBounds)
}
####
## Fim
#
