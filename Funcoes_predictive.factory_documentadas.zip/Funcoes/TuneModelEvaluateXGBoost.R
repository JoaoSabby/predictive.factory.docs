#' @title Avaliar um Candidato de Hiperparâmetros em um Fold
#'
#' @usage
#' TuneModelEvaluateXGBoost(xgbTuneSetTrain, xgbTuneSetValid, xgbTuneSetTest, params)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Ajusta um modelo XGBoost com os hiperparâmetros candidatos na porção de treino do fold,
#' com parada antecipada na porção de validação, e mede a área sob a curva precisão-recall
#' na porção de teste.
#'
#' @details
#' O ajuste usa até 2.000 rodadas, `early_stopping_rounds = 50`, métrica `aucpr`, árvores
#' `gbtree`, método `hist`, `max_bin = 512` e semente `42`. O desempenho do fold é a área
#' sob a curva precisão-recall da classe positiva na porção de teste:
#' \deqn{\mathrm{AUC\text{-}PR} = \int_0^1 P(R) \, dR}
#'
#' ::: {.callout-important}
#' <i class="fa-solid fa-circle-exclamation"></i> **Coluna Removida antes do Cálculo:**
#' A seleção `dplyr::select(TARGET, .pred_class)` remove `.pred_positive`, usada em
#' seguida por `yardstick::pr_auc_vec()`. O acesso `predictionData$.pred_positive` retorna
#' `NULL` e o cálculo da métrica termina com erro.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(TuneModelEvaluateXGBoost, prefix = "##", code = FALSE,
#'   narrow = TRUE), "TuneModelEvaluateXGBoost_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(TuneModelEvaluateXGBoost, max_depth = 2,
#'   show_imports = "packages", lines = FALSE), "TuneModelEvaluateXGBoost_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @param xgbTuneSetTrain `xgb.DMatrix` de treino do fold, balanceada e com pesos.
#' @param xgbTuneSetValid `xgb.DMatrix` de validação do fold, usada na parada antecipada.
#' @param xgbTuneSetTest `xgb.DMatrix` de teste do fold (observações fora do fold), com
#'   rótulos.
#' @param params Lista com os hiperparâmetros candidatos, `innerThreads`, `positiveClass`
#'   e `negativeClass`.
#'
#' @returns Número com a AUC-PR do fold.
#'
#' @family Otimização de Hiperparâmetros
#'
#' @seealso \code{\link{TuneModelEvaluateXGBoostFolds}},
#'   \code{\link{PredictModelXGBoost}}, \code{\link[yardstick]{pr_auc_vec}}
#'
#' @references
#' Davis, J., & Goadrich, M. (2006). The relationship between Precision-Recall and ROC
#' curves. Proceedings of the 23rd ICML, 233-240.
#' \url{https://doi.org/10.1145/1143844.1143874}
#'
#' Prechelt, L. (1998). Early stopping: but when? Neural Networks: Tricks of the Trade,
#' Lecture Notes in Computer Science, 1524, 55-69.
#' \url{https://doi.org/10.1007/3-540-49430-8_3}
#'
#' @examples
#' \dontrun{
#' performanceResult <- TuneModelEvaluateXGBoost(
#'   xgbTuneSetTrain = xgboost::xgb.DMatrix(params$splits[[1]]$Train),
#'   xgbTuneSetValid = xgboost::xgb.DMatrix(params$splits[[1]]$Valid),
#'   xgbTuneSetTest = xgboost::xgb.DMatrix(params$splits[[1]]$Test),
#'   params = params
#' )
#' }
#'
#' @importFrom xgboost xgb.train xgb.params getinfo
#' @importFrom yardstick pr_auc_vec
#'
#' @export
TuneModelEvaluateXGBoost <- function(
    xgbTuneSetTrain,
    xgbTuneSetValid,
    xgbTuneSetTest,
    params
){
  
  ## Ajuste com parada antecipada
  # Ajustes dos hiperparametros apurados na otimizacao
  set.seed(42L)
  fittedModel <- xgboost::xgb.train(
    data                  = xgbTuneSetTrain,
    evals = list(
      validation          = xgbTuneSetValid
    ),
    nrounds               = 2000L,
    verbose               = 0L,
    maximize              = TRUE,
    early_stopping_rounds = 50L,
    params = xgboost::xgb.params(
      booster             = "gbtree",
      objective           = "binary:logistic",
      eval_metric         = "aucpr",
      grow_policy         = "depthwise",
      device              = "cpu",
      tree_method         = "hist",
      sampling_method     = "uniform",
      max_bin             = 512L,
      verbosity           = 0L,
      seed                = 42L,
      colsample_bytree    = params$colsample_bytree,
      learning_rate       = params$learning_rate,
      max_delta_step      = params$max_delta_step,
      max_depth           = params$max_depth,
      min_child_weight    = params$min_child_weight,
      min_split_loss      = params$min_split_loss,
      reg_alpha           = params$reg_alpha,
      reg_lambda          = params$reg_lambda,
      subsample           = params$subsample,
      nthread             = params$innerThreads
    )
  )
  
  ## Extracao dos rotulos de teste
  # Extrai o gabarito
  gabarito <- ifelse(
    test = (xgboost::getinfo(xgbTuneSetTest, name = "label") == 1L),
    yes = params$positiveClass,
    no = params$negativeClass
  ) |> 
    factor(
      levels = c(
        params$positiveClass, 
        params$negativeClass
      )
    )
  
  ## Predicao no teste
  # Executa predicao
  predictionData <- PredictModelXGBoost(
    data = xgbTuneSetTest,
    model = fittedModel,
    positive = params$positiveClass,
    negative = params$negativeClass
  ) |> 
    tibble::add_column(
      TARGET = gabarito,
      .before = 1L
    ) |> 
    dplyr::select(TARGET, .pred_class)
  
  ## Calculo da AUC-PR
  # Resultado do tuning
  performanceResult <- yardstick::pr_auc_vec(
    truth = predictionData$TARGET,
    estimate = predictionData$.pred_positive,
    estimator = "binary",
    event_level = "first"
  )
  
  # Retorna objeto esperado pelo BayesianOptimization
  return(performanceResult)
}
####
## Fim
#
