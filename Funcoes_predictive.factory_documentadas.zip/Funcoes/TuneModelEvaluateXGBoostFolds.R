#' @title Avaliar um Candidato de Hiperparâmetros na Validação Cruzada
#'
#' @usage
#' TuneModelEvaluateXGBoostFolds(params)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Avalia um conjunto candidato de hiperparâmetros em todos os folds, em paralelo, e
#' retorna a média do desempenho no formato exigido por `BayesianOptimization()`.
#'
#' @details
#' Para cada fold \eqn{k}, carrega as matrizes de treino, validação e teste gravadas em
#' disco por `TuneModelResampleFoldsXGBoost()` (`xgb.DMatrix()` recebe o caminho do
#' arquivo) e chama `TuneModelEvaluateXGBoost()`. O escore do candidato é:
#' \deqn{S = \frac{1}{K} \sum_{k=1}^{K} \mathrm{AUC\text{-}PR}_k}
#'
#' A execução usa `furrr::future_map()` com `chunk_size = 1`, de modo que cada fold é uma
#' tarefa independente do plano `future` registrado em `TuneModel()`, e `seed = 42L` para
#' fluxos de números aleatórios reprodutíveis.
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(TuneModelEvaluateXGBoostFolds, prefix = "##", code = FALSE,
#'   narrow = TRUE), "TuneModelEvaluateXGBoostFolds_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(TuneModelEvaluateXGBoostFolds,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "TuneModelEvaluateXGBoostFolds_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @param params Lista montada em `TuneModel()`, com `splits` (lista de caminhos `Train`,
#'   `Valid` e `Test` por fold), `innerThreads`, as classes positiva e negativa e os
#'   hiperparâmetros do candidato na escala do XGBoost.
#'
#' @returns Lista com `Score` (média do desempenho nos folds) e `Pred` (`0L`), estrutura
#'   exigida pela função objetivo de `BayesianOptimization()`.
#'
#' @family Otimização de Hiperparâmetros
#'
#' @seealso \code{\link{TuneModel}}, \code{\link{TuneModelEvaluateXGBoost}},
#'   \code{\link{TuneModelResampleFoldsXGBoost}}, \code{\link[furrr]{future_map}}
#'
#' @references
#' Kohavi, R. (1995). A study of cross-validation and bootstrap for accuracy estimation
#' and model selection. Proceedings of the 14th IJCAI, 1137-1143.
#'
#' furrr: Apply Mapping Functions in Parallel using Futures.
#' \url{https://furrr.futureverse.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: params montado em TuneModel() e plano future registrado
#' tuneResult <- TuneModelEvaluateXGBoostFolds(params)
#' tuneResult$Score
#' }
#'
#' @importFrom furrr future_map furrr_options
#'
#' @export
TuneModelEvaluateXGBoostFolds <- function(params){
  
  ## Avaliacao paralela dos folds
  # Processa folds
  performanceResults <- furrr::future_map(
    .x = seq_along(params$splits),
    .f = function(fold){
      
      # Processa avaliacao dos hiperparametros candidatos
      TuneModelEvaluateXGBoost(
        xgbTuneSetTrain = xgboost::xgb.DMatrix(
          data = params$splits[[fold]]$Train,
          silent = TRUE,
          nthread = params$innerThreads
        ),
        xgbTuneSetValid = xgboost::xgb.DMatrix(
          data = params$splits[[fold]]$Valid,
          silent = TRUE,
          nthread = params$innerThreads
        ),
        xgbTuneSetTest  = xgboost::xgb.DMatrix(
          data = params$splits[[fold]]$Test,
          silent = TRUE,
          nthread = params$innerThreads
        ),
        params = params
      )
    },
    # params = params
    .options = furrr::furrr_options(
      seed = 42L,
      globals = list(
        params = params,
        TuneModelEvaluateXGBoost = TuneModelEvaluateXGBoost,
        PredictModelXGBoost = PredictModelXGBoost
      ),
      packages = c(
        "xgboost", "tibble", "dplyr", "cli",
        "tidyselect", "yardstick", "options", "progressr"
      ),
      # Atribui exatamente um fold a cada future. Os folds de longa duracao
      # permanecem agendaveis de forma independente, e nenhum worker recebe um
      # chunk com varios folds enquanto outro worker compativel estiver livre.
      chunk_size = 1L
    )
  )
  
  ## Calculo do escore medio
  # Retorna media de desempenhodos folds
  tuneResult <- list(
    Score = mean(unlist(performanceResults)),
    Pred = 0L
  )
  
  # Retorna desempenho medio
  return(tuneResult)
}
####
## Fim
# 
