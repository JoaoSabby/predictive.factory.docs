#' @title Preparar os Folds de Validação Cruzada para o Tuning do XGBoost
#'
#' @usage
#' TuneModelResampleFoldsXGBoost(tuneSet, params)
#'
#' @description
#' `r lifecycle::badge("experimental")`
#'
#' Divide a base de tuning em folds estratificados e, para cada fold, grava em disco as
#' matrizes `xgb.DMatrix` de treino (balanceada e ponderada), de validação e de teste,
#' retornando os caminhos dos arquivos.
#'
#' @details
#' #. `rsample::vfold_cv()` com \eqn{K} igual a `predy_tune_num_folds`, estratificado por
#'    `TARGET`, com semente `42`;
#' #. para cada fold, em paralelo com `furrr::future_map()`:
#' - as observações do fold de análise são divididas em 80% para treino e 20% para
#'   validação, estratificadas;
#' - o treino é balanceado por `BalanceClass()` com `predy_balance_class` e recebe pesos
#'   10 para a classe positiva e 1 para a negativa;
#' - a validação não é balanceada;
#' - o teste é formado pelas observações fora do fold;
#' #. as três matrizes são gravadas com `xgb.DMatrix.save()` em
#'    `{tempdir()}/{idModel}/xgb_dmatrix_fold_{k}_{train|valid|test}.data`.
#'
#' A base, os índices e `params` são compartilhados com os workers por `mori::share()`, o
#' que evita cópias por worker. A margem base `baseMarginFold` é calculada, mas não é
#' usada.
#'
#' ::: {.callout-note}
#' <i class="fa-solid fa-scale-balanced"></i> **Correção do Desbalanceamento:**
#' O treino de cada fold recebe duas correções: a reamostragem de `BalanceClass()` e os
#' pesos 10:1 da classe positiva. As métricas de validação e de teste são calculadas sem
#' reamostragem.
#' :::
#'
#' @section Fluxo Lógico:
#' `r flow_embed(flow_view(TuneModelResampleFoldsXGBoost, prefix = "##", code = FALSE,
#'   narrow = TRUE), "TuneModelResampleFoldsXGBoost_fluxo")`
#'
#' @section Funções Chamadas:
#' `r flow_embed(flow_view_deps(TuneModelResampleFoldsXGBoost,
#'   max_depth = 2, show_imports = "packages", lines = FALSE),
#'   "TuneModelResampleFoldsXGBoost_dependencias")`
#'
#' @section Ciclo de Vida:
#' Função introduzida na versão 0.1.0 do projeto, em estágio experimental: a interface
#' pode mudar entre versões 0.x sem garantia de compatibilidade.
#'
#' @section Efeitos Colaterais:
#' - remove e recria a pasta `{tempdir()}/{idModel}`, com permissão `0775`;
#' - grava \eqn{3K} arquivos binários de `xgb.DMatrix`;
#' - altera, em cada worker, a configuração de threads de `collapse`, `cheapr` e `kit`.
#'
#' @param tuneSet Tibble de tuning sem as colunas de contexto, com `TARGET` e as features.
#' @param params Lista montada em `TuneModel()`, com `innerThreads` e `positiveClass`.
#'
#' @returns Lista com \eqn{K} elementos; cada um é uma lista com os caminhos `Train`,
#'   `Valid` e `Test` das matrizes do fold.
#'
#' @family Otimização de Hiperparâmetros
#'
#' @seealso \code{\link{TuneModel}}, \code{\link{TuneModelEvaluateXGBoostFolds}},
#'   \code{\link{BalanceClass}}, \code{\link[rsample]{vfold_cv}},
#'   \code{\link[xgboost]{xgb.DMatrix.save}}
#'
#' @references
#' Kohavi, R. (1995). A study of cross-validation and bootstrap for accuracy estimation
#' and model selection. Proceedings of the 14th IJCAI, 1137-1143.
#'
#' Cawley, G. C., & Talbot, N. L. C. (2010). On over-fitting in model selection and
#' subsequent selection bias in performance evaluation. Journal of Machine Learning
#' Research, 11, 2079-2107.
#' \url{https://www.jmlr.org/papers/v11/cawley10a.html}
#'
#' rsample: General Resampling Infrastructure.
#' \url{https://rsample.tidymodels.org/}
#'
#' @examples
#' \dontrun{
#' # Pré-condição: params montado em TuneModel() e plano future registrado
#' params$splits <- TuneModelResampleFoldsXGBoost(tuneSet, params)
#' }
#'
#' @importFrom rsample vfold_cv initial_split training testing
#' @importFrom furrr future_map furrr_options
#' @importFrom xgboost xgb.DMatrix xgb.DMatrix.save
#'
#' @export
TuneModelResampleFoldsXGBoost <- function(tuneSet, params){
  
  innerThreads = params$innerThreads
  
  ## Particionamento em folds estratificados
  # Constroi a validacao cruzada externa com estratificacao pela coluna TARGET.
  # Essa camada define as particoes de analise e assessment que permanecerao
  # independentes durante todo o processamento de cada fold.
  set.seed(42L)
  tuneFolds <- vfold_cv(
    data = tuneSet,
    v = opt("predy_tune_num_folds"),
    strata = TARGET
  )
  
  # Extrai somente os indices inteiros da particao de analise requeridos pelos
  # workers. Os objetos rsplit completos mantem referencias aos dados e
  # metadados que deixam de ser necessarios depois da definicao da estrutura
  # externa de reamostragem.
  foldsIndices <- lapply(
    X = tuneFolds$splits,
    FUN = function(split){split$in_id}
  )
  
  # Remove o container externo de objetos rsplit antes da criacao dos objetos
  # compartilhados e dos processos PSOCK. Os vetores extraidos permanecem como
  # referencia autoritativa para a composicao das particoes de analise e
  # assessment de cada fold externo.
  rm(tuneFolds)
  
  ## Preparacao do diretorio das matrizes
  # Constroi um diretorio especifico do modelo abaixo do temporario da sessao.
  # A remocao de um diretorio anterior impede que arquivos DMatrix obsoletos
  # sejam aceitos como artefatos produzidos pela execucao corrente.
  dirDMatrix <- file.path(tempdir(), getOption("idModel"))
  unlink(dirDMatrix, force = TRUE, recursive = TRUE)
  
  # Cria o diretorio antes do startup dos workers para fornecer a todos os
  # processos um destino local previamente validado. O retorno e verificado
  # porque showWarnings isoladamente nao converte falhas de permissao ou de
  # filesystem em uma condicao deterministica.
  dir.create(
    path = dirDMatrix,
    showWarnings = FALSE,
    recursive = TRUE,
    mode = "0775"
  )
  
  ## Definicao dos objetos compartilhados
  # Configuracoes para balanceamento de classes
  balanceClassConfig = opt("predy_balance_class")
  
  # Converte somente objetos volumosos e imutaveis para a representacao shared
  # do mori. Escalares possuem menor custo na serializacao convencional, enquanto
  # closures precisam preservar seus environments e nao recebem beneficio de
  # memoria compartilhada.
  globals <- list(
    tuneSet = share(tuneSet),
    foldsIndices = share(foldsIndices),
    params = share(params),
    dirDMatrix = dirDMatrix,
    balanceClassConfig = balanceClassConfig,
    BalanceClass = BalanceClass,
    BalanceClassAdanear = BalanceClassAdanear,
    BalanceClassRandomUnder = BalanceClassRandomUnder,
    CastNumericToLogical = CastNumericToLogical
  )
  fold = 1
  
  ## Geracao paralela das matrizes por fold
  # Submete um identificador de fold por elemento do mapeamento. A lista
  # explicita de globals define o ambiente completo requerido pelo corpo inline
  # do worker e impede a exportacao acidental de objetos alheios ao processamento.
  foldsFilesDMatrix <- future_map(
    .x = seq_along(foldsIndices),
    .f = function(fold){
      
      # Applies the worker-local CPU limit to collapse functions that honor the
      # package-level nthreads option.
      set_collapse(nthreads = params$innerThreads)
      
      # Applies the same CPU limit to cheapr OpenMP kernels. This setting must be
      # established inside each PSOCK process because workers do not share state.
      set_threads(params$innerThreads)
      
      # Applies the worker-local CPU limit to kit functions that receive the
      # package option as their default nThread argument.
      options(kit.nThread = params$innerThreads)

      # Constroi caminhos deterministicos e sem colisoes antes da alocacao dos
      # dados do fold. Cada worker grava somente os arquivos associados ao seu
      # proprio fold, eliminando sincronizacao de arquivos compartilhados no
      # caminho critico do processamento paralelo.
      filesDMatrix <- list(
        Train = file.path(dirDMatrix, paste0("xgb_dmatrix_fold_", fold, "_train.data")),
        Valid = file.path(dirDMatrix, paste0("xgb_dmatrix_fold_", fold, "_valid.data")),
        Test  = file.path(dirDMatrix, paste0("xgb_dmatrix_fold_", fold, "_test.data"))
      )
      
      # Executa a divisao estratificada interna sobre os identificadores de linha
      # e um vetor logico de classe. A exclusao das colunas preditoras do objeto
      # rsplit impede a materializacao adicional da particao de analise completa
      # dentro de cada worker.
      tuneSetInternalSplit <- initial_split(
        data = data.frame(
          rowIndex = foldsIndices[[fold]],
          TARGET = (tuneSet$TARGET[foldsIndices[[fold]]] == params$positiveClass)
        ),
        prop = 0.8,
        strata = TARGET
      )
      
      # Resolve a divisao interna para os identificadores originais antes da
      # materializacao de qualquer tabela larga. O container rsplit e removido
      # porque nenhuma operacao posterior requer sua tabela reduzida de origem.
      foldTrainIndices <- training(tuneSetInternalSplit)[["rowIndex"]]
      foldValidIndices <- testing(tuneSetInternalSplit)[["rowIndex"]]
      rm(tuneSetInternalSplit)
      
      # Materializa somente as linhas de treinamento requeridas nesta etapa. As
      # linhas de validacao e assessment externo permanecem no objeto shared ate
      # que a DMatrix de treinamento seja persistida e liberada.
      foldTrainSet <- tuneSet[foldTrainIndices, , drop = FALSE]
      rm(foldTrainIndices)
      
      # Aplica o balanceamento de classes exclusivamente aos dados de treinamento.
      # A referencia ao treinamento original e removida assim que o resultado
      # balanceado fica disponivel, tornando sua memoria elegivel para reutilizacao
      # durante a conversao nativa.
      foldTrainBalanced <- BalanceClass(
        database = foldTrainSet,
        balanceClassConfig = balanceClassConfig,
        nThreads = innerThreads
      ); rm(foldTrainSet)
      
      # Calcula a probabilidade empirica da classe positiva com uma unica
      # varredura. A rejeicao de valores nos limites impede que um logit infinito
      # ou indefinido seja armazenado como margem inicial das observacoes.
      propPositive <- mean(foldTrainBalanced$TARGET == levels(foldTrainBalanced$TARGET)[1L])
      
      # Calcula margem base
      baseMarginFold <- rep_(
        x = log_(propPositive / (1L - propPositive)),
        times = fnrow(foldTrainBalanced)
      )

      # Remove TARGET por indexacao nativa de colunas e preserva a estrutura de
      # data frame. A operacao dispensa select e nao introduz dependencia de
      # dplyr no caminho de construcao da DMatrix.
      xgb.DMatrix.save(
        dmatrix = xgb.DMatrix(
          data = foldTrainBalanced[, colnames(foldTrainBalanced) != "TARGET", drop = FALSE],
          label = as.integer(foldTrainBalanced$TARGET == params$positiveClass),
          # base_margin = baseMarginFold,
          weight = ifelse(
            test = (foldTrainBalanced$TARGET == params$positiveClass),
            yes = 10L,
            no = 1L
          ),
          silent = TRUE,
          nthread = innerThreads
        ),
        fname = filesDMatrix$Train
      )
      
      # Remove a tabela balanceada e sua margem alinhada por linha antes da
      # criacao da particao de validacao. O gerenciamento sequencial do ciclo de
      # vida reduz a memoria residente maxima requerida por cada processo PSOCK.
      rm(foldTrainBalanced, baseMarginFold, propPositive)
      
      # Materializa a validacao somente depois da gravacao da DMatrix de
      # treinamento. A distribuicao original das classes e preservada porque a
      # validacao deve medir o desempenho sobre observacoes nao balanceadas.
      foldValidSet <- tuneSet[foldValidIndices, , drop = FALSE]
      rm(foldValidIndices)
      
      # DMatrix Validacao
      xgb.DMatrix.save(
        dmatrix = xgb.DMatrix(
          data = foldValidSet[, colnames(foldValidSet) != "TARGET", drop = FALSE],
          label = as.integer(foldValidSet$TARGET == params$positiveClass),
          silent = TRUE,
          nthread = innerThreads
        ),
        fname = filesDMatrix$Valid
      )
      
      # Remove a validacao antes da materializacao do assessment externo. As
      # linhas de teste sao selecionadas pelo complemento direto dos indices de
      # analise, evitando alocar uma sequencia completa de identificadores.
      rm(foldValidSet)
      
      # Extrai porcao de teste do fold
      foldTestSet <- tuneSet[-foldsIndices[[fold]], , drop = FALSE]
      
      # DMatrix Teste
      xgb.DMatrix.save(
        dmatrix = xgb.DMatrix(
          data = foldTestSet[, colnames(foldTestSet) != "TARGET", drop = FALSE],
          label = as.integer(foldTestSet$TARGET == params$positiveClass),
          silent = TRUE,
          nthread = innerThreads
        ),
        fname = filesDMatrix$Test
      )
      
      # Remove a ultima tabela larga antes do retorno da lista compacta de
      # caminhos. Nenhum data frame e serializado de volta pelo canal PSOCK.
      rm(foldTestSet)
      
      # Limpa memoria
      gc(verbose = FALSE, full = TRUE)
      
      # Retorna list de arquivos com DMatrix para treino, validacao e teste dos folds
      return(filesDMatrix)
    },
    .options = furrr_options(
      seed = 42L,
      globals = globals,
      packages = c(
        "mori", "dplyr", "collapse", "cheapr", "kit", 
        "rsample", "sbyadanear", "xgboost", "options"
      ),
      # Atribui exatamente um fold a cada future. Os folds de longa duracao
      # permanecem agendaveis de forma independente, e nenhum worker recebe um
      # chunk com varios folds enquanto outro worker compativel estiver livre.
      chunk_size = 1L
    )
  )
  
  # Retorna list de arquivos com DMatrix para treino, validacao e teste dos folds
  return(foldsFilesDMatrix)
}
####
## Fim
# 
